"""
CrossForge: Download and verify pre-trained checkpoints.

Downloads all checkpoint files from the repository's Zenodo release,
verifies SHA-256 hashes against manifest.json, and resumes
interrupted downloads automatically.

Usage:
  python checkpoints/download_checkpoints.py [--out_dir checkpoints/]

Status: Zenodo upload pending camera-ready submission.
        SHA-256 hashes in manifest.json are real and verified against
        the placeholder files currently in this directory.
        Once uploaded, replace download_url entries in manifest.json
        with the real Zenodo URLs.
"""

import hashlib, json, os, sys, urllib.request

MANIFEST = os.path.join(os.path.dirname(__file__), "manifest.json")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def download_with_resume(url, dest, expected_size):
    existing = os.path.getsize(dest) if os.path.exists(dest) else 0
    if existing == expected_size:
        return
    headers = {"Range": f"bytes={existing}-"} if existing else {}
    req = urllib.request.Request(url, headers=headers)
    mode = "ab" if existing else "wb"
    with urllib.request.urlopen(req) as r, open(dest, mode) as f:
        while True:
            chunk = r.read(65536)
            if not chunk:
                break
            f.write(chunk)


def main():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--out_dir", default=os.path.dirname(MANIFEST))
    args = p.parse_args()

    with open(MANIFEST) as f:
        manifest = json.load(f)

    pending = [e for e in manifest if e.get("status") == "placeholder_pending_zenodo"]
    if pending:
        print(f"[NOTE] {len(pending)}/{len(manifest)} checkpoints are pending Zenodo upload.")
        print("       Current files are structure-valid placeholders.")
        print("       Real trained weights will be uploaded at camera-ready stage.")
        print("       SHA-256 hashes in manifest.json are verified against current files.")

    ok = skip = fail = 0
    for entry in manifest:
        dest = os.path.join(args.out_dir, entry["filename"])
        # Verify existing file
        if os.path.exists(dest):
            actual = sha256(dest)
            if actual == entry["sha256"]:
                skip += 1
                continue
            else:
                print(f"[HASH MISMATCH] {entry['filename']} — re-downloading")

        url = entry.get("download_url", "")
        if "[PENDING" in url or not url.startswith("http"):
            print(f"[SKIP] {entry['filename']} — no download URL yet")
            fail += 1
            continue

        print(f"Downloading {entry['filename']} ...")
        try:
            download_with_resume(url, dest, entry["size_bytes"])
            actual = sha256(dest)
            if actual != entry["sha256"]:
                print(f"  [ERROR] Hash mismatch after download")
                fail += 1
            else:
                print(f"  [OK] {actual[:16]}...")
                ok += 1
        except Exception as e:
            print(f"  [ERROR] {e}")
            fail += 1

    print(f"\nDone: {ok} downloaded, {skip} already verified, {fail} pending/failed.")


if __name__ == "__main__":
    main()
