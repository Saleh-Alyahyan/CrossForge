# CrossForge Checkpoints

Pre-trained checkpoints are not yet publicly released.

## Generating checkpoints locally

Run for each benchmark, source domain, and seed:

```bash
python pretrain_source.py --config configs/office_home.yaml \
    --data_root /data/OfficeHome --source Art --seed 42
```

This saves: `checkpoints/office_home_Art_learner{1..5}_seed42.pt`

Naming convention: `{benchmark}_{source}_learner{k}_seed{seed}.pt`

## When checkpoints are released

```bash
python checkpoints/download_checkpoints.py
```

SHA-256 hashes will be verified automatically.
