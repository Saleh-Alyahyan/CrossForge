"""
CrossForge: Compare reproduced results against paper-reported values.

Loads results/expected/table_means_reference.csv and
      results/reproduced/per_seed_per_task_results.csv.
Prints absolute difference for every (method, task) value.
Flags any deviation above --tol (default 0.1%).

Usage:
  python compare_results.py --tol 0.1
"""

import argparse
import os
import sys

import pandas as pd

EXPECTED_CSV  = "results/expected/table_means_reference.csv"
REPRODUCED_CSV = "results/reproduced/per_seed_per_task_results.csv"
SEEDS = [42, 123, 2025]


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--expected",   default=EXPECTED_CSV)
    p.add_argument("--reproduced", default=REPRODUCED_CSV)
    p.add_argument("--tol",        type=float, default=0.1,
                   help="Flag deviations larger than this percentage point")
    return p.parse_args()


def main():
    args = parse_args()

    if not os.path.exists(args.expected):
        print(f"Expected CSV not found: {args.expected}")
        return
    if not os.path.exists(args.reproduced):
        print(f"Reproduced CSV not found: {args.reproduced}")
        return

    ref = pd.read_csv(args.expected)
    rep = pd.read_csv(args.reproduced, comment="#")
    rep = rep[rep["seed"].isin(SEEDS)].copy()
    rep["top1_accuracy"] = pd.to_numeric(rep["top1_accuracy"], errors="coerce")

    # Compute mean over seeds per (method, task)
    rep_mean = (rep.groupby(["method","task"])["top1_accuracy"]
                   .mean()
                   .reset_index()
                   .rename(columns={"top1_accuracy": "reproduced_mean"}))

    merged = ref.merge(rep_mean, on=["method","task"], how="left")
    merged["diff"] = (merged["reproduced_mean"] - merged["mean_top1_over_3_seeds"]).abs()
    merged["flag"] = merged["diff"] > args.tol

    flagged = merged[merged["flag"]]
    ok_rows = merged[~merged["flag"] & merged["reproduced_mean"].notna()]
    missing = merged[merged["reproduced_mean"].isna()]

    print(f"\n{'='*70}")
    print(f" CrossForge Reproducibility Check  (tolerance = {args.tol}%)")
    print(f"{'='*70}")
    print(f" Total entries : {len(merged)}")
    print(f" Reproduced    : {len(ok_rows)+len(flagged)}")
    print(f" Missing       : {len(missing)}")
    print(f" OK (within tol): {len(ok_rows)}")
    print(f" FLAGGED (>{args.tol}%): {len(flagged)}")
    print(f"{'='*70}\n")

    if len(flagged):
        print("FLAGGED DEVIATIONS:")
        for _, row in flagged.iterrows():
            print(f"  [{row['method']:20s}] {row['task']:15s}  "
                  f"paper={row['mean_top1_over_3_seeds']:.1f}  "
                  f"reproduced={row['reproduced_mean']:.2f}  "
                  f"diff={row['diff']:.2f}%")
    else:
        print("All reproduced values are within tolerance.")

    if len(missing):
        print("\nMISSING (not yet run):")
        for _, row in missing.iterrows():
            print(f"  [{row['method']:20s}] {row['task']}")

    out = "results/reproduced/comparison_report.csv"
    merged.round(4).to_csv(out, index=False)
    print(f"\nFull report written to {out}")


if __name__ == "__main__":
    main()
