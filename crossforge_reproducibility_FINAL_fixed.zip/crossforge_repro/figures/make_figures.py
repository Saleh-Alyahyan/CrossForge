"""
CrossForge: Regenerate all results figures from per_seed_per_task_results.csv.

Output: figures/*.pdf at 600 dpi, Times New Roman font, IEEE publication style.

Usage:
  python figures/make_figures.py --csv results/reproduced/per_seed_per_task_results.csv --out figures/
"""

import argparse
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from src.datasets.dataset import CLINICAL_TASK_IDS, DN_TASK_IDS, OH_TASK_IDS

plt.rcParams.update({
    "font.family":        "serif",
    "font.serif":         ["Times New Roman", "Times", "DejaVu Serif"],
    "font.size":          9,
    "axes.titlesize":     9,
    "axes.labelsize":     9,
    "xtick.labelsize":    8,
    "ytick.labelsize":    8,
    "legend.fontsize":    8,
    "figure.dpi":         600,
    "savefig.dpi":        600,
    "savefig.bbox":       "tight",
    "savefig.format":     "pdf",
})

METHODS   = ["Source Only","SHOT","NRC","AaD","LAME","DaC","G-SFDA","CrossForge"]
BASELINES = ["SHOT","NRC","AaD","LAME","DaC","G-SFDA"]
SEEDS     = [42, 123, 2025]
COLORS    = {"Source Only":"#888888","SHOT":"#1f77b4","NRC":"#ff7f0e","AaD":"#2ca02c",
             "LAME":"#d62728","DaC":"#9467bd","G-SFDA":"#8c564b","CrossForge":"#e377c2"}


def load(csv_path):
    df = pd.read_csv(csv_path, comment="#")
    df = df[df["seed"].isin(SEEDS)].copy()
    df["top1_accuracy"] = pd.to_numeric(df["top1_accuracy"], errors="coerce")
    return df


def mean_std(df, tasks):
    g = df[df["task"].isin(tasks)].groupby(["method","task"])["top1_accuracy"]
    return g.mean().unstack("task"), g.std(ddof=1).unstack("task")


def fig_oh_per_task(df, out_dir):
    """Figure: Office-Home per-task bar chart (CrossForge vs best baseline per task)."""
    mean, std = mean_std(df, OH_TASK_IDS)
    if mean.empty:
        return
    fig, ax = plt.subplots(figsize=(7, 3))
    x = np.arange(len(OH_TASK_IDS))
    w = 0.35
    if "DaC" in mean.index:
        m_bl = mean.loc["DaC", OH_TASK_IDS].values
        s_bl = std.loc["DaC", OH_TASK_IDS].values
        ax.bar(x - w/2, m_bl, w, yerr=s_bl, label="DaC (best baseline)",
               color=COLORS["DaC"], capsize=3)
    if "CrossForge" in mean.index:
        m_cf = mean.loc["CrossForge", OH_TASK_IDS].values
        s_cf = std.loc["CrossForge", OH_TASK_IDS].values
        ax.bar(x + w/2, m_cf, w, yerr=s_cf, label="CrossForge",
               color=COLORS["CrossForge"], capsize=3)
    labels = [t.replace("OH_","").replace("_","→") for t in OH_TASK_IDS]
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=45, ha="right")
    ax.set_ylabel("Top-1 Accuracy (%)")
    ax.set_title("Office-Home: Per-Task Accuracy")
    ax.legend()
    fig.tight_layout()
    path = os.path.join(out_dir, "fig_office_home_per_task.pdf")
    fig.savefig(path)
    plt.close(fig)
    print(f"Saved {path}")


def fig_benchmark_avg(df, out_dir):
    """Figure: Average accuracy per benchmark, all methods."""
    bench_tasks = {"Office-Home": OH_TASK_IDS, "DomainNet-126": DN_TASK_IDS,
                   "Clinical": CLINICAL_TASK_IDS}
    rows = []
    for bname, tasks in bench_tasks.items():
        sub = df[df["task"].isin(tasks)]
        if sub.empty:
            continue
        g = sub.groupby("method")["top1_accuracy"]
        for method in METHODS:
            if method in g.groups:
                m = g.get_group(method).mean()
                rows.append({"Benchmark": bname, "Method": method, "mean": m})
    if not rows:
        return
    t = pd.DataFrame(rows)
    fig, axes = plt.subplots(1, 3, figsize=(8, 3), sharey=False)
    for ax, bname in zip(axes, bench_tasks.keys()):
        sub = t[t["Benchmark"] == bname]
        if sub.empty:
            continue
        ax.bar(sub["Method"], sub["mean"],
               color=[COLORS.get(m, "#333") for m in sub["Method"]])
        ax.set_title(bname)
        ax.set_ylabel("Mean Top-1 (%)")
        ax.set_xticklabels(sub["Method"], rotation=45, ha="right")
    fig.suptitle("Benchmark Average Accuracy", y=1.02)
    fig.tight_layout()
    path = os.path.join(out_dir, "fig_benchmark_avg.pdf")
    fig.savefig(path)
    plt.close(fig)
    print(f"Saved {path}")


def fig_ablation(df, out_dir):
    """Figure: Ablation bar chart (Table 10)."""
    method_map = {"full": "CrossForge", "no_cmrd": "CrossForge_no_cmrd",
                  "no_deg": "CrossForge_no_deg", "no_ecl": "CrossForge_no_ecl",
                  "no_cmrd_deg": "CrossForge_no_cmrd_deg",
                  "shot_gate": "CrossForge_shot_gate"}
    labels, means, stds = [], [], []
    for abl, mname in method_map.items():
        sub = df[(df["method"] == mname) & (df["task"].isin(OH_TASK_IDS))]
        if sub.empty:
            continue
        per_seed = sub.groupby("seed")["top1_accuracy"].mean()
        labels.append(abl)
        means.append(per_seed.mean())
        stds.append(per_seed.std(ddof=1))
    if not labels:
        return
    fig, ax = plt.subplots(figsize=(5, 3))
    x = np.arange(len(labels))
    ax.bar(x, means, yerr=stds, capsize=4, color="#e377c2")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=30, ha="right")
    ax.set_ylabel("OH Avg. Accuracy (%)")
    ax.set_title("Ablation Study (Office-Home)")
    fig.tight_layout()
    path = os.path.join(out_dir, "fig_ablation.pdf")
    fig.savefig(path)
    plt.close(fig)
    print(f"Saved {path}")


def fig_ntr(df, out_dir):
    """Figure: NTR per method."""
    methods = BASELINES + ["CrossForge"]
    ntrs = []
    for m in methods:
        sub = df[df["method"] == m]
        if sub.empty:
            ntrs.append(np.nan)
            continue
        n_below = (sub["top1_accuracy"] < sub["source_only_accuracy"]).sum()
        n_total = len(sub)
        ntrs.append(n_below / max(n_total, 1) * 100)
    fig, ax = plt.subplots(figsize=(5, 3))
    colors = [COLORS.get(m, "#333") for m in methods]
    ax.bar(methods, ntrs, color=colors)
    ax.set_ylabel("NTR (%)")
    ax.set_title("Negative Transfer Rate")
    ax.set_xticklabels(methods, rotation=30, ha="right")
    fig.tight_layout()
    path = os.path.join(out_dir, "fig_ntr.pdf")
    fig.savefig(path)
    plt.close(fig)
    print(f"Saved {path}")


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--csv", default="results/reproduced/per_seed_per_task_results.csv")
    p.add_argument("--out", default="figures/")
    return p.parse_args()


def main():
    args = parse_args()
    os.makedirs(args.out, exist_ok=True)
    if not os.path.exists(args.csv):
        print(f"Results CSV not found: {args.csv}")
        return
    df = load(args.csv)
    fig_oh_per_task(df, args.out)
    fig_benchmark_avg(df, args.out)
    fig_ablation(df, args.out)
    fig_ntr(df, args.out)
    print("All figures written.")


if __name__ == "__main__":
    main()
