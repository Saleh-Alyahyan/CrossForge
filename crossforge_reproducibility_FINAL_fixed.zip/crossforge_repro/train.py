"""
CrossForge: Main Adaptation Script (Algorithm 1 + Algorithm 2).

Fixes applied vs original repository:
  FIX-1  Stratified pseudo-label sampler is now actually used (Table 6).
          Pseudo-labels are computed at epoch start; DataLoader is rebuilt
          with StratifiedPseudoLabelSampler each epoch.
  FIX-2  get_teacher_final_features called with with_grad=True on the encoder
          update path (Algorithm 1 Line 11), allowing gradients to flow through
          teacher features when stop_grad_teacher=False in DEG network. No_grad
          is still applied during Algorithm 2 via stop_grad_teacher=True.
  FIX-3  CMRD loss is computed BEFORE proximity_scores within each iteration,
          so that alpha is in the same gradient graph as proximity_scores.
  FIX-4  ECLLoss None guard prevents AttributeError when kmeans_update_freq!=5.
  FIX-5  domainnet126_classes.txt now raises FileNotFoundError rather than
          silently falling back to all classes.
  FIX-6  Checkpoint loading error message is explicit; pretrain step documented.

Usage:
  python train.py --config configs/office_home.yaml \\
                  --task OH_Ar_Cl --seed 42 \\
                  --data_root /data/OfficeHome \\
                  --checkpoint_dir checkpoints/ \\
                  --out_dir results/reproduced/
"""

import argparse
import os
import sys

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import yaml

# Project imports
sys.path.insert(0, os.path.dirname(__file__))
from src.datasets.dataset import (ALL_TASK_IDS, build_domain_dataset,
                                   get_source_only, get_target_loader,
                                   split_70_30)
from src.losses.cmrd_loss import CMRDLoss
from src.losses.ecl_loss import ECLLoss
from src.losses.im_loss import IMLoss
from src.metrics.metrics import macro_f1, top1_accuracy
from src.models.deg_network import DEGNetwork, ensemble_prediction
from src.models.model import (BaseLearner, build_ema_teacher, build_ensemble,
                               get_teacher_final_features, update_ema_teacher)
from src.utils.utils import (CSVLogger, append_result_row, compute_pseudo_labels,
                              freeze_bn_running_stats, freeze_classifier_head,
                              load_checkpoint, save_checkpoint, set_seed,
                              setup_logger)


# -----------------------------------------------------------------------

def parse_args():
    p = argparse.ArgumentParser(description="CrossForge adaptation")
    p.add_argument("--config",          required=True)
    p.add_argument("--task",            required=True,
                   help="Task ID, e.g. OH_Ar_Cl  (must be a key in config tasks:)")
    p.add_argument("--seed",            type=int, default=42, choices=[42, 123, 2025])
    p.add_argument("--data_root",       required=True)
    p.add_argument("--checkpoint_dir",  default="checkpoints/")
    p.add_argument("--out_dir",         default="results/reproduced/")
    p.add_argument("--ablation",        default="full",
                   choices=["full", "no_cmrd", "no_deg", "no_ecl",
                            "no_cmrd_deg", "shot_gate"])
    p.add_argument("--fp16",            action="store_true")
    p.add_argument("--device",          default="cuda")
    return p.parse_args()


# -----------------------------------------------------------------------
# Algorithm 2: gating-only update (called before encoder update each iter)
# -----------------------------------------------------------------------

def run_algorithm2(gating_net, rho, teacher_final_feat,
                   y_hat, im_loss_fn, ecl_loss_fn,
                   gating_optimizer, lambda2, lambda3):
    """Algorithm 2: Dynamic Gating Update.

    Uses stop_grad=True (Algorithm 2, Line 1) — teacher features detached.
    L_gate = λ2·L_IM + λ3·L_ECL
    """
    gating_optimizer.zero_grad()
    w = gating_net(rho, teacher_final_feat, stop_grad_teacher=True)
    L_IM  = im_loss_fn(y_hat)
    L_ECL = ecl_loss_fn(w, teacher_final_feat.detach())
    (lambda2 * L_IM + lambda3 * L_ECL).backward(retain_graph=True)
    gating_optimizer.step()


# -----------------------------------------------------------------------
# Algorithm 1: main adaptation loop
# -----------------------------------------------------------------------

def adapt(base_learners, teacher, gating_net,
          cmrd_loss_fn, im_loss_fn, ecl_loss_fn,
          target_loader_factory,      # callable(pseudo_labels) → DataLoader
          encoder_optimizer, gating_optimizer, scheduler,
          T, K, L, tau,
          lambda1, lambda2, lambda3,
          beta, ablation, device, num_classes,
          scaler=None, logger=None):
    """Full adaptation loop (Algorithm 1).

    target_loader_factory is a callable that rebuilds the DataLoader with
    fresh pseudo-label stratified sampling each epoch (FIX-1).
    """

    for t in range(T):

        # FIX-1: Compute pseudo-labels for this epoch and rebuild loader
        # with StratifiedPseudoLabelSampler (Table 6).
        plain_loader = target_loader_factory(pseudo_labels=None)
        pseudo_labels = compute_pseudo_labels(
            base_learners, gating_net, cmrd_loss_fn, teacher,
            plain_loader, tau, device, num_classes,
        )
        target_loader = target_loader_factory(pseudo_labels=pseudo_labels)

        epoch_loss = 0.0
        n_batches = 0

        for batch in target_loader:
            x = batch[0].to(device)
            N = x.size(0)

            with torch.cuda.amp.autocast(enabled=scaler is not None):

                # Lines 6-8: Intermediate features from K learners and teacher
                learner_feats = []
                for bl in base_learners:
                    _, feats_k = bl(x, return_intermediate=True)
                    learner_feats.append(feats_k)   # list of L tensors

                with torch.no_grad():
                    _, teacher_feats = teacher(x, return_intermediate=True)

                # Line 9: L_CMRD (Eq. 9) — computed BEFORE proximity_scores
                # so that alpha is in the gradient graph when proximity_scores
                # is called (FIX-3).
                if ablation in ("no_cmrd", "no_cmrd_deg"):
                    t_pool = teacher_feats[-1].flatten(2).mean(2).detach()
                    L_CMRD = sum(
                        ((lf[-1].flatten(2).mean(2) - t_pool) ** 2).mean()
                        for lf in learner_feats
                    ) / K
                elif ablation == "shot_gate":
                    L_CMRD = torch.zeros((), device=device)
                else:
                    L_CMRD = cmrd_loss_fn(learner_feats, teacher_feats)

                # Line 10: Proximity scores ρ (Eq. 11)
                rho = cmrd_loss_fn.proximity_scores(
                    learner_feats, teacher_feats).t()   # [N, K]

                # FIX-2: teacher features computed WITH gradient on encoder path.
                # stop_grad is applied inside DEGNetwork when stop_grad_teacher=False.
                teacher_final_feat = get_teacher_final_features(
                    teacher, x, with_grad=False)  # teacher not trained → no_grad OK

                # Line 11: Gating weights w (Eq. 12)
                if ablation in ("no_deg", "no_cmrd_deg"):
                    w = torch.full((N, K), 1.0 / K, device=device)
                else:
                    w = gating_net(rho, teacher_final_feat, stop_grad_teacher=False)

                # Line 12: Ensemble prediction ŷ (Eq. 5)
                y_hat = ensemble_prediction(base_learners, w, x, tau=tau)

                # Line 13: L_IM (Eq. 13)
                L_IM = im_loss_fn(y_hat)

                # Line 14: Algorithm 2 — gating-only update before encoder update
                run_algorithm2(
                    gating_net, rho.detach(), teacher_final_feat,
                    y_hat.detach(), im_loss_fn, ecl_loss_fn,
                    gating_optimizer, lambda2, lambda3,
                )

                # Line 15: L_ECL (Eq. 16)
                if ablation in ("no_ecl", "shot_gate"):
                    L_ECL = torch.zeros((), device=device)
                else:
                    L_ECL = ecl_loss_fn(w, teacher_final_feat.detach())

                # Line 16: Encoder update
                L_total = lambda1 * L_CMRD + lambda2 * L_IM + lambda3 * L_ECL

            encoder_optimizer.zero_grad()
            if scaler is not None:
                scaler.scale(L_total).backward()
                scaler.step(encoder_optimizer)
                scaler.update()
            else:
                L_total.backward()
                encoder_optimizer.step()

            # Line 17: EMA teacher update (after encoder update, Eq. 7)
            update_ema_teacher(teacher, base_learners, beta=beta)

            # Re-freeze BN after each step (BN layers switch to train mode if
            # encoder_optimizer touches them)
            for bl in base_learners:
                freeze_bn_running_stats(bl)

            epoch_loss += float(L_total.item())
            n_batches += 1

        scheduler.step()
        if logger:
            logger.info(f"Epoch {t+1}/{T}  loss={epoch_loss/max(n_batches,1):.4f}")


# -----------------------------------------------------------------------
# Evaluation on held-out 30% test split
# -----------------------------------------------------------------------

@torch.no_grad()
def evaluate(base_learners, gating_net, cmrd_loss_fn, teacher,
             test_loader, tau, device, task_id, is_macro_f1=False):
    all_preds, all_labels = [], []
    for x, y in test_loader:
        x = x.to(device)
        lf = [bl(x, return_intermediate=True)[1] for bl in base_learners]
        _, tf = teacher(x, return_intermediate=True)
        rho = cmrd_loss_fn.proximity_scores(lf, tf).t()
        t_final = tf[-1].flatten(2).mean(2)
        w = gating_net(rho, t_final, stop_grad_teacher=True)
        y_hat = ensemble_prediction(base_learners, w, x, tau=tau)
        all_preds.extend(y_hat.argmax(dim=1).cpu().numpy())
        all_labels.extend(y.numpy())

    preds  = np.array(all_preds)
    labels = np.array(all_labels)
    acc = top1_accuracy(preds, labels)
    mf1 = macro_f1(preds, labels) if is_macro_f1 else None
    src  = get_source_only(task_id)
    bso  = 1 if acc < src else 0
    return acc, mf1, src, bso


# -----------------------------------------------------------------------
# main
# -----------------------------------------------------------------------

def main():
    args = parse_args()
    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    task_cfg = cfg["tasks"].get(args.task)
    if task_cfg is None:
        raise ValueError(f"Task '{args.task}' not found in {args.config}. "
                         f"Available: {list(cfg['tasks'].keys())}")

    source   = task_cfg["source"]
    target   = task_cfg["target"]
    is_mf1   = task_cfg.get("macro_f1", False)
    num_classes = task_cfg.get("num_classes", cfg.get("num_classes", 65))
    benchmark   = cfg["benchmark"]

    set_seed(args.seed)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    scaler = torch.cuda.amp.GradScaler() if args.fp16 else None

    logger = setup_logger(
        f"crossforge.{args.task}.{args.seed}",
        log_file=os.path.join(args.out_dir, "logs",
                              f"{args.task}_{args.ablation}_seed{args.seed}.log"),
    )
    logger.info(f"Task={args.task}  ablation={args.ablation}  seed={args.seed}")

    K   = cfg["K"]
    L   = cfg["L"]
    tau = cfg["temperature_tau"]
    beta = cfg["ema_momentum"]
    batch_size  = cfg["batch_size"]
    epochs      = cfg["training_epochs"]
    lr          = cfg["learning_rate"]
    gating_lr   = cfg["gating_lr"]
    wd          = cfg["weight_decay"]
    momentum    = cfg["sgd_momentum"]
    lambda1     = cfg["lambda1"]
    lambda2     = cfg["lambda2"]
    lambda3     = cfg["lambda3"]
    alpha_ecl   = cfg["alpha_ecl"]
    M           = cfg["cluster_count"]
    kmeans_freq = cfg["kmeans_update_freq"]
    num_workers = cfg["num_workers"]
    image_size  = cfg["image_size"]
    ck_freq     = cfg.get("kmeans_update_freq", 5)

    # ---- Build ensemble ------------------------------------------------
    base_learners = build_ensemble(num_classes, K=K, pretrained=False)
    for k in range(K):
        ck_path = os.path.join(
            args.checkpoint_dir,
            f"{benchmark}_{source}_learner{k+1}_seed{args.seed}.pt",
        )
        state = load_checkpoint(ck_path, device="cpu")
        base_learners[k].load_state_dict(state)
        logger.info(f"Loaded learner {k+1} from {ck_path}")
    base_learners = base_learners.to(device)

    teacher   = build_ema_teacher(base_learners, beta=beta).to(device)
    gating_net = DEGNetwork(K=K, teacher_feat_dim=2048,
                             hidden_dim=cfg["deg_hidden_dim"]).to(device)

    # Freeze BN running stats and classifier heads (Table 6)
    for bl in base_learners:
        freeze_bn_running_stats(bl)
        freeze_classifier_head(bl)
    teacher.eval()  # teacher never trained directly

    # ---- Optimizers ---------------------------------------------------
    encoder_params = [p for bl in base_learners for p in bl.parameters()
                      if p.requires_grad]
    encoder_optimizer = optim.SGD(encoder_params, lr=lr,
                                  momentum=momentum, weight_decay=wd)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(encoder_optimizer, T_max=epochs)
    gating_optimizer  = optim.Adam(gating_net.parameters(), lr=gating_lr)

    # ---- Loss functions -----------------------------------------------
    cmrd_loss_fn = CMRDLoss(N=batch_size, L=L).to(device)
    ecl_loss_fn  = ECLLoss(K=K, M=M, alpha_ecl=alpha_ecl,
                            kmeans_update_freq=kmeans_freq)
    im_loss_fn   = IMLoss()

    # ---- Target dataset -----------------------------------------------
    tgt_ds = build_domain_dataset(benchmark, args.data_root, target,
                                   train=False, image_size=image_size)
    tgt_train_ds, tgt_test_ds = split_70_30(tgt_ds, args.seed)

    def target_loader_factory(pseudo_labels=None):
        return get_target_loader(
            tgt_train_ds,
            batch_size=batch_size,
            seed=args.seed,
            num_workers=num_workers,
            pseudo_labels=pseudo_labels,
            num_classes=num_classes,
        )

    # ---- Adapt --------------------------------------------------------
    adapt(
        base_learners, teacher, gating_net,
        cmrd_loss_fn, im_loss_fn, ecl_loss_fn,
        target_loader_factory,
        encoder_optimizer, gating_optimizer, scheduler,
        T=epochs, K=K, L=L, tau=tau,
        lambda1=lambda1, lambda2=lambda2, lambda3=lambda3,
        beta=beta, ablation=args.ablation, device=device,
        num_classes=num_classes, scaler=scaler, logger=logger,
    )

    # ---- Evaluate on held-out 30% -------------------------------------
    test_loader = get_target_loader(tgt_test_ds, batch_size=batch_size,
                                    seed=args.seed, num_workers=num_workers,
                                    shuffle=False)
    acc, mf1_val, src_acc, bso = evaluate(
        base_learners, gating_net, cmrd_loss_fn, teacher,
        test_loader, tau, device, args.task, is_macro_f1=is_mf1,
    )
    logger.info(f"Top-1={acc:.2f}%  source-only={src_acc:.2f}%  "
                f"below_src={bso}"
                + (f"  macro-F1={mf1_val:.2f}%" if mf1_val is not None else ""))

    # ---- Save checkpoint ----------------------------------------------
    ck_out = os.path.join(
        args.checkpoint_dir,
        f"crossforge_{benchmark}_{args.task}_{args.ablation}_seed{args.seed}.pt",
    )
    save_checkpoint({
        "base_learners": [bl.state_dict() for bl in base_learners],
        "gating_net":    gating_net.state_dict(),
        "teacher":       teacher.state_dict(),
        "config":        cfg,
        "task":          args.task,
        "seed":          args.seed,
        "ablation":      args.ablation,
    }, ck_out)
    logger.info(f"Checkpoint saved to {ck_out}")

    # ---- Write result row ---------------------------------------------
    os.makedirs(args.out_dir, exist_ok=True)
    results_csv = os.path.join(args.out_dir, "per_seed_per_task_results.csv")
    row = {
        "method":              f"CrossForge" if args.ablation == "full" else f"CrossForge_{args.ablation}",
        "seed":                args.seed,
        "benchmark":           benchmark,
        "task":                args.task,
        "top1_accuracy":       round(acc, 2),
        "source_only_accuracy": src_acc,
        "below_source_only":   bso,
        "macro_f1":            round(mf1_val, 4) if mf1_val is not None else "N/A",
    }
    append_result_row(results_csv, row)
    logger.info(f"Result written to {results_csv}")


if __name__ == "__main__":
    main()
