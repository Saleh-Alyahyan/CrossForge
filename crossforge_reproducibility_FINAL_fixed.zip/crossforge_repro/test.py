"""
CrossForge: Test / Inference Script.

Evaluates an adapted ensemble checkpoint on the held-out 30% test split.
Outputs: top-1 accuracy, macro-F1 (C2/C4), below_source_only flag,
         confusion matrix, per-class accuracy, gating entropy, param count.

Usage:
  python test.py --checkpoint checkpoints/crossforge_office_home_OH_Ar_Cl_full_seed42.pt \\
                 --config configs/office_home.yaml \\
                 --task OH_Ar_Cl --seed 42 \\
                 --data_root /data/OfficeHome
"""

import argparse
import json
import os
import sys
import time

import numpy as np
import torch
import yaml

sys.path.insert(0, os.path.dirname(__file__))
from src.datasets.dataset import (build_domain_dataset, get_source_only,
                                   get_target_loader, split_70_30)
from src.losses.cmrd_loss import CMRDLoss
from src.metrics.metrics import (classification_report_str, confusion,
                                  gate_entropy, macro_f1, per_class_accuracy,
                                  top1_accuracy)
from src.models.deg_network import DEGNetwork, ensemble_prediction
from src.models.model import build_ensemble
from src.utils.utils import load_checkpoint, set_seed, setup_logger


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint",  required=True)
    p.add_argument("--config",      required=True)
    p.add_argument("--task",        required=True)
    p.add_argument("--seed",        type=int, default=42)
    p.add_argument("--data_root",   required=True)
    p.add_argument("--out",         default=None, help="Write JSON result to this path")
    p.add_argument("--device",      default="cuda")
    return p.parse_args()


@torch.no_grad()
def run_test(base_learners, gating_net, cmrd, teacher, loader, tau, device, K):
    all_preds, all_labels, all_weights = [], [], []
    t0 = time.perf_counter()
    n_samples = 0
    for x, y in loader:
        x = x.to(device)
        lf = [bl(x, return_intermediate=True)[1] for bl in base_learners]
        _, tf = teacher(x, return_intermediate=True)
        rho     = cmrd.proximity_scores(lf, tf).t()
        t_final = tf[-1].flatten(2).mean(2)
        w = gating_net(rho, t_final, stop_grad_teacher=True)
        y_hat = ensemble_prediction(base_learners, w, x, tau=tau)
        all_preds.extend(y_hat.argmax(1).cpu().numpy())
        all_labels.extend(y.numpy())
        all_weights.append(w.cpu())
        n_samples += x.size(0)
    elapsed = time.perf_counter() - t0
    return (np.array(all_preds), np.array(all_labels),
            torch.cat(all_weights, dim=0), elapsed, n_samples)


def count_params(module_list):
    return sum(p.numel() for m in module_list for p in m.parameters())


def main():
    args = parse_args()
    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    task_cfg    = cfg["tasks"][args.task]
    target      = task_cfg["target"]
    is_mf1      = task_cfg.get("macro_f1", False)
    num_classes = task_cfg.get("num_classes", cfg.get("num_classes", 65))
    benchmark   = cfg["benchmark"]
    K           = cfg["K"]
    tau         = cfg["temperature_tau"]
    batch_size  = cfg["batch_size"]
    num_workers = cfg["num_workers"]
    image_size  = cfg["image_size"]

    set_seed(args.seed)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    logger = setup_logger("crossforge.test")

    ck = load_checkpoint(args.checkpoint, device="cpu")

    base_learners = build_ensemble(num_classes, K=K, pretrained=False)
    for bl, sd in zip(base_learners, ck["base_learners"]):
        bl.load_state_dict(sd)
    base_learners = base_learners.to(device).eval()

    teacher = build_ensemble(num_classes, K=1, pretrained=False)[0]
    teacher.load_state_dict(ck["teacher"])
    teacher = teacher.to(device).eval()

    gating_net = DEGNetwork(K=K, teacher_feat_dim=2048,
                             hidden_dim=cfg["deg_hidden_dim"])
    gating_net.load_state_dict(ck["gating_net"])
    gating_net = gating_net.to(device).eval()

    cmrd = CMRDLoss(N=batch_size, L=cfg["L"]).to(device)

    tgt_ds = build_domain_dataset(benchmark, args.data_root, target,
                                   train=False, image_size=image_size)
    _, test_ds = split_70_30(tgt_ds, args.seed)
    test_loader = get_target_loader(test_ds, batch_size=batch_size,
                                    seed=args.seed, num_workers=num_workers,
                                    shuffle=False)

    preds, labels, weights, elapsed, n_samples = run_test(
        base_learners, gating_net, cmrd, teacher, test_loader, tau, device, K
    )

    acc   = top1_accuracy(preds, labels)
    mf1v  = macro_f1(preds, labels) if is_mf1 else None
    src   = get_source_only(args.task)
    bso   = 1 if acc < src else 0
    H_gate = gate_entropy(weights)
    n_params = count_params(list(base_learners) + [gating_net, teacher])

    logger.info(f"Top-1 Accuracy : {acc:.2f}%")
    logger.info(f"Source-Only    : {src:.2f}%")
    logger.info(f"Below source   : {bso}")
    if mf1v is not None:
        logger.info(f"Macro-F1       : {mf1v:.2f}%")
    logger.info(f"Gating entropy : {H_gate:.4f}")
    logger.info(f"Parameters     : {n_params:,}")
    logger.info(f"Throughput     : {n_samples/elapsed:.1f} samples/s")

    per_cls = per_class_accuracy(preds, labels)
    cm      = confusion(preds, labels)
    report  = classification_report_str(preds, labels)
    logger.info("\nPer-class accuracy:\n" +
                "\n".join(f"  {k}: {v:.1f}%" for k, v in per_cls.items()))
    logger.info("\nClassification Report:\n" + report)

    result = {
        "task":                args.task,
        "seed":                args.seed,
        "top1_accuracy":       round(acc, 2),
        "source_only_accuracy": src,
        "below_source_only":   bso,
        "macro_f1":            round(mf1v, 2) if mf1v is not None else None,
        "gating_entropy":      round(H_gate, 4),
        "n_params":            n_params,
        "throughput_samples_per_s": round(n_samples / elapsed, 1),
        "per_class_accuracy":  per_cls,
    }

    if args.out:
        os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
        with open(args.out, "w") as f:
            json.dump(result, f, indent=2)
        logger.info(f"Result written to {args.out}")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
