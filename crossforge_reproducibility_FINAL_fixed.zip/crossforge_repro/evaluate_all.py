"""
CrossForge: Aggregate all per-seed per-task results and generate every paper table.

Reads results/reproduced/per_seed_per_task_results.csv.
Writes: Table 7 (OH), Table 8 (DN+VisDA), Table 9 (Clinical), Table 10 (Ablation),
        Table 11 (NTR).

Usage:
  python evaluate_all.py --csv results/reproduced/per_seed_per_task_results.csv
"""

import argparse
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(__file__))
from src.datasets.dataset import (ALL_TASK_IDS, CLINICAL_TASK_IDS,
                                   DN_TASK_IDS, OH_TASK_IDS)

METHODS   = ["Source Only","SHOT","NRC","AaD","LAME","DaC","G-SFDA","CrossForge"]
BASELINES = ["SHOT","NRC","AaD","LAME","DaC","G-SFDA"]
SEEDS     = [42, 123, 2025]
N_TASKS   = 24


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--csv",  default="results/reproduced/per_seed_per_task_results.csv")
    p.add_argument("--out",  default="results/reproduced/")
    return p.parse_args()


def load(csv_path):
    df = pd.read_csv(csv_path, comment="#")
    df = df[df["seed"].isin(SEEDS)].copy()
    for c in ("top1_accuracy","source_only_accuracy","below_source_only","macro_f1"):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def require_filled(df, tasks, methods=METHODS):
    sub     = df[df["task"].isin(tasks) & df["method"].isin(methods)]
    missing = sub[sub["top1_accuracy"].isna()]
    expected = len(tasks) * len(methods) * len(SEEDS)
    if len(sub) < expected or len(missing):
        n_bad = (expected - len(sub)) + len(missing)
        miss_sample = missing[["method","seed","task"]].head(3).values.tolist()
        print(f"[WARNING] {n_bad}/{expected} rows missing top1_accuracy. "
              f"Sample: {miss_sample}")


def per_task_mean_std(df, tasks, value="top1_accuracy"):
    g = df[df["task"].isin(tasks)].groupby(["method","task"])[value]
    return (g.mean().unstack("task").reindex(columns=tasks),
            g.std(ddof=1).unstack("task").reindex(columns=tasks))


def benchmark_avg(df, tasks):
    mean, _ = per_task_mean_std(df, tasks)
    return mean.mean(axis=1)


def build_table7(df, out_dir):
    tasks = OH_TASK_IDS
    require_filled(df, tasks)
    mean, std = per_task_mean_std(df, tasks)
    mean["Avg."] = mean.mean(axis=1)
    mean.round(1).to_csv(os.path.join(out_dir, "table7_office_home.csv"))
    std.round(2).to_csv(os.path.join(out_dir, "table7_office_home_std.csv"))
    print("\n=== Table 7: Office-Home ===")
    print(mean.round(1).to_string())
    best = mean["Avg."][BASELINES].idxmax()
    gain = mean.loc["CrossForge","Avg."] - mean.loc[best,"Avg."]
    print(f"CrossForge gain over best baseline ({best}): {gain:+.1f}%")


def build_table8(df, out_dir):
    dn_avg  = benchmark_avg(df, DN_TASK_IDS)
    vda_avg = benchmark_avg(df, ["VisDA"])
    t8 = pd.DataFrame({"DomainNet-126 Avg": dn_avg, "VisDA-C": vda_avg})
    t8.round(1).to_csv(os.path.join(out_dir, "table8_dn_visda.csv"))
    print("\n=== Table 8: DomainNet-126 & VisDA-C ===")
    print(t8.round(1).to_string())


def build_table9(df, out_dir):
    tasks = CLINICAL_TASK_IDS
    require_filled(df, tasks)
    mean, _ = per_task_mean_std(df, tasks)
    mean["Avg."] = mean.mean(axis=1)
    mean.round(1).to_csv(os.path.join(out_dir, "table9_clinical.csv"))
    # Macro-F1 for C2 and C4
    f1_tasks = ["C2_CheXpert","C4_ISIC"]
    f1_df = df[df["task"].isin(f1_tasks)]
    if f1_df["macro_f1"].isna().any():
        print("[WARNING] macro_f1 incomplete for C2/C4. "
              "Run test.py with --task C2_CheXpert / C4_ISIC.")
    else:
        g = f1_df.groupby(["method","task"])["macro_f1"].agg(["mean","std"])
        tab = g.apply(lambda r: f"{r['mean']:.1f}±{r['std']:.1f}", axis=1
                      ).unstack("task").reindex(METHODS)
        tab.to_csv(os.path.join(out_dir, "table9_macro_f1.csv"))
        print("\nMacro-F1 (mean±std):\n" + tab.to_string())
    print("\n=== Table 9: Clinical ===")
    print(mean.round(1).to_string())


def build_table10(df, out_dir):
    ablations = ["full","no_cmrd","no_deg","no_ecl","no_cmrd_deg","shot_gate"]
    method_map = {a: ("CrossForge" if a == "full" else f"CrossForge_{a}")
                  for a in ablations}
    rows = {}
    for abl, mname in method_map.items():
        sub = df[df["method"] == mname]
        if sub.empty:
            continue
        oh_avg = sub[sub["task"].isin(OH_TASK_IDS)].groupby("seed")["top1_accuracy"].mean()
        rows[abl] = {"OH_Avg_mean": oh_avg.mean(), "OH_Avg_std": oh_avg.std(ddof=1)}
    t10 = pd.DataFrame(rows).T
    t10.round(2).to_csv(os.path.join(out_dir, "table10_ablation.csv"))
    print("\n=== Table 10: Ablation ===")
    print(t10.round(2).to_string())


def build_table11(df, out_dir):
    """NTR per method per seed (integer counts / 24, and mean %)."""
    need = df[df["method"].isin(BASELINES + ["CrossForge"])]
    cnt  = need.groupby(["method","seed"])["below_source_only"].sum().unstack("seed")
    cnt["mean_NTR_pct"] = cnt.mean(axis=1) / N_TASKS * 100
    cnt.round(2).to_csv(os.path.join(out_dir, "table11_ntr.csv"))
    print("\n=== Table 11: NTR ===")
    print(cnt.round(2).to_string())


def main():
    args = parse_args()
    os.makedirs(args.out, exist_ok=True)

    if not os.path.exists(args.csv):
        print(f"Results CSV not found: {args.csv}")
        print("Run train.py for all tasks, seeds, and methods first.")
        return

    df = load(args.csv)
    build_table7(df, args.out)
    build_table8(df, args.out)
    build_table9(df, args.out)
    build_table10(df, args.out)
    build_table11(df, args.out)
    print(f"\nAll tables written to {args.out}")


if __name__ == "__main__":
    main()
