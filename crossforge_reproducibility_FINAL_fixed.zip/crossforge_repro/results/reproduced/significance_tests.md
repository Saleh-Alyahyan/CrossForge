# CrossForge Significance Tests

> **NOTE — generation blocked by missing heavy dependencies (torch/torchvision)
> in this environment.** This file was written directly rather than via
> `scripts/update_significance_tests.py`, because that script imports
> `src/datasets/dataset.py`, which requires `torch`/`torchvision` to be
> installed. Run `python scripts/update_significance_tests.py` yourself in an
> environment with the full `requirements.txt` installed to regenerate this
> file mechanically from `results/reproduced/per_seed_per_task_results.csv`.

## 1. NTR derivation (paper-reported values — Table 11, current manuscript)

This section reproduces the verified, internally-consistent NTR derivation
confirmed against the manuscript (Table 11, Abstract, Discussion, Conclusion
all consistent as of the current revision). These are the published figures,
not values computed from this package's synthetic placeholder data (see
Section 2).

| Method | Seed 42 count/24 | Seed 123 count/24 | Seed 2025 count/24 | Mean NTR |
|---|---|---|---|---|
| SHOT | 3/24 (12.50%) | 1/24 (4.17%) | 3/24 (12.50%) | **9.72%** |
| NRC | 2/24 (8.33%) | 1/24 (4.17%) | 2/24 (8.33%) | **6.94%** |
| AaD | 2/24 (8.33%) | 1/24 (4.17%) | 1/24 (4.17%) | **5.56%** |
| LAME | 3/24 (12.50%) | 2/24 (8.33%) | 3/24 (12.50%) | **11.11%** |
| DaC | 2/24 (8.33%) | 2/24 (8.33%) | 2/24 (8.33%) | **8.33%** |
| G-SFDA | 2/24 (8.33%) | 1/24 (4.17%) | 2/24 (8.33%) | **6.94%** |
| CrossForge | 1/24 (4.17%) | 1/24 (4.17%) | 1/24 (4.17%) | **4.17%** |

Reduction vs. DaC: (8.33 − 4.17) / 8.33 = **49.8%**
Reduction vs. SHOT: (9.72 − 4.17) / 9.72 = **57.1%**

Bonferroni-corrected significance threshold for the 12 × 6 Office-Home
pairwise comparisons: 0.05 / 72 ≈ 0.0007.

## 2. Bootstrap / macro-F1 blocks — NOT YET AVAILABLE

The paired-bootstrap confidence intervals and the macro-F1 mean ± std table
cannot be honestly populated yet. `results/reproduced/per_seed_per_task_results.csv`
currently contains **synthetic placeholder data** generated to exercise the
pipeline, not real experimental output (no base learners have been trained —
see `checkpoints/README.md`). Running the comparison script
(`compare_results.py`) against this synthetic data shows deviations of up to
~14% from the published paper values, and the per-seed NTR counts implied by
this synthetic data (CrossForge 5.56%, G-SFDA 8.33%) do **not** match Section 1
above. This is expected for synthetic data and is not a new numerical claim
about the paper — it simply means Section 2 cannot be filled in from this data
without being misleading.

**To complete this section:** run `pretrain_source.py` →
`scripts/run_main.sh` (real adaptation) → `scripts/collect_logs.py` →
`scripts/update_significance_tests.py`. The resulting bootstrap CIs and
macro-F1 values should then be checked against Section 1 and
`results/expected/table_means_reference.csv` using `compare_results.py`
before being reported anywhere.
