# CrossForge: Source-Free Cross-Domain Knowledge Bridging for Ensemble Models via Relational Feature Alignment

**IEEE Access** · Official Reproducibility Package

---

> ### ⚠️ Current package status
> - `checkpoints/` contains **placeholder files only** (correct names, shapes,
>   and verified SHA-256 hashes, but no trained weights — see
>   `checkpoints/README.md`). Real weights are pending upload to Zenodo.
> - `results/reproduced/` currently contains **synthetic placeholder data**
>   used to test the pipeline end-to-end, **not real experimental output**.
>   Running `python compare_results.py` against `results/expected/` will
>   correctly flag large deviations from the paper for this reason — that is
>   expected and does not indicate a bug.
> - `results/expected/table_means_reference.csv` and
>   `results/reproduced/significance_tests.md` §1 contain the actual
>   paper-reported values and are safe to cite; `results/reproduced/*.csv`
>   and `significance_tests.md` §2 are not, until real runs replace them.

---

## Citation

```bibtex
@article{crossforge2025,
  title   = {Source-Free Cross-Domain Knowledge Bridging for Ensemble Models
             via Relational Feature Alignment},
  journal = {IEEE Access},
  year    = {2025},
  note    = {DOI: [UNVERIFIED — to be filled on publication]}
}
```

---

## Bug Fixes Applied vs Submitted Repository

| ID | Bug | File Fixed |
|----|-----|-----------|
| FIX-1 | `StratifiedPseudoLabelSampler` imported but never called; plain shuffle used instead of stratified batch sampling (Table 6) | `train.py`, `src/datasets/dataset.py` |
| FIX-2 | `get_teacher_final_features()` wrapped in `torch.no_grad()` unconditionally, silently cutting gradients on the encoder-update path | `src/models/model.py` |
| FIX-3 | `proximity_scores()` called before `forward()` in the same iteration — alpha not yet updated | `train.py` |
| FIX-4 | `ECLLoss._cluster_ids` had no `None` guard; `AttributeError` if `kmeans_update_freq != 5` | `src/losses/ecl_loss.py` |
| FIX-5 | `domainnet126_classes.txt` missing caused silent fallback to all classes | `src/datasets/dataset.py` |
| FIX-6 | Checkpoint `FileNotFoundError` message was generic; now explicit with instructions | `src/utils/utils.py` |

---

## Environment Setup

```bash
conda env create -f environment.yml
conda activate crossforge
# or
pip install -r requirements.txt
```

Set deterministic CUDA ops:
```bash
export CUBLAS_WORKSPACE_CONFIG=:4096:8
```

---

## Dataset Download

| Dataset | Download |
|---------|----------|
| Office-Home | https://hemanthdv.org/officeHomeDataset/ |
| DomainNet-126 | http://ai.bu.edu/M3SDA/ (use 126-class protocol) |
| VisDA-C 2017 | https://github.com/VisionLearningGroup/taskcv-2017-public |
| REFUGE | https://refuge.grand-challenge.org/ |
| CheXpert | https://stanfordmlgroup.github.io/competitions/chexpert/ |
| CHAOS | https://chaos.grand-challenge.org/ |
| ISIC 2018 | https://challenge.isic-archive.com/landing/2018/ |

Organize datasets under one root directory:
```
/data/crossforge_datasets/
  OfficeHome/        Art/  Clipart/  Product/  Real_World/
  DomainNet126/      real/  clipart/  painting/  sketch/
  VisDA-C/           train/  validation/
  Clinical/
    refuge_source/   refuge_target/
    chexpert_source/ chexpert_target/
    chaos_source/    chaos_target/
    isic_source/     isic_target/
```

Each split folder: `<domain>/<class>/<image.jpg>`

DomainNet-126 class list: `src/datasets/domainnet126_classes.txt` (bundled).

---

## One-Command Full Reproduction

```bash
bash scripts/run_all.sh --data_root /data/crossforge_datasets
```

Expected total runtime: ~60 hours on a single A100 40GB GPU.

---

## Step-by-Step Commands

### 1. Initialize results CSV skeleton

```bash
python scripts/collect_logs.py --init \
    --csv results/reproduced/per_seed_per_task_results.csv
```

### 2. Source pre-training (K=5 learners per domain, 3 seeds)

```bash
bash scripts/run_pretrain.sh --data_root /data/crossforge_datasets
```

### 3. CrossForge adaptation (all 24 tasks × 3 seeds)

```bash
bash scripts/run_main.sh --data_root /data/crossforge_datasets
```

### 4. Ablation study (Table 10)

```bash
bash scripts/run_ablation.sh --data_root /data/crossforge_datasets
```

### 5. Aggregate results

```bash
python evaluate_all.py
```

### 6. Compare against paper

```bash
python compare_results.py --tol 0.1
```

### 7. Generate figures

```bash
python figures/make_figures.py
```

---

## Per-Experiment Commands

**Single task, single seed:**
```bash
# Pre-train
python pretrain_source.py --config configs/office_home.yaml \
    --data_root /data/crossforge_datasets/OfficeHome \
    --source Art --seed 42

# Adapt
python train.py --config configs/office_home.yaml \
    --task OH_Ar_Cl --seed 42 \
    --data_root /data/crossforge_datasets/OfficeHome

# Test
python test.py \
    --checkpoint checkpoints/crossforge_office_home_OH_Ar_Cl_full_seed42.pt \
    --config configs/office_home.yaml --task OH_Ar_Cl --seed 42 \
    --data_root /data/crossforge_datasets/OfficeHome
```

**Ablation variant:**
```bash
python train.py --config configs/office_home.yaml \
    --task OH_Ar_Cl --seed 42 --ablation no_cmrd \
    --data_root /data/crossforge_datasets/OfficeHome
```

---

## Expected Runtime per Experiment (A100 40GB)

| Step | Time |
|------|------|
| Source pre-training (1 domain, 1 seed) | ~20 min |
| Source pre-training (all domains, all seeds) | ~8 h |
| CrossForge adaptation (1 task, 1 seed) | ~25 min |
| CrossForge adaptation (all 24 tasks, 3 seeds) | ~30 h |
| Ablation (all OH tasks, 5 variants, 3 seeds) | ~18 h |
| Evaluate + figures | ~5 min |
| **Total** | **~56 h** |

---

## Paper Table / Figure → Script Mapping

| Paper Output | Script |
|-------------|--------|
| Table 7 (Office-Home) | `evaluate_all.py` → `results/reproduced/table7_office_home.csv` |
| Table 8 (DomainNet + VisDA) | `evaluate_all.py` → `results/reproduced/table8_dn_visda.csv` |
| Table 9 (Clinical) | `evaluate_all.py` → `results/reproduced/table9_clinical.csv` |
| Table 10 (Ablation) | `evaluate_all.py` → `results/reproduced/table10_ablation.csv` |
| Table 11 (NTR) | `evaluate_all.py` → `results/reproduced/table11_ntr.csv` |
| Figure (per-task OH) | `figures/make_figures.py` → `figures/fig_office_home_per_task.pdf` |
| Figure (benchmark avg) | `figures/make_figures.py` → `figures/fig_benchmark_avg.pdf` |
| Figure (ablation) | `figures/make_figures.py` → `figures/fig_ablation.pdf` |
| Figure (NTR) | `figures/make_figures.py` → `figures/fig_ntr.pdf` |

---

## DomainNet-126 Source-Only Per-Task Values

The paper reports only a 7-task average (31.2%) for Source-Only on DomainNet-126 (Table 8). Per-task values are needed to compute `below_source_only` flags for individual DN tasks.

After running Source-Only on DomainNet-126, write measured per-task accuracies to:
```
logs/source_only_per_task.json
```
Example:
```json
{"DN_Re_Cl": 30.1, "DN_Re_Pa": 28.9, "DN_Cl_Pa": 31.4,
 "DN_Pa_Cl": 32.2, "DN_Cl_Sk": 29.7, "DN_Pa_Sk": 30.8, "DN_Sk_Re": 35.3}
```
`collect_logs.py` reads this file automatically.

---

## Checkpoint Download

Pre-trained checkpoints are **not yet publicly released** (pending camera-ready upload). Once released, download with:
```bash
python checkpoints/download_checkpoints.py
```
SHA-256 hashes will be verified automatically. Until release, you must run `pretrain_source.py` to generate checkpoints locally.

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| `FileNotFoundError: domainnet126_classes.txt` | File is in `src/datasets/`; check that the repo was cloned fully |
| `KeyError: No source-only accuracy for DN_*` | Create `logs/source_only_per_task.json` with your Source-Only run results |
| `FileNotFoundError: Checkpoint not found` | Run `pretrain_source.py` first for the relevant benchmark and source domain |
| `RuntimeError: ECLLoss._cluster_ids is None` | Set `kmeans_update_freq` to a value that divides into iteration 0 (any value is fine) |
| CUDA OOM with batch_size=64 | The N×N CMRD matrices require ~40GB for N=64. Reduce to N=32 in config and add `--random_proj True` (reduces memory ~4× with <0.5% accuracy drop per paper) |
| Non-deterministic results between runs | Set `export CUBLAS_WORKSPACE_CONFIG=:4096:8` before running |

---

## Running Tests

```bash
pytest tests/test_crossforge.py -v
```

All 13 tests should pass without a GPU (CPU-only mode).
