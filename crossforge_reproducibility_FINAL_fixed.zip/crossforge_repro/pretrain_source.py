"""
CrossForge: Base-learner source pre-training.

K=5 ResNet-50 learners, each fine-tuned on 1/K of the source domain
(non-overlapping class-balanced partitions, Table 6).

SGD lr=1e-2, momentum=0.9, weight decay=1e-4, cosine schedule, 60 epochs.
Output: checkpoints/<benchmark>_<source>_learner<k>_seed<seed>.pt

Must be run before train.py. Run once per (benchmark, source, seed) combination.

Example:
  python pretrain_source.py --config configs/office_home.yaml \\
      --data_root /data/OfficeHome --source Art --seed 42
"""

import argparse
import os
import sys

import torch
import torch.nn as nn
import torch.optim as optim
import yaml
from torch.utils.data import DataLoader

sys.path.insert(0, os.path.dirname(__file__))
from src.datasets.dataset import build_domain_dataset, get_source_partitions, split_70_30
from src.models.model import BaseLearner
from src.utils.utils import save_checkpoint, set_seed, setup_logger


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--config",         required=True)
    p.add_argument("--data_root",      required=True)
    p.add_argument("--source",         required=True)
    p.add_argument("--seed",           type=int, default=42, choices=[42, 123, 2025])
    p.add_argument("--checkpoint_dir", default="checkpoints/")
    p.add_argument("--device",         default="cuda")
    return p.parse_args()


def main():
    args = parse_args()
    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    benchmark   = cfg["benchmark"]
    K           = cfg["K"]
    num_classes = cfg.get("num_classes", 65)
    epochs      = cfg["pretrain_epochs"]
    batch_size  = cfg["pretrain_batch"]
    lr          = cfg["pretrain_lr"]
    num_workers = cfg["num_workers"]
    image_size  = cfg["image_size"]

    set_seed(args.seed)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    logger = setup_logger("pretrain")
    os.makedirs(args.checkpoint_dir, exist_ok=True)

    full_ds = build_domain_dataset(benchmark, args.data_root, args.source,
                                    train=True, image_size=image_size)
    src_train, _ = split_70_30(full_ds, args.seed)   # 70% used for pre-training

    # Adapter: get_source_partitions expects .samples on the full dataset;
    # we partition the 70% subset indices into K class-balanced chunks.
    class _SubAdapter:
        samples = [full_ds.samples[i] for i in src_train.indices]

    partitions = get_source_partitions(_SubAdapter, K, args.seed)

    for k, part in enumerate(partitions):
        # Map partition indices back to full_ds indices
        real_idxs = [src_train.indices[i] for i in part.indices]
        subset = torch.utils.data.Subset(full_ds, real_idxs)
        loader = DataLoader(subset, batch_size=batch_size, shuffle=True,
                            num_workers=num_workers, drop_last=True)

        model = BaseLearner(num_classes=num_classes, pretrained=True).to(device)
        opt   = optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=1e-4)
        sched = optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
        ce    = nn.CrossEntropyLoss()

        logger.info(f"Learner {k+1}/{K}: {len(subset)} samples, {epochs} epochs")
        for ep in range(epochs):
            model.train()
            total, correct = 0, 0
            for x, y in loader:
                x, y = x.to(device), y.to(device)
                opt.zero_grad()
                logits, _ = model(x)
                loss = ce(logits, y)
                loss.backward()
                opt.step()
                total += y.size(0)
                correct += (logits.argmax(1) == y).sum().item()
            sched.step()
            if (ep + 1) % 10 == 0:
                logger.info(f"  Epoch {ep+1}/{epochs}  acc={100*correct/total:.1f}%")

        ck_path = os.path.join(
            args.checkpoint_dir,
            f"{benchmark}_{args.source}_learner{k+1}_seed{args.seed}.pt",
        )
        save_checkpoint(model.state_dict(), ck_path)
        logger.info(f"  Saved → {ck_path}")


if __name__ == "__main__":
    main()
