"""
CrossForge: Unit tests.

Tests: data pipeline shapes, model forward pass, loss correctness,
       metric formulas, dataset splitting, StratifiedPseudoLabelSampler.

Run: pytest tests/test_crossforge.py -v
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
import pytest
import torch
import torch.nn as nn


# ---- Model tests -------------------------------------------------------

def test_base_learner_output_shapes():
    from src.models.model import BaseLearner
    model = BaseLearner(num_classes=65, pretrained=False)
    x = torch.randn(4, 3, 224, 224)
    logits, feats = model(x, return_intermediate=True)
    assert logits.shape == (4, 65)
    assert len(feats) == 4
    # blocks 1-4 spatial dims for ResNet-50
    assert feats[0].shape[1] == 256   # block1 channels
    assert feats[3].shape[1] == 2048  # block4 channels


def test_build_ensemble():
    from src.models.model import build_ensemble
    ens = build_ensemble(num_classes=12, K=5, pretrained=False)
    assert len(ens) == 5
    x = torch.randn(2, 3, 224, 224)
    for bl in ens:
        logits, _ = bl(x)
        assert logits.shape == (2, 12)


def test_ema_teacher_init():
    from src.models.model import build_ensemble, build_ema_teacher
    ens = build_ensemble(65, K=3, pretrained=False)
    teacher = build_ema_teacher(ens, beta=0.999)
    # Teacher weights should be average of learner weights
    key = "classifier.weight"
    expected = sum(bl.state_dict()[key] for bl in ens) / 3
    actual   = teacher.state_dict()[key]
    assert torch.allclose(expected, actual, atol=1e-5)


def test_deg_network_simplex():
    from src.models.deg_network import DEGNetwork
    K = 5; N = 8; d = 2048
    net = DEGNetwork(K=K, teacher_feat_dim=d)
    rho  = torch.rand(N, K)
    feat = torch.randn(N, d)
    w = net(rho, feat, stop_grad_teacher=True)
    assert w.shape == (N, K)
    # Simplex constraint: rows sum to 1
    assert torch.allclose(w.sum(dim=1), torch.ones(N), atol=1e-5)
    # All weights positive
    assert (w >= 0).all()


def test_ensemble_prediction_shape():
    from src.models.model import build_ensemble
    from src.models.deg_network import ensemble_prediction
    ens = build_ensemble(12, K=3, pretrained=False)
    x = torch.randn(4, 3, 224, 224)
    w = torch.softmax(torch.randn(4, 3), dim=1)
    y_hat = ensemble_prediction(ens, w, x, tau=0.05)
    assert y_hat.shape == (4, 12)
    # Should sum to ~1 per sample (softmax ensemble)
    assert torch.allclose(y_hat.sum(dim=1), torch.ones(4), atol=1e-4)


# ---- Loss tests --------------------------------------------------------

def test_cmrd_loss_positive():
    from src.losses.cmrd_loss import CMRDLoss
    K, L, N, d = 3, 4, 8, 64
    loss_fn = CMRDLoss(N=N, L=L)
    lf = [[torch.randn(N, d) for _ in range(L)] for _ in range(K)]
    tf = [torch.randn(N, d) for _ in range(L)]
    loss = loss_fn(lf, tf)
    assert loss.item() >= 0


def test_cmrd_proximity_scores_range():
    from src.losses.cmrd_loss import CMRDLoss
    K, L, N = 3, 4, 8
    loss_fn = CMRDLoss(N=N, L=L)
    lf = [[torch.randn(N, 64) for _ in range(L)] for _ in range(K)]
    tf = [torch.randn(N, 64) for _ in range(L)]
    rho = loss_fn.proximity_scores(lf, tf)
    assert rho.shape == (K, N)
    assert (rho > 0).all() and (rho <= 1.0 + 1e-5).all()


def test_ecl_loss_no_crash_default():
    from src.losses.ecl_loss import ECLLoss
    K, N = 5, 16
    loss_fn = ECLLoss(K=K, M=4, kmeans_update_freq=5)
    W    = torch.softmax(torch.randn(N, K), dim=1)
    feat = torch.randn(N, 2048)
    loss = loss_fn(W, feat)   # first call triggers cluster update (iter 0 % 5 == 0)
    assert loss.item() == loss.item()   # not NaN


def test_ecl_loss_none_guard():
    """Ensure None guard raises before first cluster update when freq != 0."""
    from src.losses.ecl_loss import ECLLoss
    loss_fn = ECLLoss(K=5, M=4, kmeans_update_freq=10)
    loss_fn._iter = 1   # skip iter 0 so cluster update won't happen
    W    = torch.softmax(torch.randn(8, 5), dim=1)
    feat = torch.randn(8, 2048)
    with pytest.raises(RuntimeError, match="_cluster_ids is None"):
        loss_fn(W, feat)


def test_im_loss():
    from src.losses.im_loss import IMLoss
    N, C = 16, 65
    loss_fn = IMLoss()
    y_hat = torch.softmax(torch.randn(N, C), dim=1)
    loss = loss_fn(y_hat)
    assert loss.item() == loss.item()   # not NaN


# ---- Metric tests ------------------------------------------------------

def test_top1_accuracy():
    from src.metrics.metrics import top1_accuracy
    preds  = np.array([0, 1, 2, 3])
    labels = np.array([0, 1, 0, 3])
    assert top1_accuracy(preds, labels) == pytest.approx(75.0)


def test_macro_f1_balanced():
    from src.metrics.metrics import macro_f1
    # Perfect predictions → macro-F1 = 100
    labels = np.array([0,0,1,1,2,2])
    assert macro_f1(labels, labels) == pytest.approx(100.0)


def test_gate_entropy_uniform():
    from src.metrics.metrics import gate_entropy
    K = 5; N = 10
    W = torch.full((N, K), 1.0 / K)
    H = gate_entropy(W)
    import math
    assert abs(H - math.log(K)) < 0.01


# ---- Dataset tests -----------------------------------------------------

def test_split_70_30():
    from src.datasets.dataset import split_70_30
    from torch.utils.data import TensorDataset
    ds = TensorDataset(torch.randn(100, 3), torch.zeros(100, dtype=torch.long))
    train, test = split_70_30(ds, seed=42)
    assert len(train) == 70
    assert len(test)  == 30
    # Check determinism
    train2, test2 = split_70_30(ds, seed=42)
    assert list(train.indices) == list(train2.indices)


def test_stratified_sampler_length():
    from src.datasets.dataset import StratifiedPseudoLabelSampler
    N = 100; C = 5; bs = 50
    pseudo = np.random.randint(0, C, size=N)
    sampler = StratifiedPseudoLabelSampler(pseudo, batch_size=bs, num_classes=C)
    assert len(sampler) == bs


def test_stratified_sampler_iter():
    from src.datasets.dataset import StratifiedPseudoLabelSampler
    N = 200; C = 4; bs = 64
    pseudo = np.tile(np.arange(C), N // C)
    sampler = StratifiedPseudoLabelSampler(pseudo, batch_size=bs, num_classes=C)
    batch = list(sampler)
    assert len(batch) == bs
    assert all(0 <= i < N for i in batch)


def test_dn126_class_file_missing_raises():
    """domainnet126_classes.txt missing must raise FileNotFoundError."""
    import importlib, types
    from src.datasets import dataset as ds_mod
    orig = ds_mod._dn126_class_names
    # Temporarily patch to simulate missing file
    def _missing():
        raise FileNotFoundError("domainnet126_classes.txt not found: /fake/path")
    ds_mod._dn126_class_names = _missing
    with pytest.raises(FileNotFoundError, match="domainnet126_classes.txt"):
        ds_mod.build_domain_dataset("domainnet126", "/data", "real")
    ds_mod._dn126_class_names = orig
