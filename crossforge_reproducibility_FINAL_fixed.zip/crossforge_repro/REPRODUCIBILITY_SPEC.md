# CrossForge — Reproducibility Specification

## Paper
**Title:** Source-Free Cross-Domain Knowledge Bridging for Ensemble Models via Relational Feature Alignment  
**Venue:** IEEE Access  
**Modules:** CMRD · DEG · ECL  

---

## 1. Datasets

| ID | Name | Official Source | License | Samples | Classes | Split |
|----|------|----------------|---------|---------|---------|-------|
| OH | Office-Home | https://hemanthdv.org/officeHomeDataset/ | Research only | 15,588 | 65 | 70% adapt / 30% test per target domain (paper Table 5) |
| DN | DomainNet-126 | http://ai.bu.edu/M3SDA/ (126-class subset per Saito et al. ECCV 2019) | Research only | ~180k | 126 | 70% adapt / 30% test per target domain (paper Table 5) |
| VisDA-C | VisDA-C 2017 | https://github.com/VisionLearningGroup/taskcv-2017-public | MIT | 207k (train synth) + 55k (val real) | 12 | train=synthetic source, val=real target |
| C1 | REFUGE | https://refuge.grand-challenge.org/ | CC BY 4.0 | 1,200 | 2 | 70/30 per paper |
| C2 | CheXpert | https://stanfordmlgroup.github.io/competitions/chexpert/ | Stanford DUA | 224,316 | 5 | 70/30 per paper |
| C3 | CHAOS | https://chaos.grand-challenge.org/ | CC BY 4.0 | 1,694 | 4 | 70/30 per paper |
| C4 | ISIC 2018 | https://challenge.isic-archive.com/landing/2018/ | CC BY-NC 4.0 | 10,015 | 7 | 70/30 per paper |

**Split rule (paper Table 5):** 70% of target domain used for adaptation (unlabeled), 30% held out as test set. Source domain: 70% for pre-training, 30% discarded. Partitioned deterministically with `random.Random(seed).shuffle`.

**DomainNet-126 class file:** The 126-class subset is defined by `crossforge/data/domainnet126_classes.txt` (included in this repo). Tasks: 7-task protocol of Dayal et al. ECCV 2024.

---

## 2. Model Architecture

### Base Learner (K=5, ResNet-50)
- Blocks 1–4 extracted as intermediate features (L=4 layers)
- Block 5 / avgpool / FC excluded from intermediate extraction
- Classifier head: Linear(2048, num_classes), **frozen throughout adaptation**
- BN layers: running statistics **frozen** during adaptation (eval mode)

### EMA Teacher
- Equation 7: f_T ← β·f_T + (1−β)·(1/K)·Σ_k f_k; β=0.999
- Initialized as uniform average of K source-pretrained learner weights
- Updated **after** encoder gradient step each iteration

### CMRD Loss (Eq. 3–10)
- L2-normalize features; pairwise cosine similarity matrices S_k^l, S_T^l ∈ R^{N×N}
- Off-diagonal entries only (N(N−1) pairs)
- Learned layer importance α (softmax over raw α_raw, L=4), initialized uniform
- Domain alignment MLP φ: Linear(N²,256) → ReLU → Linear(256,N²)
- Proximity scores ρ_{k,j} = exp(−Σ_l α_l · Σ_{i≠j} |S_k^l_{ji} − S_T^l_{ji}|)

### DEG Network (Eq. 11–12)
- Input: [ρ_1,j…ρ_K,j; f_T^L(x_j)] = [K + 2048] dimensional
- MLP: Linear(K+2048, 256) → ReLU → Linear(256, K) → Softmax
- stop_grad applied to teacher features during Algorithm 2 gating update
- Output: w_j ∈ Δ^{K−1} (simplex-constrained)

### Ensemble Prediction (Eq. 5)
- ŷ(x) = Σ_k w_k(x) · softmax(g_k(f_k(x)) / τ); τ=0.05

### ECL Loss (Eq. 14–16)
- H_gate = −(1/N)Σ_j Σ_k w_{k,j} log w_{k,j}
- H_gate^m = −Σ_k w_k^m log w_k^m; w_k^m = mean over cluster m
- L_ECL = −(1/M)Σ_m H_gate^m + α_ECL · max(H_min − H_gate, 0)
- H_min = 0.5·log(K) = 0.805 for K=5; α_ECL=1.0; M=8 K-means clusters
- K-means updated every 5 iterations; k-means++ init; empty cluster → largest cluster centroid

### IM Loss (Eq. 13)
- L_IM = −H(ȳ) + (1/N)Σ_j H(y_j); ȳ = batch-mean prediction

---

## 3. Hyperparameters (Table 6)

| Parameter | Value |
|-----------|-------|
| Backbone | ResNet-50 (ImageNet pre-trained) |
| K (base learners) | 5 |
| L (layers) | 4 |
| τ (temperature) | 0.05 |
| β (EMA momentum) | 0.999 |
| Batch size N | 64 |
| Epochs T | 30 |
| Encoder optimizer | SGD, momentum=0.9, weight decay=1e-4, lr=5e-3 |
| LR schedule | CosineAnnealingLR(T_max=T) |
| Gating optimizer | Adam, lr=1e-4 |
| λ1 / λ2 / λ3 | 1.0 / 0.5 / 0.3 |
| M (clusters) | 8 |
| Seeds | 42, 123, 2025 |
| Batch sampling | Stratified by pseudo-label |
| Source pre-train lr | 1e-2, SGD, momentum=0.9, weight decay=1e-4, cosine, 60 epochs |
| Source pre-train batch | 64 |

**[NOT STATED IN PAPER]** Number of workers for DataLoader: using 4 (standard practice).  
**[NOT STATED IN PAPER]** Image resolution: using 224×224 (ResNet-50 standard; VisDA-C uses this).  
**[NOT STATED IN PAPER]** Augmentation for adaptation: RandomResizedCrop(224), RandomHorizontalFlip, ColorJitter(0.4,0.4,0.4) for train; Resize(256)+CenterCrop(224) for test.  
**[NOT STATED IN PAPER]** Source partition method: K non-overlapping class-balanced partitions (1/K each).  

---

## 4. Hardware and Software

| Item | Value |
|------|-------|
| GPU | [NOT STATED IN PAPER] — using A100 40GB as default |
| Framework | PyTorch 2.1.0, torchvision 0.16.0 |
| CUDA | [NOT STATED IN PAPER] — using 11.8 |
| Python | 3.10 |

---

## 5. Evaluation Metrics

| Metric | Formula | Tasks |
|--------|---------|-------|
| Top-1 Accuracy | (correct/total)×100 | All |
| Macro-F1 | sklearn f1_score(average='macro')×100 | C2, C4 only |
| NTR | (tasks below source-only / 24) × 100 | All methods |
| Gating entropy H_gate | −(1/N)Σ_j Σ_k w_{k,j} log w_{k,j} | Analysis |

Averaged over 3 seeds (42, 123, 2025). Tables report mean; std reported alongside.  
NTR denominator = 24 total tasks.

---

## 6. Baselines

| Method | Source |
|--------|--------|
| Source Only | No adaptation |
| SHOT | Liang et al. ICML 2020 |
| NRC | Yang et al. NeurIPS 2021 |
| AaD | Yang et al. ECCV 2022 |
| LAME | Boudiaf et al. CVPR 2022 |
| DaC | Zhang et al. CVPR 2023 |
| G-SFDA | Yang et al. ICCV 2021 |
| SHOT+Gate | SHOT encoder with CrossForge DEG gating (Table 8 ablation) |

---

## 7. Ablation Variants (Table 10)

| Variant | Change |
|---------|--------|
| full | Complete CrossForge |
| no_cmrd | Replace CMRD with raw feature regression to teacher |
| no_deg | Uniform gating weights (no DEG) |
| no_ecl | Remove ECL loss (set to 0) |
| no_cmrd_deg | Both CMRD and DEG removed |
| shot_gate | SHOT encoder + CrossForge DEG gating |

---

## 8. Target Numeric Results

All values sourced directly from paper tables. Stored in `results/expected/`.

### Table 7 (Office-Home, mean top-1 over 3 seeds)
CrossForge per-task: Ar→Cl 68.0, Ar→Pr 85.3, Ar→Re 86.4, Cl→Ar 74.8, Cl→Pr 84.7, Cl→Re 84.2, Pr→Ar 73.1, Pr→Cl 62.9, Pr→Re 87.1, Re→Ar 79.5, Re→Cl 66.3, Re→Pr 89.1

### Table 8 (DomainNet-126, VisDA-C averages)
CrossForge: DN 54.2, VisDA 89.8

### Table 9 (Clinical)
CrossForge: C1 84.3, C2 90.2 (macro-F1), C3 81.4, C4 91.7 (macro-F1)

### Table 10 (Ablation, Office-Home Avg)
full 78.5, no_cmrd 74.1, no_deg 74.8, no_ecl 75.9, no_cmrd_deg 71.3, shot_gate 77.1

### NTR (Table 11)
CrossForge: 4.17%; NRC: 6.94%; AaD: 5.56%; G-SFDA: 6.94%; DaC: 8.33%; SHOT: 9.72%; LAME: 11.11%
(reduction vs. DaC: 49.8%; vs. SHOT: 57.1%. See results/reproduced/significance_tests.md §1
for the full per-seed derivation.)
