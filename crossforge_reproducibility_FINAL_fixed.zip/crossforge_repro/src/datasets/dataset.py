"""
CrossForge: Dataset classes for all four benchmarks.

FIX (vs original repo): domainnet126_classes.txt is now bundled in src/datasets/
and its absence raises an explicit error rather than silently including extra classes.

Folder layout expected:  <root>/<domain>/<class>/<image>
Clinical data must be converted to this layout by data/preprocess.py.
"""

import os
import random
from collections import defaultdict
from typing import List, Optional, Tuple

import numpy as np
import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset, Sampler, Subset
from torchvision import transforms

IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD  = [0.229, 0.224, 0.225]

# ---------- task definitions -------------------------------------------

OFFICE_HOME_TASKS = [
    ("Art", "Clipart"), ("Art", "Product"), ("Art", "Real_World"),
    ("Clipart", "Art"), ("Clipart", "Product"), ("Clipart", "Real_World"),
    ("Product", "Art"), ("Product", "Clipart"), ("Product", "Real_World"),
    ("Real_World", "Art"), ("Real_World", "Clipart"), ("Real_World", "Product"),
]

# 7-task protocol (Dayal et al. ECCV 2024)
DOMAINNET_TASKS = [
    ("real", "clipart"), ("real", "painting"), ("clipart", "painting"),
    ("painting", "clipart"), ("clipart", "sketch"), ("painting", "sketch"),
    ("sketch", "real"),
]

OH_TASK_IDS = [
    "OH_Ar_Cl","OH_Ar_Pr","OH_Ar_Re","OH_Cl_Ar","OH_Cl_Pr","OH_Cl_Re",
    "OH_Pr_Ar","OH_Pr_Cl","OH_Pr_Re","OH_Re_Ar","OH_Re_Cl","OH_Re_Pr",
]
DN_TASK_IDS  = ["DN_Re_Cl","DN_Re_Pa","DN_Cl_Pa","DN_Pa_Cl","DN_Cl_Sk","DN_Pa_Sk","DN_Sk_Re"]
CLINICAL_TASK_IDS = ["C1_REFUGE","C2_CheXpert","C3_CHAOS","C4_ISIC"]
ALL_TASK_IDS = OH_TASK_IDS + DN_TASK_IDS + ["VisDA"] + CLINICAL_TASK_IDS  # 24 tasks

CLINICAL_NUM_CLASSES = {"C1_REFUGE": 2, "C2_CheXpert": 5, "C3_CHAOS": 4, "C4_ISIC": 7}

# Source-only reference accuracies (Tables 7–9) used for NTR and below_source_only flag.
# DomainNet-126 per-task values are measured from your own Source-Only runs and written
# to logs/source_only_per_task.json by collect_logs.py.
SOURCE_ONLY_ACCURACY = {
    "OH_Ar_Cl": 46.3, "OH_Ar_Pr": 67.5, "OH_Ar_Re": 75.3,
    "OH_Cl_Ar": 60.5, "OH_Cl_Pr": 65.2, "OH_Cl_Re": 69.4,
    "OH_Pr_Ar": 58.3, "OH_Pr_Cl": 44.2, "OH_Pr_Re": 76.3,
    "OH_Re_Ar": 68.9, "OH_Re_Cl": 50.1, "OH_Re_Pr": 79.6,
    "VisDA": 45.3,
    "C1_REFUGE": 62.3, "C2_CheXpert": 71.1, "C3_CHAOS": 54.2, "C4_ISIC": 75.5,
}

_OVERRIDE_PATH = "logs/source_only_per_task.json"


def get_source_only(task: str) -> float:
    """Return paper-reported source-only accuracy for a task.

    For DomainNet-126 tasks the per-task value is not reported in the paper
    (only a 7-task average of 31.2 is given). Those must come from your own
    Source-Only runs, written to logs/source_only_per_task.json.
    """
    import json
    table = dict(SOURCE_ONLY_ACCURACY)
    if os.path.isfile(_OVERRIDE_PATH):
        with open(_OVERRIDE_PATH) as f:
            table.update(json.load(f))
    if task not in table:
        raise KeyError(
            f"No source-only accuracy for '{task}'. "
            f"For DN_* tasks: run Source-Only, then add to {_OVERRIDE_PATH}."
        )
    return table[task]


# ---------- transforms -------------------------------------------------

def get_transforms(train: bool, image_size: int = 224) -> transforms.Compose:
    if train:
        return transforms.Compose([
            transforms.RandomResizedCrop(image_size),
            transforms.RandomHorizontalFlip(),
            transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4),
            transforms.ToTensor(),
            transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
        ])
    return transforms.Compose([
        transforms.Resize(int(image_size * 256 / 224)),
        transforms.CenterCrop(image_size),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])


# ---------- core dataset -----------------------------------------------

class FolderDataset(Dataset):
    """<root>/<class>/<image> folder layout. Class index = sorted position."""

    EXT = (".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff")

    def __init__(self, root: str, transform=None, class_names: Optional[List[str]] = None):
        if not os.path.isdir(root):
            raise FileNotFoundError(f"Dataset folder not found: {root}")
        self.root = root
        self.transform = transform
        self.classes = class_names or sorted(
            d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d))
        )
        self.class_to_idx = {c: i for i, c in enumerate(self.classes)}
        self.samples: List[Tuple[str, int]] = []
        for c in self.classes:
            cdir = os.path.join(root, c)
            if not os.path.isdir(cdir):
                continue
            for f in sorted(os.listdir(cdir)):
                if f.lower().endswith(self.EXT):
                    self.samples.append((os.path.join(cdir, f), self.class_to_idx[c]))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, i):
        path, y = self.samples[i]
        img = Image.open(path).convert("RGB")
        if self.transform is not None:
            img = self.transform(img)
        return img, y


# ---------- benchmark builders -----------------------------------------

def _dn126_class_names() -> Optional[List[str]]:
    """Load the 126-class list bundled with this repo.

    FIX: Previously the file path was silently ignored if missing, causing the
    loader to use all classes in the folder (which may exceed 126).
    Now raises FileNotFoundError so the user knows what to do.
    """
    cls_file = os.path.join(os.path.dirname(__file__), "domainnet126_classes.txt")
    if not os.path.isfile(cls_file):
        raise FileNotFoundError(
            f"DomainNet-126 class file not found: {cls_file}\n"
            "This file is bundled in src/datasets/domainnet126_classes.txt. "
            "If it is missing, re-clone the repository."
        )
    with open(cls_file) as f:
        return sorted(line.strip() for line in f if line.strip())


def build_domain_dataset(benchmark: str, root: str, domain: str,
                         train: bool = False, image_size: int = 224) -> FolderDataset:
    tf = get_transforms(train, image_size)
    if benchmark == "domainnet126":
        names = _dn126_class_names()          # raises if missing — no silent fallback
        return FolderDataset(os.path.join(root, domain), tf, class_names=names)
    return FolderDataset(os.path.join(root, domain), tf)


# ---------- splits -----------------------------------------------------

def split_70_30(dataset: Dataset, seed: int):
    """Deterministic 70/30 adapt/test split (paper Table 5)."""
    idx = list(range(len(dataset)))
    random.Random(seed).shuffle(idx)
    n = int(0.7 * len(idx))
    return Subset(dataset, idx[:n]), Subset(dataset, idx[n:])


def get_source_partitions(dataset: FolderDataset, k: int, seed: int):
    """K non-overlapping, class-balanced source partitions for base-learner pre-training."""
    rng = random.Random(seed)
    by_class: dict = defaultdict(list)
    for i, (_, y) in enumerate(dataset.samples):
        by_class[y].append(i)
    parts: List[List[int]] = [[] for _ in range(k)]
    for idxs in by_class.values():
        idxs = list(idxs)
        rng.shuffle(idxs)
        for j, i in enumerate(idxs):
            parts[j % k].append(i)
    return [Subset(dataset, p) for p in parts]


# ---------- pseudo-label stratified sampler ----------------------------

class StratifiedPseudoLabelSampler(Sampler):
    """Stratified mini-batch sampling by pseudo-label (paper Table 6).

    Ensures class-balanced batches, reducing sensitivity of the N×N pairwise
    similarity matrices (Eq. 4) to batch class composition.

    FIX (vs original repo): this sampler is now actually used by get_target_loader
    when pseudo_labels are provided, resolving the import-but-never-called bug.
    """

    def __init__(self, pseudo_labels: np.ndarray, batch_size: int, num_classes: int):
        self.batch_size = batch_size
        self.num_classes = num_classes
        self.per_class = max(1, batch_size // num_classes)
        self.class_indices = [
            np.where(pseudo_labels == c)[0].tolist()
            for c in range(num_classes)
        ]

    def __iter__(self):
        batch = []
        for c in range(self.num_classes):
            if not self.class_indices[c]:
                continue
            chosen = np.random.choice(
                self.class_indices[c], size=self.per_class, replace=True
            ).tolist()
            batch.extend(chosen)
        np.random.shuffle(batch)
        return iter(batch)

    def __len__(self):
        return self.batch_size


def get_target_loader(
    dataset: Dataset,
    batch_size: int = 64,
    seed: int = 42,
    num_workers: int = 4,
    pseudo_labels: Optional[np.ndarray] = None,
    num_classes: Optional[int] = None,
    shuffle: bool = True,
) -> DataLoader:
    """Build target DataLoader.

    FIX: When pseudo_labels and num_classes are supplied, uses
    StratifiedPseudoLabelSampler (Table 6) instead of plain shuffle.
    drop_last=True is mandatory — CMRD builds fixed-size N×N matrices.
    """
    g = torch.Generator()
    g.manual_seed(seed)

    if pseudo_labels is not None and num_classes is not None:
        sampler = StratifiedPseudoLabelSampler(pseudo_labels, batch_size, num_classes)
        return DataLoader(
            dataset, batch_sampler=None, sampler=sampler,
            batch_size=batch_size,
            num_workers=num_workers,
            pin_memory=torch.cuda.is_available(),
            drop_last=True,
        )

    return DataLoader(
        dataset, batch_size=batch_size, shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
        drop_last=True,
        generator=g,
    )
