"""
CrossForge: Evaluation metrics.

Top-1 Accuracy: (correct / total) × 100
Macro-F1: sklearn f1_score(average='macro') × 100 — used for C2 (CheXpert) and C4 (ISIC)
NTR: fraction of 24 tasks where method < source-only × 100
Gating entropy: H_gate = −(1/N) Σ_j Σ_k w_{k,j} log w_{k,j}
"""

from typing import Dict, List, Optional

import numpy as np
import torch
from sklearn.metrics import (confusion_matrix, f1_score,
                              classification_report)


def top1_accuracy(preds: np.ndarray, labels: np.ndarray) -> float:
    """(correct / total) × 100."""
    return float((preds == labels).mean() * 100)


def macro_f1(preds: np.ndarray, labels: np.ndarray) -> float:
    """sklearn macro-F1 × 100. Used for C2 and C4 (paper Table 9)."""
    return float(f1_score(labels, preds, average="macro") * 100)


def per_class_accuracy(preds: np.ndarray, labels: np.ndarray,
                        class_names: Optional[List[str]] = None) -> Dict[str, float]:
    """Per-class top-1 accuracy as a dict {class_name: acc%}."""
    classes = sorted(set(labels))
    out = {}
    for c in classes:
        mask = labels == c
        name = class_names[c] if class_names else str(c)
        out[name] = float((preds[mask] == c).mean() * 100)
    return out


def confusion(preds: np.ndarray, labels: np.ndarray) -> np.ndarray:
    return confusion_matrix(labels, preds)


def classification_report_str(preds: np.ndarray, labels: np.ndarray,
                               class_names: Optional[List[str]] = None) -> str:
    return classification_report(labels, preds, target_names=class_names)


def compute_ntr(results_df) -> Dict[str, float]:
    """NTR = (tasks below source-only / 24) × 100 per method.

    results_df must have columns: method, task, top1_accuracy, source_only_accuracy.
    Returns {method: ntr_pct}.
    """
    out = {}
    for method, grp in results_df.groupby("method"):
        if method == "Source Only":
            continue
        n_below = (grp["top1_accuracy"] < grp["source_only_accuracy"]).sum()
        out[method] = float(n_below / 24 * 100)
    return out


def gate_entropy(W: torch.Tensor) -> float:
    """H_gate (Eq. 14) — batch-mean gating entropy. W: [N, K]."""
    eps = 1e-8
    H = -(W * (W + eps).log()).sum(dim=1)
    return float(H.mean().item())
