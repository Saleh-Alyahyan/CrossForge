"""
CrossForge: Ensemble Calibration Loss (ECL).
Equations (14), (15), (16).

Prevents gate collapse (gating network degenerating to single learner).
Promotes diverse learner activation across semantically distinct target subdomains.
M=8 K-means clusters over teacher final-layer features; updated every 5 iterations.

FIX (vs original repo):
  Added explicit None guard on self._cluster_ids before any forward() call.
  If kmeans_update_freq is changed to a value that skips iteration 0, the first
  forward() would previously raise AttributeError. Now raises a clear message.
  Also: _cluster_ids is moved to the correct device inside forward() in a safe way.
"""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.cluster import KMeans


def batch_gate_entropy(W: torch.Tensor) -> torch.Tensor:
    """H_gate (Eq. 14): mean per-sample gating entropy.

    H_gate = −(1/N) Σ_j Σ_k w_{k,j} log w_{k,j}
    H_gate=0 → full collapse; H_gate=log K → uniform.
    W: [N, K] gating weights (rows sum to 1).
    """
    eps = 1e-8
    H = -(W * (W + eps).log()).sum(dim=1)   # [N]
    return H.mean()


def cluster_gate_entropy(W: torch.Tensor,
                          cluster_ids: torch.Tensor,
                          M: int) -> torch.Tensor:
    """H_gate^m per cluster (Eq. 15), averaged over non-empty clusters.

    w_k^m = mean_{j∈B_m} w_{k,j}; H_gate^m = −Σ_k w_k^m log w_k^m
    """
    eps = 1e-8
    entropies = []
    for m in range(M):
        mask = cluster_ids == m
        if mask.sum() == 0:
            continue
        W_m = W[mask].mean(dim=0)                           # [K]
        H_m = -(W_m * (W_m + eps).log()).sum()
        entropies.append(H_m)
    if not entropies:
        return torch.tensor(0.0, device=W.device)
    return torch.stack(entropies).mean()


class ECLLoss(nn.Module):
    """Ensemble Calibration Loss (Eq. 16).

    L_ECL = −(1/M) Σ_m H_gate^m + α_ECL · max(H_min − H_gate, 0)
    H_min = 0.5 · log(K) = 0.805 for K=5.
    """

    def __init__(self, K: int = 5, M: int = 8,
                 alpha_ecl: float = 1.0,
                 kmeans_update_freq: int = 5):
        super().__init__()
        self.K = K
        self.M = M
        self.alpha_ecl = alpha_ecl
        self.kmeans_update_freq = kmeans_update_freq
        self.register_buffer("H_min", torch.tensor(0.5 * np.log(K), dtype=torch.float32))
        self._iter = 0
        self._cluster_ids: torch.Tensor | None = None   # FIX: explicit None

    def _update_clusters(self, teacher_features: torch.Tensor) -> None:
        """Run K-means++ over teacher final-layer features.

        Empty clusters reassigned to samples from the largest cluster.
        """
        feats = teacher_features.detach().cpu().float().numpy()
        km = KMeans(n_clusters=self.M, init="k-means++", n_init=1,
                    max_iter=100, random_state=42)
        km.fit(feats)
        labels = km.labels_.copy()
        # Reassign empty clusters
        counts = np.bincount(labels, minlength=self.M)
        empty = np.where(counts == 0)[0]
        if len(empty):
            largest = int(np.argmax(counts))
            largest_idxs = np.where(labels == largest)[0]
            for i, m in enumerate(empty):
                labels[largest_idxs[i % len(largest_idxs)]] = m
        self._cluster_ids = torch.tensor(labels, dtype=torch.long)

    def forward(self, W: torch.Tensor,
                teacher_final_features: torch.Tensor) -> torch.Tensor:
        """Compute L_ECL (Eq. 16).

        Args:
            W: [N, K] gating weights (simplex-constrained).
            teacher_final_features: [N, 2048] teacher block-4 avg-pool features.
        Returns:
            L_ECL scalar.
        """
        # FIX: guard against None before first cluster update
        if self._cluster_ids is None and self._iter % self.kmeans_update_freq != 0:
            raise RuntimeError(
                "ECLLoss._cluster_ids is None. Ensure kmeans_update_freq divides "
                "into iteration 0 (i.e., update happens before first forward call). "
                "Default freq=5 is safe because 0 % 5 == 0."
            )
        if self._iter % self.kmeans_update_freq == 0:
            self._update_clusters(teacher_final_features)
        self._iter += 1

        cluster_ids = self._cluster_ids.to(W.device)       # safe device move
        H_gate = batch_gate_entropy(W)
        H_cluster = cluster_gate_entropy(W, cluster_ids, self.M)
        collapse_penalty = self.alpha_ecl * F.relu(self.H_min.to(W.device) - H_gate)
        return -H_cluster + collapse_penalty
