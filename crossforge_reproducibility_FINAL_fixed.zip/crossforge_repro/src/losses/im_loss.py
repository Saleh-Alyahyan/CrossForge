"""
CrossForge: Information Maximization Loss (L_IM).
Equation (13).

L_IM = −H(ȳ) + (1/N) Σ_j H(y_j)
  ȳ = batch-mean ensemble prediction (marginal).
Minimizing L_IM maximizes marginal entropy (diverse batch predictions)
while minimizing conditional entropy per sample (confident predictions).
Applied to ensemble output ŷ (Eq. 5) during gating network update (Algorithm 2).
"""

import torch
import torch.nn as nn

EPS = 1e-8


class IMLoss(nn.Module):
    def forward(self, y_hat: torch.Tensor) -> torch.Tensor:
        """Args:
            y_hat: [N, C] ensemble softmax predictions (Eq. 5).
        Returns:
            L_IM scalar.
        """
        y_bar = y_hat.mean(dim=0)                               # [C] marginal
        H_marginal = -(y_bar * (y_bar + EPS).log()).sum()       # maximize → minimize negative
        H_conditional = -(y_hat * (y_hat + EPS).log()).sum(dim=1).mean()
        return -H_marginal + H_conditional
