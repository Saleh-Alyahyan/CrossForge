"""
CrossForge: Cross-Model Relational Distillation (CMRD) Loss.
Equations (3), (4), (6), (8), (9), (10).

Key novelty vs RKD/S-RKD:
1. EMA teacher aggregated over K heterogeneous base learners, not a fixed supervised teacher.
2. Operates across K parallel learners simultaneously.
3. Source-free: no cross-domain teacher calibration with source data.

Note on iteration-0 bootstrapping:
  At t=0, alpha is initialized uniform (softmax of zeros). Proximity scores computed
  before the first gradient step therefore use uniform layer importance. This is
  consistent with the uniform initialization stated in the paper (Eq. 6) and resolves
  after the first backward pass through L_CMRD.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

EPS = 1e-8  # Eq. (3) numerical stability


def l2_normalize(z: torch.Tensor) -> torch.Tensor:
    """Eq. (3): z / (||z||_2 + eps)."""
    return z / (z.norm(dim=-1, keepdim=True) + EPS)


def pairwise_similarity_matrix(Z: torch.Tensor) -> torch.Tensor:
    """Eq. (4): S = Z_norm @ Z_norm^T ∈ R^{N×N}. Z must be [N, d]."""
    Z_norm = l2_normalize(Z)
    return Z_norm @ Z_norm.t()


def off_diagonal(M: torch.Tensor) -> torch.Tensor:
    """Extract off-diagonal elements (N(N-1) entries). Diagonal = self-similarity = 1."""
    N = M.size(0)
    mask = ~torch.eye(N, dtype=torch.bool, device=M.device)
    return M[mask]


def spatial_pool(z: torch.Tensor) -> torch.Tensor:
    """Global average pool spatial feature maps [N, C, H, W] → [N, C]."""
    if z.dim() == 4:
        return z.flatten(2).mean(dim=2)
    return z


class CMRDLoss(nn.Module):
    """Cross-Model Relational Distillation Loss (Eq. 9).

    Args:
        N: batch size (must equal actual batch size — used only for phi MLP input dim).
        L: number of intermediate feature layers (=4 for ResNet-50 blocks 1–4).
        hidden: phi MLP hidden dimension.
    """

    def __init__(self, N: int = 64, L: int = 4, hidden: int = 256):
        super().__init__()
        self.L = L
        # Learned layer importance α, initialized uniform via softmax(zeros) (Eq. 6)
        self.alpha_raw = nn.Parameter(torch.zeros(L))
        # Domain alignment network φ: two-layer MLP over N²-dimensional similarity maps
        self.phi = nn.Sequential(
            nn.Linear(N * N, hidden),
            nn.ReLU(),
            nn.Linear(hidden, N * N),
        )

    @property
    def alpha(self) -> torch.Tensor:
        """Softmax-normalized layer importance (Eq. 6). Shape: [L]."""
        return F.softmax(self.alpha_raw, dim=0)

    def forward(self,
                learner_features: list,
                teacher_features: list) -> torch.Tensor:
        """L_CMRD (Eq. 9).

        Args:
            learner_features: list of K elements, each a list of L tensors [N, C_l, H_l, W_l].
            teacher_features: list of L tensors [N, C_l, H_l, W_l].
        Returns:
            L_CMRD scalar.
        """
        K = len(learner_features)
        alpha = self.alpha
        loss = torch.zeros((), device=alpha.device, requires_grad=False)

        # Teacher similarity matrices S_T^l (Eq. 8)
        S_T = []
        for l in range(self.L):
            Z_T = spatial_pool(teacher_features[l])
            S_T.append(pairwise_similarity_matrix(Z_T))

        # Sum over K learners and L layers (Eq. 9)
        for k in range(K):
            for l in range(self.L):
                Z_k = spatial_pool(learner_features[k][l])
                S_k = pairwise_similarity_matrix(Z_k)
                diff = off_diagonal(S_k - S_T[l])        # [N(N-1)]
                frobenius_sq = (diff ** 2).sum()
                loss = loss + alpha[l] * frobenius_sq

        return loss / K

    def proximity_scores(self,
                         learner_features: list,
                         teacher_features: list) -> torch.Tensor:
        """Compute proximity scores ρ_{k,j} (Eq. 11).

        ρ_{k,j} = exp(−Σ_l α_l · Σ_{i≠j} |S_k^l_{ji} − S_T^l_{ji}|)

        Note: alpha used here may be from a forward() call in the same iteration
        (gradients already computed) or from the previous iteration (if called
        before forward in a fresh graph). The training loop calls forward() then
        proximity_scores() in the same iteration so alpha is always updated.

        Returns: [K, N] tensor with values in (0, 1].
        """
        K = len(learner_features)
        N = spatial_pool(teacher_features[0]).size(0)
        alpha = self.alpha.detach()  # proximity scores are used as routing inputs, not loss
        device = alpha.device
        rho = torch.zeros(K, N, device=device)

        S_T = []
        for l in range(self.L):
            Z_T = spatial_pool(teacher_features[l].detach())
            S_T.append(pairwise_similarity_matrix(Z_T))

        for k in range(K):
            row_dev = torch.zeros(N, device=device)
            for l in range(self.L):
                Z_k = spatial_pool(learner_features[k][l].detach())
                S_k = pairwise_similarity_matrix(Z_k)
                diff_abs = (S_k - S_T[l]).abs()
                eye_mask = torch.eye(N, dtype=torch.bool, device=device)
                diff_abs = diff_abs.masked_fill(eye_mask, 0.0)
                row_dev = row_dev + alpha[l] * diff_abs.sum(dim=1)
            rho[k] = torch.exp(-row_dev)

        return rho  # [K, N]
