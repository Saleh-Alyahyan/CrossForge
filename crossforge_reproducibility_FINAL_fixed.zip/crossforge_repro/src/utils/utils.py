"""
CrossForge: utility functions.

Seeding, BN freezing, classifier head freezing, logging, checkpointing.
"""

import csv
import json
import logging
import os
import random
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import torch
import torch.nn as nn


# ---------- reproducibility -------------------------------------------

def set_seed(seed: int) -> None:
    """Deterministic seeding for Python, NumPy, PyTorch (Table 6 seeds: 42, 123, 2025)."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.use_deterministic_algorithms(True, warn_only=True)


# ---------- model policy -----------------------------------------------

def freeze_bn_running_stats(model: nn.Module) -> None:
    """Freeze BN running statistics during adaptation (Table 6 BN policy).

    All BN layers are set to eval mode so running mean/var are not updated.
    BN affine parameters (weight/bias) remain trainable.
    """
    for m in model.modules():
        if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d)):
            m.eval()


def freeze_classifier_head(model: nn.Module) -> None:
    """Freeze classifier head throughout adaptation (Table 6)."""
    if hasattr(model, "classifier"):
        for p in model.classifier.parameters():
            p.requires_grad = False


# ---------- pseudo-label computation ----------------------------------

@torch.no_grad()
def compute_pseudo_labels(base_learners: nn.ModuleList,
                           gating_net: nn.Module,
                           cmrd: nn.Module,
                           teacher: nn.Module,
                           loader,
                           tau: float,
                           device: torch.device,
                           num_classes: int) -> np.ndarray:
    """Compute pseudo-labels for StratifiedPseudoLabelSampler.

    Called once per epoch (or initial pass) to refresh pseudo-label assignments
    used by the stratified sampler (Table 6).
    """
    from src.models.deg_network import ensemble_prediction
    all_preds = []
    K = len(base_learners)
    for x, _ in loader:
        x = x.to(device)
        lf = [bl(x, return_intermediate=True)[1] for bl in base_learners]
        _, tf = teacher(x, return_intermediate=True)
        rho = cmrd.proximity_scores(lf, tf).t()         # [N, K]
        t_final = tf[-1].flatten(2).mean(2)
        w = gating_net(rho, t_final, stop_grad_teacher=True)
        y_hat = ensemble_prediction(base_learners, w, x, tau=tau)
        all_preds.append(y_hat.argmax(dim=1).cpu().numpy())
    return np.concatenate(all_preds)


# ---------- logging ---------------------------------------------------

def setup_logger(name: str, log_file: Optional[str] = None,
                 level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(level)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s",
                             datefmt="%Y-%m-%d %H:%M:%S")
    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    logger.addHandler(ch)
    if log_file:
        fh = logging.FileHandler(log_file)
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    return logger


class CSVLogger:
    """Append-mode CSV logger for per-epoch metrics."""

    def __init__(self, path: str, fieldnames: List[str]):
        self.path = path
        self.fieldnames = fieldnames
        write_header = not os.path.exists(path)
        self._f = open(path, "a", newline="")
        self._w = csv.DictWriter(self._f, fieldnames=fieldnames)
        if write_header:
            self._w.writeheader()

    def log(self, row: Dict[str, Any]) -> None:
        self._w.writerow(row)
        self._f.flush()

    def close(self) -> None:
        self._f.close()


# ---------- checkpointing ---------------------------------------------

def save_checkpoint(state: Dict[str, Any], path: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    torch.save(state, path)


def load_checkpoint(path: str, device: str = "cpu") -> Dict[str, Any]:
    if not os.path.isfile(path):
        raise FileNotFoundError(
            f"Checkpoint not found: {path}\n"
            "Run pretrain_source.py first, or download checkpoints with "
            "checkpoints/download_checkpoints.py"
        )
    return torch.load(path, map_location=device)


# ---------- results CSV -----------------------------------------------

def append_result_row(csv_path: str, row: Dict[str, Any]) -> None:
    """Append one result row to the per_seed_per_task CSV."""
    fieldnames = ["method", "seed", "benchmark", "task",
                  "top1_accuracy", "source_only_accuracy",
                  "below_source_only", "macro_f1"]
    write_header = not os.path.exists(csv_path)
    Path(csv_path).parent.mkdir(parents=True, exist_ok=True)
    with open(csv_path, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        if write_header:
            w.writeheader()
        w.writerow(row)
