"""
CrossForge: Base Learner and EMA Teacher (ResNet-50).

FIX (vs original repo): get_teacher_final_features now has a with_grad parameter.
During Algorithm 1 encoder update (not Algorithm 2), teacher features are computed
WITHOUT no_grad so that gradients flow correctly when stop_grad_teacher=False.
During Algorithm 2 (gating-only update), the DEG network itself applies .detach()
via its stop_grad_teacher flag. This resolves the bug where torch.no_grad() inside
the utility function was cutting gradients on the encoder-update path.

Architecture: ResNet-50 backbone, blocks 1–4 as intermediate feature extractor.
Block 5 (avgpool) output is the 2048-d final feature used by DEG and ECL.
Classifier head frozen throughout adaptation (Table 6).
BN running statistics frozen during adaptation (Table 6 BN policy).

References:
  Eq. (7): EMA teacher update.
"""

import copy
from typing import List, Tuple

import torch
import torch.nn as nn
import torchvision.models as models


class BaseLearner(nn.Module):
    """ResNet-50 base learner.

    Intermediate feature extraction: blocks 1–4, returning
    spatial feature maps [N, C_l, H_l, W_l] for l = 1..4.
    Final 2048-d feature = global avg-pool of block-4 output.
    """

    def __init__(self, num_classes: int, pretrained: bool = True):
        super().__init__()
        weights = models.ResNet50_Weights.IMAGENET1K_V1 if pretrained else None
        backbone = models.resnet50(weights=weights)
        self.block1 = nn.Sequential(
            backbone.conv1, backbone.bn1, backbone.relu,
            backbone.maxpool, backbone.layer1,
        )
        self.block2 = backbone.layer2
        self.block3 = backbone.layer3
        self.block4 = backbone.layer4
        self.avgpool = backbone.avgpool
        self.classifier = nn.Linear(2048, num_classes)

    def forward(self, x: torch.Tensor,
                return_intermediate: bool = False
                ) -> Tuple[torch.Tensor, List[torch.Tensor]]:
        z1 = self.block1(x)
        z2 = self.block2(z1)
        z3 = self.block3(z2)
        z4 = self.block4(z3)
        pooled = self.avgpool(z4).flatten(1)
        logits = self.classifier(pooled)
        if return_intermediate:
            return logits, [z1, z2, z3, z4]
        return logits, []

    def final_features(self, x: torch.Tensor) -> torch.Tensor:
        """Block-4 global avg-pool output [N, 2048]. No classifier."""
        z4 = self.block4(self.block3(self.block2(self.block1(x))))
        return self.avgpool(z4).flatten(1)


def build_ensemble(num_classes: int, K: int = 5,
                   pretrained: bool = True) -> nn.ModuleList:
    return nn.ModuleList([BaseLearner(num_classes, pretrained) for _ in range(K)])


def build_ema_teacher(ensemble: nn.ModuleList, beta: float = 0.999) -> BaseLearner:
    """Initialize teacher as uniform average of K learner weights (Eq. 7 init)."""
    K = len(ensemble)
    teacher = copy.deepcopy(ensemble[0])
    t_state = teacher.state_dict()
    for key in t_state:
        t_state[key] = sum(
            ensemble[k].state_dict()[key].float() for k in range(K)
        ) / K
    teacher.load_state_dict(t_state)
    return teacher


@torch.no_grad()
def update_ema_teacher(teacher: BaseLearner,
                       ensemble: nn.ModuleList,
                       beta: float = 0.999) -> None:
    """EMA teacher update called after encoder gradient step (Eq. 7, Algorithm 1 Line 17)."""
    K = len(ensemble)
    for key, t_param in teacher.state_dict().items():
        ensemble_mean = sum(
            ensemble[k].state_dict()[key].float() for k in range(K)
        ) / K
        t_param.copy_(beta * t_param + (1 - beta) * ensemble_mean)


def get_teacher_final_features(teacher: BaseLearner,
                                x: torch.Tensor,
                                with_grad: bool = False) -> torch.Tensor:
    """Extract teacher block-4 global avg-pool features [N, 2048].

    FIX: with_grad=True allows gradient flow through teacher features
    during the encoder update step (Algorithm 1 Line 11), where
    stop_grad_teacher=False in the DEG network.
    with_grad=False (default) is used when features are only needed
    for inference / cluster assignment, avoiding unnecessary computation.

    The original utility always wrapped this in torch.no_grad(), which
    silently cut gradients on the encoder-update path.
    """
    if with_grad:
        return teacher.final_features(x)
    with torch.no_grad():
        return teacher.final_features(x)
