"""
CrossForge: Dynamic Ensemble Gating (DEG) Network.
Equations (11), (12), Algorithm 2.

Routes target samples to most domain-compatible base learners via soft weights.
Input: proximity score vector [ρ_1,j … ρ_K,j] (K values) concatenated with
       teacher final-layer features f_T^L(x_j) (2048 values).
Output: w_j ∈ Δ^{K-1} (simplex-constrained soft ensemble weights).

stop_grad_teacher semantics:
  Algorithm 2 (gating-only update): stop_grad=True → teacher features detached.
  Algorithm 1 encoder update: stop_grad=False → teacher features carry gradients.

FIX: The original repo's get_teacher_final_features() always wrapped in no_grad(),
silently making stop_grad_teacher=False a no-op on the encoder path. That is fixed
in src/models/model.py by the with_grad parameter. DEG network itself is unchanged.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class DEGNetwork(nn.Module):
    """Dynamic Ensemble Gating Network (ψ). Two-layer MLP (Eq. 12)."""

    def __init__(self, K: int = 5, teacher_feat_dim: int = 2048, hidden_dim: int = 256):
        super().__init__()
        self.K = K
        self.mlp = nn.Sequential(
            nn.Linear(K + teacher_feat_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, K),
        )

    def forward(self, rho: torch.Tensor,
                teacher_final_feat: torch.Tensor,
                stop_grad_teacher: bool = True) -> torch.Tensor:
        """Args:
            rho: [N, K] proximity scores (Eq. 11).
            teacher_final_feat: [N, 2048] teacher block-4 features.
            stop_grad_teacher: True during Algorithm 2 gating update;
                               False during Algorithm 1 encoder update.
        Returns:
            w: [N, K] simplex weights (Eq. 12).
        """
        feat = teacher_final_feat.detach() if stop_grad_teacher else teacher_final_feat
        h = torch.cat([rho, feat], dim=1)     # [N, K+2048]
        logits = self.mlp(h)                   # [N, K]
        return F.softmax(logits, dim=1)        # [N, K] ∈ Δ^{K-1}


def ensemble_prediction(base_learners: nn.ModuleList,
                         gating_weights: torch.Tensor,
                         x: torch.Tensor,
                         tau: float = 0.05) -> torch.Tensor:
    """Weighted ensemble output ŷ (Eq. 5).

    ŷ(x) = Σ_k w_k(x) · softmax(g_k(f_k(x)) / τ); τ=0.05.
    """
    y_hat = None
    for k, bl in enumerate(base_learners):
        logits_k, _ = bl(x)                              # [N, C]
        pred_k = F.softmax(logits_k / tau, dim=1)        # [N, C]
        w_k = gating_weights[:, k].unsqueeze(1)          # [N, 1]
        y_hat = w_k * pred_k if y_hat is None else y_hat + w_k * pred_k
    return y_hat    # [N, C]
