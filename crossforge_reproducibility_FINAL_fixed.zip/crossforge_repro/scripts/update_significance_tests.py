"""
CrossForge: Regenerate significance tests from reproduced results.

Runs paired Wilcoxon signed-rank tests comparing CrossForge vs each baseline
on Office-Home (12 tasks × 3 seeds) and DomainNet-126 (7 tasks × 3 seeds).

Usage:
  python scripts/update_significance_tests.py \
      --csv results/reproduced/per_seed_per_task_results.csv
"""

import argparse, os, sys
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from src.datasets.dataset import OH_TASK_IDS, DN_TASK_IDS

BASELINES = ["SHOT","NRC","AaD","LAME","DaC","G-SFDA"]
SEEDS     = [42, 123, 2025]


def require_filled(df, method, tasks):
    sub = df[(df["method"]==method) & (df["task"].isin(tasks))]
    missing = sub["top1_accuracy"].isna().sum()
    if missing:
        raise ValueError(
            f"{missing} missing top1_accuracy rows for method='{method}'. "
            "Run experiments first."
        )


def wilcoxon_test(cf_vals, bl_vals):
    """Paired Wilcoxon signed-rank test; returns p-value."""
    diffs = np.array(cf_vals) - np.array(bl_vals)
    if (diffs == 0).all():
        return 1.0
    try:
        _, p = wilcoxon(diffs, alternative="greater")
    except Exception:
        p = float("nan")
    return p


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--csv", default="results/reproduced/per_seed_per_task_results.csv")
    p.add_argument("--out", default="results/reproduced/significance_tests.md")
    p.add_argument("--alpha", type=float, default=0.05)
    return p.parse_args()


def main():
    args = parse_args()
    if not os.path.exists(args.csv):
        print(f"CSV not found: {args.csv}")
        return

    df = pd.read_csv(args.csv, comment="#")
    df = df[df["seed"].isin(SEEDS)].copy()
    df["top1_accuracy"] = pd.to_numeric(df["top1_accuracy"], errors="coerce")

    lines = [
        "# CrossForge Significance Tests",
        "",
        f"Method: paired Wilcoxon signed-rank (one-sided, CrossForge > baseline)",
        f"Alpha: {args.alpha}",
        "",
    ]

    for bench_name, tasks in [("Office-Home", OH_TASK_IDS),
                               ("DomainNet-126", DN_TASK_IDS)]:
        lines.append(f"## {bench_name}")
        lines.append("")
        lines.append("| Baseline | p-value | Significant |")
        lines.append("|----------|---------|-------------|")

        require_filled(df, "CrossForge", tasks)
        cf_vals = (df[(df["method"]=="CrossForge") & (df["task"].isin(tasks))]
                   .sort_values(["task","seed"])["top1_accuracy"]
                   .dropna().tolist())

        for bl in BASELINES:
            try:
                require_filled(df, bl, tasks)
                bl_vals = (df[(df["method"]==bl) & (df["task"].isin(tasks))]
                           .sort_values(["task","seed"])["top1_accuracy"]
                           .dropna().tolist())
                p = wilcoxon_test(cf_vals, bl_vals)
                sig = "Yes ✓" if p < args.alpha else "No"
                lines.append(f"| {bl} | {p:.4f} | {sig} |")
            except ValueError as e:
                lines.append(f"| {bl} | MISSING | — |")

        lines.append("")

    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w") as f:
        f.write("\n".join(lines))
    print(f"Significance tests written to {args.out}")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
