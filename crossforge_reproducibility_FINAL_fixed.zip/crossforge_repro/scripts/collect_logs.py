"""
CrossForge: Merge per-run JSON result rows into the master results CSV.

Each JSON file in logs/ holds one row:
  {"method": "CrossForge", "task": "OH_Ar_Cl", "seed": 42,
   "top1_accuracy": 68.1, "macro_f1": null}

crossforge.inference or test.py writes this format.
Baseline rows (SHOT, NRC, ...) and Source-Only can be added in the same format.

For DomainNet-126 per-task source-only values (not reported in the paper — only
the 7-task average of 31.2 is given), place your measured values in
logs/source_only_per_task.json, e.g.:
  {"DN_Re_Cl": 30.1, "DN_Re_Pa": 29.8, ...}

Usage:
  python scripts/collect_logs.py --logs logs --csv results/reproduced/per_seed_per_task_results.csv
"""

import argparse
import glob
import json
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from src.datasets.dataset import ALL_TASK_IDS, SOURCE_ONLY_ACCURACY


METHODS = ["Source Only","SHOT","NRC","AaD","LAME","DaC","G-SFDA","CrossForge",
           "CrossForge_no_cmrd","CrossForge_no_deg","CrossForge_no_ecl",
           "CrossForge_no_cmrd_deg","CrossForge_shot_gate"]
SEEDS   = [42, 123, 2025]


def make_empty_csv(path):
    """Create a fully-populated skeleton CSV with all rows empty."""
    import csv
    fieldnames = ["method","seed","benchmark","task",
                  "top1_accuracy","source_only_accuracy",
                  "below_source_only","macro_f1"]
    benchmark_map = {t: ("Office-Home" if t.startswith("OH") else
                         "DomainNet-126" if t.startswith("DN") else
                         "VisDA-C" if t == "VisDA" else "Clinical")
                     for t in ALL_TASK_IDS}
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for method in METHODS:
            for seed in SEEDS:
                for task in ALL_TASK_IDS:
                    w.writerow({
                        "method": method, "seed": seed,
                        "benchmark": benchmark_map[task], "task": task,
                        "top1_accuracy": "", "source_only_accuracy": "",
                        "below_source_only": "", "macro_f1": "",
                    })


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--logs",    default="logs")
    p.add_argument("--csv",     default="results/reproduced/per_seed_per_task_results.csv")
    p.add_argument("--init",    action="store_true",
                   help="Create an empty skeleton CSV and exit (run once before training)")
    return p.parse_args()


def main():
    args = parse_args()

    if args.init:
        make_empty_csv(args.csv)
        print(f"Skeleton CSV written to {args.csv}")
        return

    if not os.path.exists(args.csv):
        print(f"CSV not found. Run with --init first: {args.csv}")
        return

    df  = pd.read_csv(args.csv, comment="#")
    key = ["method","seed","task"]
    df  = df.set_index(key).sort_index()

    # Load source-only overrides for DN tasks
    so_override_path = os.path.join(args.logs, "source_only_per_task.json")
    so_extra = {}
    if os.path.isfile(so_override_path):
        with open(so_override_path) as f:
            so_extra = json.load(f)
    so_all = {**SOURCE_ONLY_ACCURACY, **so_extra}

    n_new = n_skip = 0
    for path in sorted(glob.glob(os.path.join(args.logs, "*.json"))):
        if os.path.basename(path) == "source_only_per_task.json":
            continue
        r = json.load(open(path))
        k = (r.get("method"), int(r["seed"]), r["task"])
        if k not in df.index:
            n_skip += 1
            print(f"skip {path}: {k} not in CSV rows")
            continue
        df.loc[k, "top1_accuracy"] = r["top1_accuracy"]
        if r.get("macro_f1") is not None:
            df.loc[k, "macro_f1"] = r["macro_f1"]
        n_new += 1

    df = df.reset_index()
    df["top1_accuracy"] = pd.to_numeric(df["top1_accuracy"], errors="coerce")

    # Recompute source_only_accuracy and below_source_only
    df["source_only_accuracy"] = df["task"].map(so_all)
    ok = df["top1_accuracy"].notna() & df["source_only_accuracy"].notna()
    df.loc[ok, "below_source_only"] = (
        df.loc[ok, "top1_accuracy"] < df.loc[ok, "source_only_accuracy"]
    ).astype(int)

    df.to_csv(args.csv, index=False)
    filled = int(df["top1_accuracy"].notna().sum())
    f1_filled = int(df[df["task"].isin(["C2_CheXpert","C4_ISIC"])]["macro_f1"].notna().sum())
    no_ref = sorted(set(
        df.loc[df["top1_accuracy"].notna() & df["source_only_accuracy"].isna(), "task"]
    ))
    print(f"Merged {n_new} rows ({n_skip} skipped). "
          f"CSV: {filled}/{len(df)} accuracy cells filled, "
          f"{f1_filled}/48 macro-F1 filled.")
    if no_ref:
        print(f"No source-only reference for: {', '.join(no_ref)}")
        print(f"  → Add to {so_override_path}")


if __name__ == "__main__":
    main()
