#!/usr/bin/env bash
# Adapt CrossForge on all 24 tasks × 3 seeds.

set -euo pipefail
DATA_ROOT="/data/crossforge_datasets"; CKPT_DIR="checkpoints"; OUT_DIR="results/reproduced"; DEVICE="cuda"
while [[ $# -gt 0 ]]; do
  case $1 in
    --data_root) DATA_ROOT="$2"; shift 2 ;;
    --ckpt_dir)  CKPT_DIR="$2"; shift 2 ;;
    --out_dir)   OUT_DIR="$2"; shift 2 ;;
    --device)    DEVICE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

OH_TASKS=(OH_Ar_Cl OH_Ar_Pr OH_Ar_Re OH_Cl_Ar OH_Cl_Pr OH_Cl_Re OH_Pr_Ar OH_Pr_Cl OH_Pr_Re OH_Re_Ar OH_Re_Cl OH_Re_Pr)
DN_TASKS=(DN_Re_Cl DN_Re_Pa DN_Cl_Pa DN_Pa_Cl DN_Cl_Sk DN_Pa_Sk DN_Sk_Re)
CLIN_TASKS=(C1_REFUGE C2_CheXpert C3_CHAOS C4_ISIC)

for SEED in 42 123 2025; do
  for TASK in "${OH_TASKS[@]}"; do
    python train.py --config configs/office_home.yaml --task "$TASK" \
        --seed $SEED --data_root "$DATA_ROOT/OfficeHome" \
        --checkpoint_dir "$CKPT_DIR" --out_dir "$OUT_DIR" --device "$DEVICE"
  done
  for TASK in "${DN_TASKS[@]}"; do
    python train.py --config configs/domainnet126.yaml --task "$TASK" \
        --seed $SEED --data_root "$DATA_ROOT/DomainNet126" \
        --checkpoint_dir "$CKPT_DIR" --out_dir "$OUT_DIR" --device "$DEVICE"
  done
  python train.py --config configs/visda_c.yaml --task VisDA \
      --seed $SEED --data_root "$DATA_ROOT/VisDA-C" \
      --checkpoint_dir "$CKPT_DIR" --out_dir "$OUT_DIR" --device "$DEVICE"
  for TASK in "${CLIN_TASKS[@]}"; do
    python train.py --config configs/clinical.yaml --task "$TASK" \
        --seed $SEED --data_root "$DATA_ROOT/Clinical" \
        --checkpoint_dir "$CKPT_DIR" --out_dir "$OUT_DIR" --device "$DEVICE"
  done
done
echo "Main adaptation complete."
