#!/usr/bin/env bash
# Pre-train K=5 base learners for every benchmark source domain and seed.
# Must complete before run_main.sh.

set -euo pipefail
DATA_ROOT="/data/crossforge_datasets"; CKPT_DIR="checkpoints"; DEVICE="cuda"
while [[ $# -gt 0 ]]; do
  case $1 in
    --data_root) DATA_ROOT="$2"; shift 2 ;;
    --ckpt_dir)  CKPT_DIR="$2"; shift 2 ;;
    --device)    DEVICE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

for SEED in 42 123 2025; do
  # Office-Home: 4 source domains
  for SRC in Art Clipart Product Real_World; do
    python pretrain_source.py --config configs/office_home.yaml \
        --data_root "$DATA_ROOT/OfficeHome" --source "$SRC" \
        --seed $SEED --checkpoint_dir "$CKPT_DIR" --device "$DEVICE"
  done
  # DomainNet-126: 4 domains
  for SRC in real clipart painting sketch; do
    python pretrain_source.py --config configs/domainnet126.yaml \
        --data_root "$DATA_ROOT/DomainNet126" --source "$SRC" \
        --seed $SEED --checkpoint_dir "$CKPT_DIR" --device "$DEVICE"
  done
  # VisDA-C: synthetic source
  python pretrain_source.py --config configs/visda_c.yaml \
      --data_root "$DATA_ROOT/VisDA-C" --source train \
      --seed $SEED --checkpoint_dir "$CKPT_DIR" --device "$DEVICE"
  # Clinical: 4 source sites
  for SRC in refuge_source chexpert_source chaos_source isic_source; do
    python pretrain_source.py --config configs/clinical.yaml \
        --data_root "$DATA_ROOT/Clinical" --source "$SRC" \
        --seed $SEED --checkpoint_dir "$CKPT_DIR" --device "$DEVICE"
  done
done
echo "Pre-training complete."
