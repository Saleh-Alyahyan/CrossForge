#!/usr/bin/env bash
# CrossForge: Full end-to-end reproduction.
# Usage: bash scripts/run_all.sh --data_root /path/to/datasets
# This reproduces ALL tables in the paper across all seeds.
# Expected runtime: ~60h on a single A100 40GB GPU.

set -euo pipefail

DATA_ROOT="/data/crossforge_datasets"
CKPT_DIR="checkpoints"
OUT_DIR="results/reproduced"
DEVICE="cuda"

# Parse args
while [[ $# -gt 0 ]]; do
  case $1 in
    --data_root) DATA_ROOT="$2"; shift 2 ;;
    --ckpt_dir)  CKPT_DIR="$2"; shift 2 ;;
    --out_dir)   OUT_DIR="$2"; shift 2 ;;
    --device)    DEVICE="$2"; shift 2 ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

echo "=== CrossForge Full Reproduction ==="
echo "Data root : $DATA_ROOT"
echo "Checkpoint: $CKPT_DIR"
echo "Output    : $OUT_DIR"

# Initialize empty skeleton CSV
python scripts/collect_logs.py --init --csv "$OUT_DIR/per_seed_per_task_results.csv"

# Source pre-training
bash scripts/run_pretrain.sh --data_root "$DATA_ROOT" --ckpt_dir "$CKPT_DIR" --device "$DEVICE"

# Main adaptation + baselines
bash scripts/run_main.sh    --data_root "$DATA_ROOT" --ckpt_dir "$CKPT_DIR" --out_dir "$OUT_DIR" --device "$DEVICE"
bash scripts/run_baselines.sh --data_root "$DATA_ROOT" --ckpt_dir "$CKPT_DIR" --out_dir "$OUT_DIR" --device "$DEVICE"

# Ablations
bash scripts/run_ablation.sh --data_root "$DATA_ROOT" --ckpt_dir "$CKPT_DIR" --out_dir "$OUT_DIR" --device "$DEVICE"

# Aggregate results
python evaluate_all.py --csv "$OUT_DIR/per_seed_per_task_results.csv" --out "$OUT_DIR"

# Compare against paper
python compare_results.py --expected results/expected/table_means_reference.csv \
                           --reproduced "$OUT_DIR/per_seed_per_task_results.csv" \
                           --tol 0.1

# Figures
python figures/make_figures.py --csv "$OUT_DIR/per_seed_per_task_results.csv" \
                                --out figures/

echo "=== Done. Results in $OUT_DIR ==="
