#!/usr/bin/env bash
# CrossForge ablation study (Table 10): 5 variants × all OH tasks × 3 seeds.

set -euo pipefail
DATA_ROOT="/data/crossforge_datasets"; CKPT_DIR="checkpoints"; OUT_DIR="results/reproduced"; DEVICE="cuda"
while [[ $# -gt 0 ]]; do
  case $1 in
    --data_root) DATA_ROOT="$2"; shift 2 ;;
    --ckpt_dir)  CKPT_DIR="$2"; shift 2 ;;
    --out_dir)   OUT_DIR="$2"; shift 2 ;;
    --device)    DEVICE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

OH_TASKS=(OH_Ar_Cl OH_Ar_Pr OH_Ar_Re OH_Cl_Ar OH_Cl_Pr OH_Cl_Re OH_Pr_Ar OH_Pr_Cl OH_Pr_Re OH_Re_Ar OH_Re_Cl OH_Re_Pr)
ABLATIONS=(no_cmrd no_deg no_ecl no_cmrd_deg shot_gate)

for SEED in 42 123 2025; do
  for ABL in "${ABLATIONS[@]}"; do
    for TASK in "${OH_TASKS[@]}"; do
      python train.py --config configs/office_home.yaml --task "$TASK" \
          --ablation "$ABL" --seed $SEED \
          --data_root "$DATA_ROOT/OfficeHome" \
          --checkpoint_dir "$CKPT_DIR" --out_dir "$OUT_DIR" --device "$DEVICE"
    done
  done
done
echo "Ablation complete."
