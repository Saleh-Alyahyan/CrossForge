"""
evaluate.py - CrossForge Evaluation Script
Reproduces Tables 5, 6, 7, 8, 9 from the paper.

Metrics (Section V-B):
  - Top-1 Accuracy (primary metric)
  - Negative Transfer Rate (NTR)
  - Average Per-Class Accuracy
  - Gating Entropy H_gate

Run:
  python evaluate.py --dataset office_home --source Art --target Clipart
  python evaluate.py --all_tasks  # Evaluates all 12 Office-Home tasks
"""

import os
import argparse
from typing import Dict, List, Tuple

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import (
    accuracy_score, f1_score, precision_score, recall_score,
    confusion_matrix, classification_report
)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm

import config
from model import CrossForge
from dataset import get_test_loader, OfficeHomeDataset, DomainNet126Dataset
from utils import load_checkpoint


# ─────────────────────────────────────────────────────────────────────────────
# METRIC FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def compute_all_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    num_classes: int,
) -> Dict[str, float]:
    """
    Compute all metrics used in the paper (Section V-B):
      - Top-1 Accuracy
      - Per-class accuracy (average)
      - Macro F1, Precision, Recall
    """
    acc = 100.0 * accuracy_score(y_true, y_pred)

    # Per-class accuracy
    per_class = []
    for c in range(num_classes):
        mask = y_true == c
        if mask.sum() == 0:
            continue
        per_class.append(accuracy_score(y_true[mask], y_pred[mask]))
    avg_per_class = 100.0 * np.mean(per_class)

    f1        = 100.0 * f1_score(y_true, y_pred, average="macro", zero_division=0)
    precision = 100.0 * precision_score(y_true, y_pred, average="macro", zero_division=0)
    recall    = 100.0 * recall_score(y_true, y_pred, average="macro", zero_division=0)

    return {
        "Top1_Acc":        acc,
        "Avg_Per_Class":   avg_per_class,
        "Macro_F1":        f1,
        "Macro_Precision": precision,
        "Macro_Recall":    recall,
    }


def compute_ntr(
    method_accs: Dict[str, float],
    source_only_acc: float,
) -> float:
    """
    Negative Transfer Rate: fraction of tasks where method < source_only.
    Section V-B: Lower is better.
    CrossForge achieves NTR=5.2% (Table 9).
    """
    # For single task evaluation
    return 1.0 if method_accs["Top1_Acc"] < source_only_acc else 0.0


def compute_gating_entropy(model: CrossForge, loader, device) -> float:
    """
    Compute batch-averaged gating entropy H_gate (Section V-B, Eq. 14).
    CrossForge target: H_gate > 0.8 * log(K) = 1.29 (Section V-F).
    """
    model.eval()
    K   = model.K
    eps = 1e-8
    h_vals = []

    with torch.no_grad():
        for imgs, _ in loader:
            imgs = imgs.to(device)
            out  = model(imgs)
            w    = out["gating_weights"]   # (N, K)
            H    = -(w * (w + eps).log()).sum(dim=-1)  # (N,)
            h_vals.extend(H.cpu().numpy().tolist())

    return float(np.mean(h_vals))


# ─────────────────────────────────────────────────────────────────────────────
# CONFUSION MATRIX & ROC
# ─────────────────────────────────────────────────────────────────────────────

def save_confusion_matrix(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    class_names: List[str],
    save_path: str,
    title: str = "Confusion Matrix",
) -> None:
    cm = confusion_matrix(y_true, y_pred)
    cm_norm = cm.astype(float) / (cm.sum(axis=1, keepdims=True) + 1e-8)

    fig, ax = plt.subplots(figsize=(min(20, len(class_names)), min(18, len(class_names))))
    sns.heatmap(cm_norm, annot=len(class_names) <= 20, fmt=".2f",
                cmap="Blues", ax=ax,
                xticklabels=class_names if len(class_names) <= 20 else [],
                yticklabels=class_names if len(class_names) <= 20 else [])
    ax.set_title(title, fontsize=14)
    ax.set_xlabel("Predicted", fontsize=12)
    ax.set_ylabel("True", fontsize=12)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Confusion matrix saved: {save_path}")


def save_per_class_accuracy_plot(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    class_names: List[str],
    save_path: str,
) -> None:
    per_class = []
    for c in range(len(class_names)):
        mask = y_true == c
        if mask.sum() == 0:
            per_class.append(0.0)
            continue
        per_class.append(100.0 * accuracy_score(y_true[mask], y_pred[mask]))

    idx  = np.argsort(per_class)
    fig, ax = plt.subplots(figsize=(12, max(6, len(class_names) // 4)))
    ax.barh(range(len(class_names)), [per_class[i] for i in idx], color="steelblue")
    ax.set_yticks(range(len(class_names)))
    ax.set_yticklabels([class_names[i] for i in idx], fontsize=7)
    ax.set_xlabel("Accuracy (%)")
    ax.set_title("Per-Class Accuracy")
    ax.axvline(np.mean(per_class), color="red", linestyle="--",
               label=f"Mean: {np.mean(per_class):.1f}%")
    ax.legend()
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Per-class accuracy plot saved: {save_path}")


# ─────────────────────────────────────────────────────────────────────────────
# FULL EVALUATION
# ─────────────────────────────────────────────────────────────────────────────

def evaluate_one_task(
    model: CrossForge,
    loader,
    device: torch.device,
    num_classes: int,
    class_names: List[str],
    task_name: str = "",
    save_plots: bool = True,
) -> Dict[str, float]:
    """Evaluate CrossForge on a single adaptation task."""
    model.eval()
    all_preds  = []
    all_labels = []
    all_probs  = []
    h_vals     = []
    eps = 1e-8

    with torch.no_grad():
        for imgs, labels in tqdm(loader, desc=f"Eval {task_name}"):
            imgs, labels = imgs.to(device), labels.to(device)
            out    = model(imgs)
            probs  = out["ensemble_probs"]   # (N, C)
            preds  = probs.argmax(dim=-1)
            w      = out["gating_weights"]   # (N, K)
            H      = -(w * (w + eps).log()).sum(dim=-1)

            all_preds.append(preds.cpu().numpy())
            all_labels.append(labels.cpu().numpy())
            all_probs.append(probs.cpu().numpy())
            h_vals.extend(H.cpu().numpy().tolist())

    y_true = np.concatenate(all_labels)
    y_pred = np.concatenate(all_preds)
    probs  = np.concatenate(all_probs)

    metrics = compute_all_metrics(y_true, y_pred, num_classes)
    metrics["H_gate"] = float(np.mean(h_vals))
    metrics["log_K"]  = float(np.log(model.K))

    print(f"\n{'='*60}")
    print(f"Task: {task_name}")
    print(f"  Top-1 Accuracy:       {metrics['Top1_Acc']:.2f}%")
    print(f"  Avg Per-Class Acc:    {metrics['Avg_Per_Class']:.2f}%")
    print(f"  Macro F1:             {metrics['Macro_F1']:.2f}%")
    print(f"  Macro Precision:      {metrics['Macro_Precision']:.2f}%")
    print(f"  Macro Recall:         {metrics['Macro_Recall']:.2f}%")
    print(f"  Gating Entropy:       {metrics['H_gate']:.4f} "
          f"(log K = {metrics['log_K']:.4f})")
    print(f"  Gate Utilization:     {100.0*metrics['H_gate']/metrics['log_K']:.1f}%")
    print(f"{'='*60}\n")

    if save_plots:
        os.makedirs(config.RESULTS_DIR, exist_ok=True)
        cm_path  = os.path.join(config.RESULTS_DIR,
                                f"confusion_matrix_{task_name}.png")
        acc_path = os.path.join(config.RESULTS_DIR,
                                f"per_class_acc_{task_name}.png")
        save_confusion_matrix(y_true, y_pred, class_names, cm_path,
                               title=f"CrossForge - {task_name}")
        save_per_class_accuracy_plot(y_true, y_pred, class_names, acc_path)

    # Full classification report
    report_path = os.path.join(config.RESULTS_DIR,
                               f"classification_report_{task_name}.txt")
    with open(report_path, "w") as f:
        f.write(classification_report(y_true, y_pred,
                                      target_names=class_names, digits=4))
    print(f"Classification report saved: {report_path}")

    return metrics


# ─────────────────────────────────────────────────────────────────────────────
# PRINT RESULTS TABLE (matching paper Tables 5-9)
# ─────────────────────────────────────────────────────────────────────────────

def print_results_table(results: Dict[str, float], dataset_name: str) -> None:
    """Print results in paper table format."""
    print(f"\n{'='*70}")
    print(f"CROSSFORGE EVALUATION RESULTS — {dataset_name.upper()}")
    print(f"(Matches paper Table format, Section V)")
    print(f"{'='*70}")
    print(f"{'Metric':<30} {'CrossForge':>15}")
    print(f"{'-'*45}")
    for k, v in results.items():
        print(f"{k:<30} {v:>14.2f}")
    print(f"{'='*70}\n")


# ─────────────────────────────────────────────────────────────────────────────
# ALL OFFICE-HOME TASKS (Table 5)
# ─────────────────────────────────────────────────────────────────────────────

def evaluate_office_home_all_tasks(
    model: CrossForge,
    device: torch.device,
    source_only_accs: Dict[str, float] = None,
) -> None:
    """
    Evaluate on all 12 Office-Home tasks and print Table 5 format.
    Source-only accuracies from Table 5 for NTR computation.
    """
    from dataset import OfficeHomeDataset
    DOMAINS = OfficeHomeDataset.DOMAINS
    TASKS   = [(s, t) for s in DOMAINS for t in DOMAINS if s != t]

    # Source-only accuracies from Table 5
    source_only = source_only_accs or {
        "Art->Clipart": 46.3, "Art->Product": 67.5, "Art->Real_World": 75.3,
        "Clipart->Art": 60.5, "Clipart->Product": 65.2, "Clipart->Real_World": 69.4,
        "Product->Art": 58.3, "Product->Clipart": 44.2, "Product->Real_World": 76.3,
        "Real_World->Art": 68.9, "Real_World->Clipart": 50.1, "Real_World->Product": 79.6,
    }

    task_accs  = []
    ntr_count  = 0

    print("\n" + "="*80)
    print("OFFICE-HOME RESULTS (Table 5)")
    print(f"{'Task':<25} {'CrossForge':>12} {'Source-Only':>12} {'Gain':>8} {'NTR':>5}")
    print("-"*80)

    for src, tgt in TASKS:
        task_name  = f"{src}->{tgt}"
        loader     = get_test_loader("office_home", tgt)
        ds         = OfficeHomeDataset(tgt, split="test")
        class_names = ds.classes

        metrics = evaluate_one_task(
            model, loader, device, OfficeHomeDataset.NUM_CLASSES,
            class_names, task_name=task_name.replace("->", "_to_"),
            save_plots=False,
        )
        acc = metrics["Top1_Acc"]
        so  = source_only.get(task_name, 0.0)
        ntr = 1 if acc < so else 0
        ntr_count += ntr
        task_accs.append(acc)

        print(f"{task_name:<25} {acc:>11.2f}% {so:>11.1f}%  "
              f"{acc-so:>+7.1f}%  {'✗' if ntr else '✓'}")

    avg = np.mean(task_accs)
    ntr_rate = 100.0 * ntr_count / len(TASKS)

    print("-"*80)
    print(f"{'Average':<25} {avg:>11.2f}%  {'NTR: ' + str(ntr_rate) + '%':>22}")
    print(f"\nPaper reports: CrossForge Avg = 80.6%, Paper NTR = 5.2%")
    print("="*80)


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="CrossForge Evaluation")
    parser.add_argument("--dataset",    default=config.ACTIVE_DATASET)
    parser.add_argument("--source",     default=config.SOURCE_DOMAIN)
    parser.add_argument("--target",     default=config.TARGET_DOMAIN)
    parser.add_argument("--checkpoint", default=None,
                        help="Path to CrossForge checkpoint")
    parser.add_argument("--all_tasks",  action="store_true",
                        help="Evaluate all Office-Home tasks (Table 5)")
    parser.add_argument("--seed",       type=int, default=config.DEFAULT_SEED)
    args = parser.parse_args()

    device = torch.device(config.DEVICE if torch.cuda.is_available() else "cpu")
    num_classes = config.DATASETS[args.dataset]["num_classes"]

    # Load model
    model = CrossForge(num_classes=num_classes, K=config.K, L=config.L).to(device)

    ckpt_path = args.checkpoint or os.path.join(
        config.CHECKPOINT_DIR,
        f"crossforge_best_run{args.seed}.pth"
    )
    if os.path.exists(ckpt_path):
        state = load_checkpoint(ckpt_path, device)
        model.load_state_dict(state["model"])
        print(f"Loaded checkpoint: {ckpt_path} (acc={state.get('acc', 'N/A')})")
    else:
        print(f"No checkpoint found at {ckpt_path}. Using random weights.")

    if args.all_tasks and args.dataset == "office_home":
        evaluate_office_home_all_tasks(model, device)
    else:
        loader = get_test_loader(args.dataset, args.target)
        if args.dataset == "office_home":
            ds          = OfficeHomeDataset(args.target, split="test")
            class_names = ds.classes
        else:
            ds          = DomainNet126Dataset(args.target, split="test")
            class_names = ds.classes

        task_name = f"{args.source}_to_{args.target}"
        metrics   = evaluate_one_task(
            model, loader, device, num_classes, class_names,
            task_name=task_name, save_plots=True
        )
        print_results_table(metrics, dataset_name=task_name)


if __name__ == "__main__":
    main()
