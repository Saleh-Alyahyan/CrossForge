# CrossForge: Source-Free Cross-Domain Knowledge Bridging for Ensemble Models

**Paper:** CrossForge: Source-Free Cross-Domain Knowledge Bridging for Ensemble Models via Relational Feature Alignment

**Year:** 2025

---

## Abstract

CrossForge is a source-free cross-domain ensemble transfer framework that bridges domain gaps through layer-wise relational feature alignment. It achieves **8.1% average accuracy improvement** over state-of-the-art SFDA ensembles and reduces negative transfer by **37%** relative to the strongest baseline (DaC) across seven cross-domain benchmarks.

---

## Architecture

CrossForge comprises three modules:

1. **CMRD** (Cross-Model Relational Distillation) — aligns pairwise similarity matrices across K base learners' intermediate layers to an EMA teacher without source data.
2. **DEG** (Dynamic Ensemble Gating) — routes target samples to the most domain-compatible base learner via proximity scores.
3. **ECL** (Ensemble Calibration Loss) — prevents gate collapse and promotes diverse learner specialization.

---

## Datasets

| Dataset | Download | Classes |
|---------|----------|---------|
| Office-Home | https://hemanthdv.github.io/officehome-dataset/ | 65 |
| DomainNet-126 | http://ai.bu.edu/M3SDA/ | 126 |
| VisDA-C | http://ai.bu.edu/visda-2017/ | 12 |
| REFUGE (C1) | https://refuge.grand-challenge.org/ | 2 |
| CheXpert (C2) | https://stanfordmlgroup.github.io/competitions/chexpert | 5 |
| CHAOS (C3) | https://chaos.grand-challenge.org/ | 4 |
| ISIC 2018 (C4) | https://challenge.isic-archive.com/data/ | 7 |

Place datasets under `data/`:

```
data/
├── office_home/
│   ├── Art/
│   ├── Clipart/
│   ├── Product/
│   └── Real_World/
├── domainnet126/
│   ├── clipart/
│   ├── painting/
│   └── ...
└── visda_c/
    ├── train/
    └── validation/
```

---

## Installation

```bash
pip install -r requirements.txt
```

---

## Usage

### Step 1 — Pre-train base learners

```bash
python train.py --phase pretrain --dataset office_home --source Art
```

### Step 2 — Adapt with CrossForge

```bash
python train.py --phase adapt --dataset office_home --source Art --target Clipart
```

### Step 3 — Run all 3 seeds (paper protocol)

```bash
python train.py --phase adapt --dataset office_home --source Art --target Clipart --run_all_seeds
```

### Evaluate

```bash
python evaluate.py --dataset office_home --source Art --target Clipart
python evaluate.py --all_tasks   # All 12 Office-Home tasks (Table 5)
```

### Inference

```bash
python inference.py --image path/to/image.jpg --target Clipart
```

---

## Results (from paper)

### Office-Home (Table 5)

| Method | Avg Accuracy |
|--------|-------------|
| Source Only | 63.5% |
| SHOT | 71.8% |
| NRC | 74.4% |
| DaC | 74.4% |
| **CrossForge (ours)** | **80.6%** |

### All Benchmarks (Table 9)

| Method | Office-Home | DomainNet-126 | VisDA-C | Clinical Avg | NTR |
|--------|-------------|---------------|---------|--------------|-----|
| DaC (best baseline) | 74.4% | 44.8% | 87.5% | 77.5% | 8.3% |
| **CrossForge** | **80.6%** | **54.2%** | **89.8%** | **86.9%** | **5.2%** |

---

## Folder Structure

```
CrossForge_Implementation/
├── figures/                  # Paper figures extracted from docx
├── data/                     # Dataset root (download separately)
├── checkpoints/              # Saved model weights
├── results/                  # Evaluation outputs
├── notebooks/
│   └── demo.ipynb
├── config.py                 # All hyperparameters
├── dataset.py                # Dataset classes + download scripts
├── model.py                  # Full CrossForge architecture
├── train.py                  # Pre-training + adaptation
├── evaluate.py               # Metrics + visualization
├── inference.py              # Single sample prediction
├── utils.py                  # Helper functions
├── requirements.txt
└── README.md
```

---

## Key Hyperparameters (Table 4)

| Parameter | Value |
|-----------|-------|
| Backbone | ResNet-50 (ImageNet) |
| Base learners K | 5 |
| Intermediate layers L | 4 |
| Optimizer | SGD (momentum=0.9) |
| Learning rate | 5e-3 (cosine decay) |
| Batch size | 64 |
| Adaptation epochs | 30 |
| EMA momentum β | 0.999 |
| Temperature τ | 0.05 |
| λ1, λ2, λ3 | 1.0, 0.5, 0.3 |
| Seeds | 42, 123, 2025 |
