"""
utils.py - CrossForge Utility Functions
Visualization, metrics, checkpointing, t-SNE, gating analysis.
"""

import os
import math
from typing import List, Dict, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.manifold import TSNE

import config


# ─────────────────────────────────────────────────────────────────────────────
# METERS
# ─────────────────────────────────────────────────────────────────────────────

class AverageMeter:
    """Tracks running average of a metric."""
    def __init__(self, name: str = "") -> None:
        self.name = name
        self.reset()

    def reset(self) -> None:
        self.val = 0.0
        self.avg = 0.0
        self.sum = 0.0
        self.count = 0

    def update(self, val: float, n: int = 1) -> None:
        self.val    = val
        self.sum   += val * n
        self.count += n
        self.avg    = self.sum / (self.count + 1e-8)

    def __repr__(self) -> str:
        return f"{self.name}: {self.avg:.4f}"


# ─────────────────────────────────────────────────────────────────────────────
# ACCURACY
# ─────────────────────────────────────────────────────────────────────────────

def accuracy(logits: torch.Tensor, labels: torch.Tensor, topk: int = 1) -> float:
    """Compute top-k accuracy (%)."""
    with torch.no_grad():
        _, pred = logits.topk(topk, dim=-1, largest=True, sorted=True)
        pred    = pred.t()
        correct = pred.eq(labels.view(1, -1).expand_as(pred))
        acc     = correct[:topk].reshape(-1).float().sum(0) * 100.0 / labels.size(0)
    return acc.item()


# ─────────────────────────────────────────────────────────────────────────────
# CHECKPOINT
# ─────────────────────────────────────────────────────────────────────────────

def save_checkpoint(state: dict, path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    torch.save(state, path)
    print(f"Checkpoint saved: {path}")


def load_checkpoint(path: str, device: torch.device) -> dict:
    state = torch.load(path, map_location=device)
    print(f"Checkpoint loaded: {path}")
    return state


# ─────────────────────────────────────────────────────────────────────────────
# t-SNE VISUALIZATION (Section V-H, Fig. 8)
# "t-SNE maps of Art->Clipart target feature embeddings
#  before (left) and after (right) CrossForge adaptation"
# ─────────────────────────────────────────────────────────────────────────────

def plot_tsne(
    features_before: np.ndarray,  # (N, d)
    features_after:  np.ndarray,  # (N, d)
    labels:          np.ndarray,  # (N,)
    save_path:       str,
    num_classes:     int = 65,
    max_samples:     int = 2000,
    title:           str = "t-SNE Feature Visualization",
) -> None:
    """
    t-SNE visualization matching Fig. 8 in paper.
    Section V-H: 'intra-class features cluster more tightly
    while inter-class separation increases after adaptation.'
    """
    # Subsample if large
    if len(labels) > max_samples:
        idx = np.random.choice(len(labels), max_samples, replace=False)
        features_before = features_before[idx]
        features_after  = features_after[idx]
        labels          = labels[idx]

    print("Computing t-SNE (before adaptation)...")
    tsne = TSNE(n_components=2, random_state=42, perplexity=30, n_iter=1000)
    emb_before = tsne.fit_transform(features_before)

    print("Computing t-SNE (after adaptation)...")
    tsne = TSNE(n_components=2, random_state=42, perplexity=30, n_iter=1000)
    emb_after  = tsne.fit_transform(features_after)

    # Color palette
    cmap   = plt.get_cmap("tab20" if num_classes <= 20 else "hsv")
    colors = [cmap(i / num_classes) for i in range(num_classes)]

    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    for ax, emb, subtitle in zip(axes, [emb_before, emb_after],
                                 ["Before Adaptation", "After CrossForge Adaptation"]):
        for c in range(num_classes):
            mask = labels == c
            if mask.sum() == 0:
                continue
            ax.scatter(emb[mask, 0], emb[mask, 1],
                       c=[colors[c]], s=8, alpha=0.6, linewidths=0)
        ax.set_xlabel("t-SNE Dimension 1")
        ax.set_ylabel("t-SNE Dimension 2")
        ax.set_title(subtitle, fontsize=13)
        ax.set_aspect("equal")

    fig.suptitle(title, fontsize=14, fontweight="bold")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"t-SNE saved: {save_path}")


# ─────────────────────────────────────────────────────────────────────────────
# GATING ENTROPY PLOT (Section V-F, Fig. 5)
# CrossForge H_gate > 0.8 * log(K) = 1.29 throughout adaptation
# ─────────────────────────────────────────────────────────────────────────────

def plot_gating_entropy(
    h_gate_per_epoch: List[float],    # CrossForge
    h_gate_no_ecl:   List[float],    # Without ECL (ablation)
    K: int,
    save_path: str,
) -> None:
    """
    Replicate Fig. 5: Gating entropy H_gate during adaptation.
    Target: CrossForge H_gate > 0.8 * log(K) = 1.29 (Section V-F).
    Without ECL, H_gate collapses to < 0.5 after epoch 10.
    """
    epochs    = list(range(1, len(h_gate_per_epoch) + 1))
    log_K     = math.log(K)
    threshold = 0.8 * log_K

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(epochs, h_gate_per_epoch, "b-o", label="CrossForge (with ECL)",
            linewidth=2, markersize=5)
    if h_gate_no_ecl:
        ax.plot(epochs[:len(h_gate_no_ecl)], h_gate_no_ecl, "r--s",
                label="w/o ECL", linewidth=2, markersize=5)
    ax.axhline(log_K,     color="black",  linestyle=":",
               label=f"log K = {log_K:.2f}")
    ax.axhline(threshold, color="green",  linestyle="--",
               label=f"0.8·log K = {threshold:.2f}")
    ax.set_xlabel("Adaptation Epoch")
    ax.set_ylabel(r"Gating Entropy $H_{\mathrm{gate}}$")
    ax.set_title("Gating Entropy During Adaptation\n(Section V-F, Fig. 5)")
    ax.legend()
    ax.set_ylim(0, log_K * 1.1)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Gating entropy plot saved: {save_path}")


# ─────────────────────────────────────────────────────────────────────────────
# LAYER IMPORTANCE WEIGHTS PLOT (Section V-I, Fig. 9)
# Deeper layers (blocks 3-4) get higher weights (0.38 and 0.35)
# ─────────────────────────────────────────────────────────────────────────────

def plot_layer_importance(
    weights_per_task: List[np.ndarray],   # Each (L,), one per task
    save_path: str,
    L: int = 4,
) -> None:
    """
    Replicate Fig. 9: Layer importance weights a_l averaged across tasks.
    Paper reports: blocks 3-4 -> 0.38, 0.35; blocks 1-2 -> 0.15, 0.12.
    """
    weights_arr = np.array(weights_per_task)    # (T, L)
    mean = weights_arr.mean(axis=0)             # (L,)
    std  = weights_arr.std(axis=0)              # (L,)

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.bar(range(1, L+1), mean, yerr=std, capsize=5,
           color=["#90CAF9", "#42A5F5", "#1976D2", "#0D47A1"],
           edgecolor="black", linewidth=0.8, width=0.6)
    ax.set_xlabel("ResNet Block Layer")
    ax.set_ylabel(r"Layer Importance $a_l$")
    ax.set_xticks(range(1, L+1))
    ax.set_xticklabels([f"Block {l}" for l in range(1, L+1)])
    ax.set_title("Learned Layer Importance Weights\n(Section V-I, Fig. 9)")
    for i, (m, s) in enumerate(zip(mean, std)):
        ax.text(i+1, m + s + 0.005, f"{m:.3f}", ha="center", va="bottom",
                fontsize=10, fontweight="bold")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Layer importance plot saved: {save_path}")


# ─────────────────────────────────────────────────────────────────────────────
# SCALABILITY PLOT (Section V-G, Fig. 7)
# Accuracy and adaptation time as function of K
# ─────────────────────────────────────────────────────────────────────────────

def plot_scalability(
    K_values:  List[int],
    accs:      List[float],
    times_min: List[float],
    save_path: str,
) -> None:
    """
    Replicate Fig. 7: Accuracy and wall-clock time vs K.
    Paper: K=5 is optimal; time scales linearly (12.3 -> 58.7 min for K=1..10).
    """
    fig, ax1 = plt.subplots(figsize=(8, 5))
    ax2 = ax1.twinx()

    color_acc  = "#1976D2"
    color_time = "#E53935"

    ax1.plot(K_values, accs,      "o-", color=color_acc,  linewidth=2,
             markersize=8, label="Accuracy (%)")
    ax2.plot(K_values, times_min, "s--", color=color_time, linewidth=2,
             markersize=8, label="Adaptation Time (min)")

    ax1.set_xlabel("Number of Base Learners K")
    ax1.set_ylabel("Top-1 Accuracy (%)", color=color_acc)
    ax2.set_ylabel("Adaptation Time (min)", color=color_time)
    ax1.tick_params(axis="y", labelcolor=color_acc)
    ax2.tick_params(axis="y", labelcolor=color_time)

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper left")
    ax1.set_title("CrossForge Scalability Analysis\n(Section V-G, Fig. 7)")
    ax1.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Scalability plot saved: {save_path}")


# ─────────────────────────────────────────────────────────────────────────────
# ABLATION STUDY TABLE (Section V-E, Table 8)
# ─────────────────────────────────────────────────────────────────────────────

def print_ablation_table(results: Dict[str, Dict[str, float]]) -> None:
    """
    Print ablation results matching Table 8 format.
    results: {variant_name: {"OH": acc, "DN": acc}}
    """
    paper_results = {
        "CrossForge (full)":    {"OH": 80.6, "DN": 54.2},
        "w/o CMRD (raw feat.)": {"OH": 76.5, "DN": 50.4},
        "w/o DEG (uniform)":    {"OH": 77.2, "DN": 51.1},
        "w/o ECL":              {"OH": 78.3, "DN": 52.1},
        "w/o CMRD & DEG":       {"OH": 73.4, "DN": 46.3},
        "Source only":          {"OH": 63.5, "DN": 31.2},
    }

    print("\n" + "="*60)
    print("ABLATION STUDY (Table 8)")
    print(f"{'Variant':<25} {'CMRD':>6} {'DEG':>5} {'ECL':>5} "
          f"{'OH Avg':>8} {'DN Avg':>8}")
    print("-"*60)

    cmrd_check = {"CrossForge (full)": "✓", "w/o CMRD (raw feat.)": "×",
                  "w/o DEG (uniform)": "✓", "w/o ECL": "✓",
                  "w/o CMRD & DEG": "×", "Source only": "—"}
    deg_check  = {"CrossForge (full)": "✓", "w/o CMRD (raw feat.)": "✓",
                  "w/o DEG (uniform)": "×", "w/o ECL": "✓",
                  "w/o CMRD & DEG": "×", "Source only": "—"}
    ecl_check  = {"CrossForge (full)": "✓", "w/o CMRD (raw feat.)": "✓",
                  "w/o DEG (uniform)": "✓", "w/o ECL": "×",
                  "w/o CMRD & DEG": "✓", "Source only": "—"}

    for variant, vals in paper_results.items():
        paper_oh = vals["OH"]
        paper_dn = vals["DN"]
        exp_oh   = results.get(variant, {}).get("OH", "N/A")
        exp_dn   = results.get(variant, {}).get("DN", "N/A")
        oh_str   = f"{exp_oh:.1f}" if isinstance(exp_oh, float) else f"({paper_oh})"
        dn_str   = f"{exp_dn:.1f}" if isinstance(exp_dn, float) else f"({paper_dn})"
        print(f"{variant:<25} {cmrd_check[variant]:>6} {deg_check[variant]:>5} "
              f"{ecl_check[variant]:>5} {oh_str:>8} {dn_str:>8}")

    print("="*60)
    print("Values in parentheses are from the paper (Table 8).")
    print("CrossForge gains: CMRD +4.1%, DEG +3.4%, ECL +2.3% on Office-Home.")
