"""
train.py - CrossForge Training Script
Paper Section V-B/C: Base learner pre-training + CrossForge adaptation

Run:
  python train.py --phase pretrain --dataset office_home --source Art
  python train.py --phase adapt   --dataset office_home --source Art --target Clipart
"""

import os
import argparse
import random
import time

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm

import config
from model import CrossForge, BaseLearner
from dataset import get_source_loaders, get_target_loader, get_test_loader
from utils import AverageMeter, accuracy, save_checkpoint, load_checkpoint


# ─────────────────────────────────────────────────────────────────────────────
# REPRODUCIBILITY  (Table 4: seeds 42, 123, 2025)
# ─────────────────────────────────────────────────────────────────────────────

def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True


# ─────────────────────────────────────────────────────────────────────────────
# BASE LEARNER PRE-TRAINING
# Section V-C: SGD, lr=1e-2, cosine decay, 60 epochs, batch=64
# ─────────────────────────────────────────────────────────────────────────────

def pretrain_base_learner(
    learner_idx: int,
    train_loader,
    val_loader,
    num_classes: int,
    device: torch.device,
    writer: SummaryWriter,
    seed: int = 42,
) -> BaseLearner:
    """
    Pre-train a single base learner on its source partition.
    Section V-C: SGD (momentum=0.9, weight_decay=1e-4), lr=1e-2, cosine,
                 60 epochs, batch=64.
    """
    set_seed(seed + learner_idx)
    model = BaseLearner(num_classes).to(device)

    optimizer = optim.SGD(
        model.parameters(),
        lr=config.PRETRAIN_LR,
        momentum=config.PRETRAIN_MOMENTUM,
        weight_decay=config.PRETRAIN_WEIGHT_DECAY,
    )
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=config.PRETRAIN_EPOCHS
    )
    criterion = nn.CrossEntropyLoss()

    best_acc  = 0.0
    ckpt_path = os.path.join(
        config.CHECKPOINT_DIR, f"base_learner_{learner_idx}_best.pth"
    )

    for epoch in range(config.PRETRAIN_EPOCHS):
        model.train()
        loss_meter = AverageMeter("Loss")
        acc_meter  = AverageMeter("Acc@1")

        for imgs, labels in tqdm(train_loader,
                                 desc=f"[Learner {learner_idx}] Epoch {epoch+1}",
                                 leave=False):
            imgs, labels = imgs.to(device), labels.to(device)
            optimizer.zero_grad()
            _, _, logits = model(imgs)
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()

            acc = accuracy(logits, labels)
            loss_meter.update(loss.item(), imgs.size(0))
            acc_meter.update(acc, imgs.size(0))

        scheduler.step()

        # Validation
        val_acc = evaluate_base_learner(model, val_loader, device)

        if writer:
            writer.add_scalar(f"pretrain/learner{learner_idx}/train_loss",
                              loss_meter.avg, epoch)
            writer.add_scalar(f"pretrain/learner{learner_idx}/val_acc",
                              val_acc, epoch)

        print(f"[Learner {learner_idx}] Epoch {epoch+1:3d}/{config.PRETRAIN_EPOCHS} "
              f"Loss: {loss_meter.avg:.4f} TrainAcc: {acc_meter.avg:.2f}% "
              f"ValAcc: {val_acc:.2f}%")

        if val_acc > best_acc:
            best_acc = val_acc
            save_checkpoint({"model": model.state_dict(),
                             "epoch": epoch, "acc": val_acc}, ckpt_path)

    print(f"[Learner {learner_idx}] Best Val Acc: {best_acc:.2f}%")
    return model


def evaluate_base_learner(model, loader, device) -> float:
    """Evaluate base learner accuracy on a data loader."""
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for imgs, labels in loader:
            imgs, labels = imgs.to(device), labels.to(device)
            _, _, logits = model(imgs)
            preds = logits.argmax(dim=-1)
            correct += (preds == labels).sum().item()
            total   += labels.size(0)
    return 100.0 * correct / (total + 1e-8)


# ─────────────────────────────────────────────────────────────────────────────
# CROSSFORGE ADAPTATION LOOP
# Algorithm 1 (Section IV-E): Main adaptation loop
# Algorithm 2 (Section IV-B): Gating update
# ─────────────────────────────────────────────────────────────────────────────

def adapt_crossforge(
    model: CrossForge,
    target_loader,
    test_loader,
    device: torch.device,
    writer: SummaryWriter,
    run_id: int = 0,
) -> float:
    """
    CrossForge adaptation loop.
    Algorithm 1: T iterations, batch size N, SGD for encoders and alignment net,
                 Adam for gating network (or SGD as in Table 4).
    Section V-B: Optimizer = SGD (momentum=0.9), lr=5e-3, cosine decay, 30 epochs.
    """

    # ── Optimizer setup (Table 4) ──────────────────────────────────────────
    # Parameters updated via L_total: base learner encoders, CMRD module
    adapt_params = (
        list(p for bl in model.base_learners for p in bl.parameters())
        + list(model.cmrd.parameters())
    )
    optimizer_adapt = optim.SGD(
        adapt_params,
        lr=config.ADAPT_LR,
        momentum=config.MOMENTUM,
        weight_decay=config.WEIGHT_DECAY,
    )
    scheduler_adapt = optim.lr_scheduler.CosineAnnealingLR(
        optimizer_adapt, T_max=config.ADAPT_EPOCHS
    )

    # Gating network updated via L_IM + L_ECL (Algorithm 2)
    optimizer_gate = optim.SGD(
        model.gating.parameters(),
        lr=config.ADAPT_LR,
        momentum=config.MOMENTUM,
        weight_decay=config.WEIGHT_DECAY,
    )

    best_acc  = 0.0
    ckpt_best = os.path.join(config.CHECKPOINT_DIR,
                             f"crossforge_best_run{run_id}.pth")
    ckpt_last = os.path.join(config.CHECKPOINT_DIR,
                             f"crossforge_last_run{run_id}.pth")

    for epoch in range(config.ADAPT_EPOCHS):
        model.train()
        loss_total_m = AverageMeter("L_total")
        loss_cmrd_m  = AverageMeter("L_cmrd")
        loss_im_m    = AverageMeter("L_im")
        loss_ecl_m   = AverageMeter("L_ecl")
        hgate_m      = AverageMeter("H_gate")
        start        = time.time()

        for batch_idx, (imgs, _) in enumerate(tqdm(
                target_loader, desc=f"[Adapt] Epoch {epoch+1}", leave=False)):
            imgs = imgs.to(device)

            # ── Algorithm 1: Forward pass ──────────────────────────────────
            out = model(imgs)

            # ── Algorithm 2: Update gating network (L_IM + L_ECL) ─────────
            optimizer_gate.zero_grad()
            gate_loss = (config.LAMBDA_2 * out["loss_im"]
                         + config.LAMBDA_3 * out["loss_ecl"])
            gate_loss.backward(retain_graph=True)
            optimizer_gate.step()

            # ── Algorithm 1 line 16: Update encoders + CMRD (L_total) ─────
            optimizer_adapt.zero_grad()
            out["loss_total"].backward()
            optimizer_adapt.step()

            # ── Algorithm 1 line 17: EMA teacher update ────────────────────
            model.update_teacher(beta=config.EMA_MOMENTUM)

            # Logging
            n = imgs.size(0)
            loss_total_m.update(out["loss_total"].item(), n)
            loss_cmrd_m.update(out["loss_cmrd"].item(), n)
            loss_im_m.update(out["loss_im"].item(), n)
            loss_ecl_m.update(out["loss_ecl"].item(), n)
            hgate_m.update(out["H_gate"].item(), n)

            if batch_idx % config.LOG_INTERVAL == 0:
                print(f"  Batch {batch_idx:4d} | "
                      f"L_total={loss_total_m.avg:.4f} "
                      f"L_cmrd={loss_cmrd_m.avg:.4f} "
                      f"L_im={loss_im_m.avg:.4f} "
                      f"L_ecl={loss_ecl_m.avg:.4f} "
                      f"H_gate={hgate_m.avg:.4f}")

        scheduler_adapt.step()
        elapsed = time.time() - start

        # ── Evaluate on test set ───────────────────────────────────────────
        test_acc = evaluate_ensemble(model, test_loader, device)

        if writer and config.TENSORBOARD:
            writer.add_scalar("adapt/loss_total",   loss_total_m.avg, epoch)
            writer.add_scalar("adapt/loss_cmrd",    loss_cmrd_m.avg,  epoch)
            writer.add_scalar("adapt/loss_im",      loss_im_m.avg,    epoch)
            writer.add_scalar("adapt/loss_ecl",     loss_ecl_m.avg,   epoch)
            writer.add_scalar("adapt/H_gate",       hgate_m.avg,      epoch)
            writer.add_scalar("adapt/test_acc",     test_acc,         epoch)

        print(f"[Epoch {epoch+1:3d}/{config.ADAPT_EPOCHS}] "
              f"L={loss_total_m.avg:.4f} "
              f"H_gate={hgate_m.avg:.4f} "
              f"TestAcc={test_acc:.2f}% "
              f"Time={elapsed:.1f}s")

        # Save checkpoints
        state = {"model": model.state_dict(), "epoch": epoch, "acc": test_acc}
        if test_acc > best_acc:
            best_acc = test_acc
            if config.SAVE_BEST:
                save_checkpoint(state, ckpt_best)
        if config.SAVE_LAST:
            save_checkpoint(state, ckpt_last)

    print(f"[Run {run_id}] Best test accuracy: {best_acc:.2f}%")
    return best_acc


def evaluate_ensemble(model: CrossForge, loader, device) -> float:
    """Evaluate CrossForge ensemble on test set. Returns top-1 accuracy."""
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for imgs, labels in loader:
            imgs, labels = imgs.to(device), labels.to(device)
            out    = model(imgs)
            preds  = out["ensemble_probs"].argmax(dim=-1)
            correct += (preds == labels).sum().item()
            total   += labels.size(0)
    return 100.0 * correct / (total + 1e-8)


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="CrossForge Training")
    parser.add_argument("--phase",   choices=["pretrain", "adapt"], default="adapt")
    parser.add_argument("--dataset", default=config.ACTIVE_DATASET)
    parser.add_argument("--source",  default=config.SOURCE_DOMAIN)
    parser.add_argument("--target",  default=config.TARGET_DOMAIN)
    parser.add_argument("--seed",    type=int, default=config.DEFAULT_SEED)
    parser.add_argument("--run_all_seeds", action="store_true",
                        help="Run all 3 seeds and report mean±std (Table 4)")
    args = parser.parse_args()

    device = torch.device(config.DEVICE if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    seeds = config.RANDOM_SEEDS if args.run_all_seeds else [args.seed]
    results = []

    for seed in seeds:
        set_seed(seed)
        exp_name = (f"{config.EXPERIMENT_NAME}_seed{seed}")
        writer   = SummaryWriter(os.path.join(config.LOG_DIR, exp_name)) \
                   if config.TENSORBOARD else None

        num_classes = config.DATASETS[args.dataset]["num_classes"]

        if args.phase == "pretrain":
            # ── Pre-train K base learners on source partitions ─────────────
            source_loaders = get_source_loaders(args.dataset, args.source, K=config.K)
            target_loader  = get_target_loader(args.dataset, args.source, split="test")

            for k in range(config.K):
                pretrain_base_learner(
                    learner_idx=k,
                    train_loader=source_loaders[k],
                    val_loader=target_loader,
                    num_classes=num_classes,
                    device=device,
                    writer=writer,
                    seed=seed,
                )
            print("Pre-training complete. Checkpoints saved.")

        elif args.phase == "adapt":
            # ── Load pre-trained base learners and adapt ───────────────────
            model = CrossForge(num_classes=num_classes, K=config.K, L=config.L).to(device)

            # Load each base learner from checkpoint
            for k in range(config.K):
                ckpt_path = os.path.join(
                    config.CHECKPOINT_DIR, f"base_learner_{k}_best.pth"
                )
                if os.path.exists(ckpt_path):
                    state = load_checkpoint(ckpt_path, device)
                    model.base_learners[k].load_state_dict(state["model"])
                    print(f"Loaded base learner {k} from {ckpt_path}")
                else:
                    print(f"WARNING: Checkpoint not found for learner {k}: {ckpt_path}")
                    print("Proceeding with ImageNet pre-trained weights.")

            # Re-initialize EMA teacher after loading base learners
            model._init_teacher()

            target_loader = get_target_loader(args.dataset, args.target,
                                              batch_size=config.BATCH_SIZE)
            test_loader   = get_test_loader(args.dataset, args.target)

            acc = adapt_crossforge(
                model, target_loader, test_loader, device, writer, run_id=seed
            )
            results.append(acc)

        if writer:
            writer.close()

    if len(results) > 1:
        mean = np.mean(results)
        std  = np.std(results)
        print(f"\n{'='*50}")
        print(f"Results over {len(seeds)} seeds: {mean:.2f} ± {std:.2f}%")
        print(f"Individual: {results}")
        print(f"{'='*50}")


if __name__ == "__main__":
    main()
