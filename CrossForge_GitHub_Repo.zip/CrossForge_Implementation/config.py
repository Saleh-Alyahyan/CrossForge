"""
config.py - CrossForge Configuration
Paper: "CrossForge: Source-Free Cross-Domain Knowledge Bridging for
        Ensemble Models via Relational Feature Alignment"
All hyperparameters match exactly as reported in Section V (Table 4).
"""

import os

# ─────────────────────────────────────────────────────────────────────────────
# PATHS
# ─────────────────────────────────────────────────────────────────────────────
BASE_DIR        = os.path.dirname(os.path.abspath(__file__))
DATA_DIR        = os.path.join(BASE_DIR, "data")
CHECKPOINT_DIR  = os.path.join(BASE_DIR, "checkpoints")
RESULTS_DIR     = os.path.join(BASE_DIR, "results")
FIGURES_DIR     = os.path.join(BASE_DIR, "figures")
LOG_DIR         = os.path.join(BASE_DIR, "runs")      # TensorBoard logs

for d in [DATA_DIR, CHECKPOINT_DIR, RESULTS_DIR, LOG_DIR]:
    os.makedirs(d, exist_ok=True)

# ─────────────────────────────────────────────────────────────────────────────
# DATASET SETTINGS
# (Section V-A, Table 3, Supplementary Table A1)
# ─────────────────────────────────────────────────────────────────────────────
DATASETS = {
    "office_home": {
        "name": "Office-Home",
        "url": "https://hemanthdv.github.io/officehome-dataset/",
        "local_path": os.path.join(DATA_DIR, "office_home"),
        "domains": ["Art", "Clipart", "Product", "Real_World"],
        "num_classes": 65,
        "num_images": 15500,
        "split": (0.7, 0.3),        # train/test
    },
    "domainnet_126": {
        "name": "DomainNet-126",
        "url": "http://ai.bu.edu/M3SDA/",
        "local_path": os.path.join(DATA_DIR, "domainnet126"),
        "domains": ["clipart", "painting", "real", "sketch", "infograph", "quickdraw"],
        "eval_tasks": [
            ("real", "clipart"), ("real", "painting"), ("clipart", "painting"),
            ("painting", "clipart"), ("clipart", "sketch"),
            ("painting", "sketch"), ("sketch", "real"),
        ],
        "num_classes": 126,
        "split": (0.7, 0.3),
    },
    "visda_c": {
        "name": "VisDA-C",
        "url": "http://ai.bu.edu/visda-2017/",
        "local_path": os.path.join(DATA_DIR, "visda_c"),
        "domains": ["train", "validation"],   # synthetic -> real
        "num_classes": 12,
        "split": (0.8, 0.2),
    },
    # Clinical datasets (Section V-A)
    "C1_refuge": {
        "name": "REFUGE Fundus",
        "url": "https://refuge.grand-challenge.org/",
        "local_path": os.path.join(DATA_DIR, "refuge"),
        "num_classes": 2,
    },
    "C2_chexpert": {
        "name": "CheXpert",
        "url": "https://stanfordmlgroup.github.io/competitions/chexpert",
        "local_path": os.path.join(DATA_DIR, "chexpert"),
        "num_classes": 5,
    },
    "C3_chaos": {
        "name": "CHAOS Abdominal",
        "url": "https://chaos.grand-challenge.org/",
        "local_path": os.path.join(DATA_DIR, "chaos"),
        "num_classes": 4,
    },
    "C4_isic": {
        "name": "ISIC 2018 Task 3",
        "url": "https://challenge.isic-archive.com/data/",
        "local_path": os.path.join(DATA_DIR, "isic2018"),
        "num_classes": 7,
    },
}

# Active dataset for current run
ACTIVE_DATASET  = "office_home"
SOURCE_DOMAIN   = "Art"
TARGET_DOMAIN   = "Clipart"

# ─────────────────────────────────────────────────────────────────────────────
# MODEL SETTINGS  (Section V-B, Table 4)
# ─────────────────────────────────────────────────────────────────────────────
BACKBONE        = "resnet50"          # ResNet-50 ImageNet pre-trained
PRETRAINED      = True
NUM_CLASSES     = DATASETS[ACTIVE_DATASET]["num_classes"]

# Section IV-B: Number of base learners
K               = 5                   # Number of base learners

# Section IV-A: Intermediate layers of ResNet blocks 1-4 (block5/FC excluded)
L               = 4                   # Number of intermediate layers

# Gating network (Section IV-B, Eq. 12): lightweight 2-layer MLP
GATING_HIDDEN   = 256
GATING_DROPOUT  = 0.1

# Domain alignment network phi (Section IV)
ALIGNMENT_HIDDEN = 512

# Random projection for memory efficiency (Section IV-E)
# Set to None to disable; 256 reduces memory ~4x with <0.5% accuracy loss
RANDOM_PROJ_DIM = None                # or 256 for memory-constrained GPUs

# ─────────────────────────────────────────────────────────────────────────────
# TRAINING HYPERPARAMETERS  (Table 4)
# ─────────────────────────────────────────────────────────────────────────────
# Base learner pre-training (Section V-C)
PRETRAIN_EPOCHS     = 60
PRETRAIN_LR         = 1e-2
PRETRAIN_MOMENTUM   = 0.9
PRETRAIN_WEIGHT_DECAY = 1e-4
PRETRAIN_BATCH_SIZE = 64
PRETRAIN_LR_SCHEDULE = "cosine"

# CrossForge adaptation (Table 4)
ADAPT_EPOCHS        = 30             # Training epochs
ADAPT_LR            = 5e-3          # Learning rate (cosine decay)
OPTIMIZER           = "SGD"
MOMENTUM            = 0.9
WEIGHT_DECAY        = 1e-4
BATCH_SIZE          = 64            # N in paper; constrained by O(N^2) memory
LR_SCHEDULE         = "cosine"      # Cosine decay

# EMA momentum beta (Section IV-A, Eq. 7)
EMA_MOMENTUM        = 0.999         # beta = 0.999

# Softmax temperature (Section III-D, Eq. 5)
TEMPERATURE         = 0.05          # tau

# ─────────────────────────────────────────────────────────────────────────────
# LOSS WEIGHTS  (Section IV-D, Eq. 17)
# Determined via grid search on held-out adaptation task
# ─────────────────────────────────────────────────────────────────────────────
LAMBDA_1    = 1.0    # CMRD loss weight
LAMBDA_2    = 0.5    # Information maximization loss weight
LAMBDA_3    = 0.3    # ECL loss weight

# ─────────────────────────────────────────────────────────────────────────────
# ECL SETTINGS  (Section IV-C, Eq. 15-16)
# ─────────────────────────────────────────────────────────────────────────────
M_CLUSTERS      = 8          # Number of K-means clusters for ECL
H_MIN           = 0.5        # Minimum acceptable gate entropy threshold
ALPHA_ECL       = 1.0        # Gate collapse penalty coefficient

# ─────────────────────────────────────────────────────────────────────────────
# REPRODUCIBILITY  (Table 4)
# ─────────────────────────────────────────────────────────────────────────────
RANDOM_SEEDS    = [42, 123, 2025]   # 3 independent runs; report mean +/- std
DEFAULT_SEED    = 42

# ─────────────────────────────────────────────────────────────────────────────
# DATA AUGMENTATION  (Section V-C)
# ─────────────────────────────────────────────────────────────────────────────
IMG_SIZE        = 224
RESIZE_SIZE     = 256

# Training augmentation
RANDOM_CROP     = True
HORIZONTAL_FLIP = True
COLOR_JITTER    = {
    "brightness": 0.4,
    "contrast":   0.4,
    "saturation": 0.4,
    "hue":        0.0,
}

# ImageNet normalization stats
IMAGENET_MEAN   = [0.485, 0.456, 0.406]
IMAGENET_STD    = [0.229, 0.224, 0.225]

# ─────────────────────────────────────────────────────────────────────────────
# HARDWARE  (Table 4)
# ─────────────────────────────────────────────────────────────────────────────
DEVICE          = "cuda"    # "cuda" or "cpu"
NUM_WORKERS     = 4
PIN_MEMORY      = True
AMP             = False     # Paper does not report AMP; set True to enable

# For batch size <= 64 on GPUs < 40GB VRAM (Section IV-E)
MAX_BATCH_SIZE_LIMITED_VRAM = 64

# ─────────────────────────────────────────────────────────────────────────────
# LOGGING AND CHECKPOINTING
# ─────────────────────────────────────────────────────────────────────────────
LOG_INTERVAL    = 10         # Print every N iterations
SAVE_BEST       = True
SAVE_LAST       = True
TENSORBOARD     = True
EXPERIMENT_NAME = f"crossforge_{ACTIVE_DATASET}_{SOURCE_DOMAIN}_to_{TARGET_DOMAIN}"
