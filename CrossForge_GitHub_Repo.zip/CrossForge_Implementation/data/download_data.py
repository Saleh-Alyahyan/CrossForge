"""
download_data.py - Download CrossForge datasets
Run: python data/download_data.py --dataset office_home
"""
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from dataset import download_office_home, download_domainnet, download_visda
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--dataset", choices=["office_home","domainnet","visda","all"], default="all")
args = parser.parse_args()

if args.dataset in ("office_home","all"): download_office_home()
if args.dataset in ("domainnet","all"):   download_domainnet()
if args.dataset in ("visda","all"):       download_visda()
