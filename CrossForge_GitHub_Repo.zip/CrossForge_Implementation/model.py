"""
model.py - CrossForge Model Architecture
Paper: CrossForge: Source-Free Cross-Domain Knowledge Bridging for
       Ensemble Models via Relational Feature Alignment

Implements:
  - BaseLeaner: ResNet-50 encoder + classifier (Section V-B)
  - CMRD: Cross-Model Relational Distillation (Section IV-A, Eqs. 2-10)
  - DEG: Dynamic Ensemble Gating network (Section IV-B, Eqs. 11-13)
  - ECL: Ensemble Calibration Loss (Section IV-C, Eqs. 14-16)
  - CrossForge: Full model combining all three modules (Section IV)
"""

import copy
import math
from typing import List, Tuple, Optional, Dict

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models

import config


# ─────────────────────────────────────────────────────────────────────────────
# BASE LEARNER  (Section V-B, Table 4)
# ResNet-50 backbone + linear classifier head
# ─────────────────────────────────────────────────────────────────────────────

class BaseLearner(nn.Module):
    """
    Single base learner: ResNet-50 feature encoder + linear classifier.
    Section V-B: 'All K=5 base learners share the ResNet-50 backbone
    architecture pre-trained on ImageNet.'
    Intermediate features are extracted from ResNet convolutional blocks 1-4
    (block5/FC excluded as it collapses spatial feature maps, Table 4).
    """

    def __init__(self, num_classes: int = config.NUM_CLASSES) -> None:
        super().__init__()
        backbone = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1
                                   if config.PRETRAINED else None)

        # Section IV (Eq. 2): Extract intermediate features at layers l in {1,..,L}
        # ResNet-50 blocks: layer1, layer2, layer3, layer4 -> L=4
        self.block1 = nn.Sequential(backbone.conv1, backbone.bn1,
                                     backbone.relu, backbone.maxpool,
                                     backbone.layer1)   # 256-d feature maps
        self.block2 = backbone.layer2    # 512-d
        self.block3 = backbone.layer3    # 1024-d
        self.block4 = backbone.layer4    # 2048-d

        self.avgpool     = backbone.avgpool          # Global average pool
        self.classifier  = nn.Linear(2048, num_classes)

        # Feature dimensionalities per block (dl in paper)
        self.layer_dims  = [256, 512, 1024, 2048]

    def forward_features(self, x: torch.Tensor) -> Tuple[List[torch.Tensor], torch.Tensor]:
        """
        Forward pass extracting intermediate feature maps.
        Returns:
            z_list: list of L=4 intermediate feature maps (after GAP),
                    each shape (N, dl)
            final:  final 2048-d embedding before classifier
        Eq. (2): Z_k^l = f_k^{1:l}(x) in R^{N x d_l}
        """
        z1  = self.block1(x)                         # (N, 256, H, W)
        z2  = self.block2(z1)                        # (N, 512, H/2, W/2)
        z3  = self.block3(z2)                        # (N, 1024, H/4, W/4)
        z4  = self.block4(z3)                        # (N, 2048, H/8, W/8)

        # Global average pool to get (N, dl) vectors
        def gap(z):
            return self.avgpool(z).squeeze(-1).squeeze(-1)

        z_list = [gap(z1), gap(z2), gap(z3), gap(z4)]
        final  = z_list[-1]                          # (N, 2048)
        return z_list, final

    def forward(self, x: torch.Tensor) -> Tuple[List[torch.Tensor], torch.Tensor, torch.Tensor]:
        """
        Full forward pass.
        Returns: (z_list, final_feat, logits)
        """
        z_list, final = self.forward_features(x)
        logits = self.classifier(final)
        return z_list, final, logits


# ─────────────────────────────────────────────────────────────────────────────
# L2-NORMALIZATION HELPER
# Section III-C, Eq. (3): z_k,j^l / (||z_k,j^l||_2 + epsilon)
# ─────────────────────────────────────────────────────────────────────────────

def l2_normalize(z: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    """Row-wise L2 normalization. Eq. (3), epsilon = 1e-8."""
    return z / (z.norm(dim=-1, keepdim=True) + eps)


# ─────────────────────────────────────────────────────────────────────────────
# PAIRWISE COSINE SIMILARITY MATRIX
# Section III-C, Eq. (4): S_k^l = Z_k^l (Z_k^l)^T in R^{NxN}
# ─────────────────────────────────────────────────────────────────────────────

def pairwise_similarity(z: torch.Tensor) -> torch.Tensor:
    """
    Pairwise cosine similarity matrix for a batch of L2-normalized features.
    Eq. (4): S = Z Z^T, entry (i,j) = cosine_sim(z_i, z_j)
    z: (N, d) -> returns (N, N)
    Symmetric, unit diagonal, invariant to feature magnitude.
    """
    z_norm = l2_normalize(z)           # (N, d)
    return torch.mm(z_norm, z_norm.t())  # (N, N)


# ─────────────────────────────────────────────────────────────────────────────
# RANDOM PROJECTION (optional, Section IV-E)
# Reduces intermediate feature dim from d to d'=256 with <0.5% accuracy drop
# ─────────────────────────────────────────────────────────────────────────────

class RandomProjection(nn.Module):
    """Fixed random projection for memory-efficient similarity computation."""
    def __init__(self, in_dim: int, out_dim: int) -> None:
        super().__init__()
        W = torch.randn(in_dim, out_dim) / math.sqrt(out_dim)
        self.register_buffer("W", W)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x @ self.W


# ─────────────────────────────────────────────────────────────────────────────
# CROSS-MODEL RELATIONAL DISTILLATION (CMRD)
# Section IV-A, Eqs. (6)-(10)
# ─────────────────────────────────────────────────────────────────────────────

class CMRDModule(nn.Module):
    """
    Cross-Model Relational Distillation module.
    Section IV-A: Computes CMRD loss between K base learners and EMA teacher.

    Key design (Section IV-A, Eq. 9):
      L_CMRD = (1/K) sum_k sum_l a_l * ||S_k^l - S_T^l||_F^2
    where a_l = softmax(A)_l are learned layer importance weights.

    The teacher f_T is an EMA over base learner weights (Eq. 7):
      f_T <- beta * f_T + (1-beta) * (1/K) * sum_k f_k
    """

    def __init__(self, L: int = config.L) -> None:
        super().__init__()
        self.L   = L
        # A: learned layer importance logits, shape (L,)
        # Initialized uniformly (Section IV-A)
        self.A   = nn.Parameter(torch.zeros(L))

    @property
    def layer_weights(self) -> torch.Tensor:
        """a_l = softmax(A), Eq. (6)."""
        return F.softmax(self.A, dim=0)   # (L,)

    def compute_loss(
        self,
        base_sim_lists: List[List[torch.Tensor]],  # [K][L] each (N,N)
        teacher_sim_list: List[torch.Tensor],       # [L] each (N,N)
    ) -> Tuple[torch.Tensor, List[torch.Tensor]]:
        """
        Eq. (9): L_CMRD = (1/K) * sum_k sum_l a_l * ||S_k^l - S_T^l||_F^2
        Returns (loss, proximity_scores) where proximity_scores: [K][N]
        """
        al   = self.layer_weights   # (L,)
        K    = len(base_sim_lists)
        loss = torch.tensor(0.0, device=al.device)
        proximity_scores = []

        for k in range(K):
            learner_loss    = torch.tensor(0.0, device=al.device)
            row_deviations  = []
            for l in range(self.L):
                S_k = base_sim_lists[k][l]     # (N, N)
                S_T = teacher_sim_list[l]      # (N, N)
                diff = S_k - S_T               # (N, N)
                learner_loss = learner_loss + al[l] * (diff ** 2).sum()

                # Per-row L1 deviation for proximity score, Eq. (11)
                row_deviations.append(al[l] * diff.abs().sum(dim=-1))  # (N,)

            loss = loss + learner_loss / (K + 1e-8)

            # Proximity score rho_{k,j} = exp(-sum_l a_l * row_L1_dev), Eq. (11)
            total_row_dev = sum(row_deviations)          # (N,)
            rho_k = torch.exp(-total_row_dev)            # (N,), in (0,1]
            proximity_scores.append(rho_k)               # [K] x (N,)

        # Normalize by N^2 (Frobenius norm convention)
        N = base_sim_lists[0][0].shape[0]
        loss = loss / (N * N)
        return loss, proximity_scores


# ─────────────────────────────────────────────────────────────────────────────
# DYNAMIC ENSEMBLE GATING (DEG)
# Section IV-B, Eqs. (11)-(13)
# ─────────────────────────────────────────────────────────────────────────────

class GatingNetwork(nn.Module):
    """
    Lightweight two-layer MLP gating network psi.
    Section IV-B, Eq. (12):
      w_j = psi([rho_{1,j},...,rho_{K,j}, f_T^L(x_j)]) in Delta_{K-1}
    Input: K proximity scores + teacher final-layer features (dim=2048)
    Output: softmax weights over K base learners
    """

    def __init__(self, K: int = config.K, teacher_dim: int = 2048,
                 hidden_dim: int = config.GATING_HIDDEN,
                 dropout: float = config.GATING_DROPOUT) -> None:
        super().__init__()
        input_dim = K + teacher_dim     # [rho_1,...,rho_K, f_T^L]
        self.mlp = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, K),
        )

    def forward(
        self,
        proximity_scores: torch.Tensor,  # (N, K)
        teacher_final: torch.Tensor,      # (N, d_L), stop-gradient in Alg2
    ) -> torch.Tensor:
        """
        Returns gating weights w (N, K) on probability simplex Delta_{K-1}.
        """
        h   = torch.cat([proximity_scores, teacher_final], dim=-1)  # (N, K+d)
        w   = F.softmax(self.mlp(h), dim=-1)   # (N, K)
        return w


# ─────────────────────────────────────────────────────────────────────────────
# ENSEMBLE CALIBRATION LOSS (ECL)
# Section IV-C, Eqs. (14)-(16)
# ─────────────────────────────────────────────────────────────────────────────

class EnsembleCalibrationLoss(nn.Module):
    """
    ECL: prevents gate collapse and promotes diverse learner activation.
    Section IV-C:
      H_gate = -(1/N) sum_j sum_k w_{k,j} log w_{k,j}           Eq. (14)
      H_gate^m = -sum_k w_k^m log w_k^m  (per-cluster)          Eq. (15)
      L_ECL = -(1/M) sum_m H_gate^m + alpha * max(H_min-H_gate, 0)  Eq. (16)
    """

    def __init__(
        self,
        M: int = config.M_CLUSTERS,
        H_min: float = config.H_MIN,
        alpha_ecl: float = config.ALPHA_ECL,
    ) -> None:
        super().__init__()
        self.M       = M
        self.H_min   = H_min
        self.alpha   = alpha_ecl

    def forward(
        self,
        w: torch.Tensor,                  # (N, K) gating weights
        teacher_final: torch.Tensor,      # (N, d) for K-means clustering
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Returns (L_ECL, H_gate).
        K-means clustering runs on teacher final-layer features.
        """
        N, K = w.shape
        eps  = 1e-8

        # Batch-averaged gating entropy, Eq. (14)
        H_gate = -(w * (w + eps).log()).sum(dim=-1).mean()  # scalar

        # K-means clustering over teacher features (detached)
        feats  = teacher_final.detach()      # (N, d)
        M_use  = min(self.M, N)
        labels = self._kmeans(feats, M_use)  # (N,)

        # Per-cluster gate entropy, Eq. (15)
        cluster_entropies = []
        for m in range(M_use):
            mask = (labels == m)
            if mask.sum() == 0:
                continue
            w_m     = w[mask].mean(dim=0)   # (K,) - average weights in cluster m
            H_m     = -(w_m * (w_m + eps).log()).sum()
            cluster_entropies.append(H_m)

        if len(cluster_entropies) == 0:
            diversity_loss = torch.tensor(0.0, device=w.device)
        else:
            diversity_loss = -torch.stack(cluster_entropies).mean()

        # Collapse penalty, Eq. (16)
        collapse_penalty = self.alpha * F.relu(
            torch.tensor(self.H_min, device=w.device) - H_gate
        )

        L_ECL = diversity_loss + collapse_penalty
        return L_ECL, H_gate

    @staticmethod
    def _kmeans(feats: torch.Tensor, K: int, n_iters: int = 10) -> torch.Tensor:
        """
        Simple Lloyd's K-means on GPU tensors.
        Returns cluster assignments (N,).
        """
        N, D  = feats.shape
        # Random initialization
        idx   = torch.randperm(N, device=feats.device)[:K]
        cents = feats[idx].clone()   # (K, D)

        for _ in range(n_iters):
            # (N, K) pairwise squared distances
            dists  = torch.cdist(feats, cents, p=2)   # (N, K)
            labels = dists.argmin(dim=-1)              # (N,)
            # Update centroids
            for k in range(K):
                mask = (labels == k)
                if mask.sum() > 0:
                    cents[k] = feats[mask].mean(dim=0)

        return labels


# ─────────────────────────────────────────────────────────────────────────────
# INFORMATION MAXIMIZATION LOSS  (Section IV-B, Eq. 13)
# Used to update gating network psi (Algorithm 2)
# ─────────────────────────────────────────────────────────────────────────────

def info_max_loss(ensemble_probs: torch.Tensor) -> torch.Tensor:
    """
    L_IM = -H(y) + (1/N) * sum_j H(y_j)
    Eq. (13): first term maximizes marginal entropy (diverse predictions),
              second term minimizes per-sample conditional entropy (confident).
    ensemble_probs: (N, C) softmax probabilities
    """
    eps   = 1e-8
    N, C  = ensemble_probs.shape

    # Marginal distribution (batch average)
    p_bar = ensemble_probs.mean(dim=0)                          # (C,)
    H_marg = -(p_bar * (p_bar + eps).log()).sum()               # scalar (max)

    # Per-sample entropy
    H_cond = -(ensemble_probs * (ensemble_probs + eps).log()).sum(dim=-1).mean()

    return -H_marg + H_cond    # minimize: maximize H_marg, minimize H_cond


# ─────────────────────────────────────────────────────────────────────────────
# CROSSFORGE: FULL MODEL
# Section IV, Fig. 2: CMRD + DEG + ECL
# ─────────────────────────────────────────────────────────────────────────────

class CrossForge(nn.Module):
    """
    CrossForge: Source-Free Cross-Domain Ensemble Transfer Framework.
    Section IV: Integrates CMRD, DEG, and ECL.

    Components:
      - K BaseLearners (fk, gk)  [Section III-D, V-B]
      - EMA Teacher f_T          [Section IV-A, Eq. 7]
      - CMRDModule                [Section IV-A, Eqs. 6-10]
      - GatingNetwork psi         [Section IV-B, Eq. 12]
      - EnsembleCalibrationLoss  [Section IV-C, Eqs. 14-16]
    """

    def __init__(
        self,
        num_classes: int = config.NUM_CLASSES,
        K: int = config.K,
        L: int = config.L,
    ) -> None:
        super().__init__()
        self.K = K
        self.L = L

        # K base learners (Section V-B)
        self.base_learners = nn.ModuleList(
            [BaseLearner(num_classes) for _ in range(K)]
        )

        # EMA teacher (not a trainable module; updated via EMA)
        self.teacher = copy.deepcopy(self.base_learners[0])
        for p in self.teacher.parameters():
            p.requires_grad_(False)
        self._init_teacher()

        # CMRD module
        self.cmrd = CMRDModule(L=L)

        # Gating network psi
        self.gating = GatingNetwork(K=K, teacher_dim=2048)

        # ECL
        self.ecl_loss_fn = EnsembleCalibrationLoss()

        # Optional random projection for memory efficiency (Section IV-E)
        if config.RANDOM_PROJ_DIM is not None:
            self.proj_layers = nn.ModuleList([
                RandomProjection(d, config.RANDOM_PROJ_DIM)
                for d in [256, 512, 1024, 2048]
            ])
        else:
            self.proj_layers = None

    def _init_teacher(self) -> None:
        """Initialize teacher as average of all base learner weights. Algorithm 1 line 1."""
        with torch.no_grad():
            for param_t, *params_k in zip(
                self.teacher.parameters(),
                *[bl.parameters() for bl in self.base_learners]
            ):
                avg = sum(p.data for p in params_k) / self.K
                param_t.data.copy_(avg)

    @torch.no_grad()
    def update_teacher(self, beta: float = config.EMA_MOMENTUM) -> None:
        """
        EMA teacher update. Eq. (7):
          f_T <- beta * f_T + (1-beta) * (1/K) * sum_k f_k
        Called after base learner weight update (Algorithm 1, line 17).
        """
        for param_t, *params_k in zip(
            self.teacher.parameters(),
            *[bl.parameters() for bl in self.base_learners]
        ):
            avg_k = sum(p.data for p in params_k) / self.K
            param_t.data.mul_(beta).add_(avg_k * (1.0 - beta))

    def compute_similarity_matrices(
        self, z_list: List[torch.Tensor]
    ) -> List[torch.Tensor]:
        """
        Compute pairwise similarity matrices S_k^l for a given feature list.
        Applies optional random projection for memory efficiency.
        Eqs. (3)-(4).
        """
        sim_list = []
        for l, z in enumerate(z_list):
            if self.proj_layers is not None:
                z = self.proj_layers[l](z)  # (N, d') random projection
            S = pairwise_similarity(z)      # (N, N) Eq. (4)
            sim_list.append(S)
        return sim_list

    def forward(
        self, x: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        Full CrossForge forward pass (Algorithm 1).
        Returns dict with all losses and predictions.
        """
        N = x.shape[0]

        # ── Step 1: Extract intermediate features from K base learners ─────
        # Algorithm 1 lines 6-7
        base_z_lists  = []    # [K][L] each (N, dl)
        base_finals   = []    # [K] each (N, 2048)
        base_logits   = []    # [K] each (N, C)
        for k in range(self.K):
            z_list, final, logits = self.base_learners[k](x)
            base_z_lists.append(z_list)
            base_finals.append(final)
            base_logits.append(logits)

        # ── Step 2: Extract teacher features ──────────────────────────────
        # Algorithm 1 lines 8
        with torch.no_grad():
            teacher_z_list, teacher_final, _ = self.teacher(x)

        # ── Step 3: Compute pairwise similarity matrices ───────────────────
        # Algorithm 1 lines 7-8; Eqs. (4)
        base_sim_lists   = [self.compute_similarity_matrices(zl) for zl in base_z_lists]
        teacher_sim_list = self.compute_similarity_matrices(teacher_z_list)

        # ── Step 4: CMRD loss + proximity scores ──────────────────────────
        # Algorithm 1 line 9; Eq. (9)
        L_cmrd, proximity_scores = self.cmrd.compute_loss(
            base_sim_lists, teacher_sim_list
        )
        # proximity_scores: [K] x (N,)
        rho = torch.stack(proximity_scores, dim=-1)   # (N, K)

        # ── Step 5: Gating weights ─────────────────────────────────────────
        # Algorithm 1 line 11; Eq. (12)
        # Stop-gradient on teacher features in gating update (Algorithm 2 step 1)
        w = self.gating(rho, teacher_final.detach())   # (N, K)

        # ── Step 6: Ensemble prediction ────────────────────────────────────
        # Algorithm 1 line 12; Eq. (5)
        # y(x) = sum_k w_k(x) * softmax(g_k(f_k(x)) / tau)
        ensemble_probs = torch.zeros(N, base_logits[0].shape[-1],
                                     device=x.device)
        for k in range(self.K):
            pk = F.softmax(base_logits[k] / config.TEMPERATURE, dim=-1)  # (N, C)
            ensemble_probs = ensemble_probs + w[:, k:k+1] * pk

        # ── Step 7: Information maximization loss ─────────────────────────
        # Algorithm 2 step 6; Eq. (13)
        L_im = info_max_loss(ensemble_probs)

        # ── Step 8: ECL ────────────────────────────────────────────────────
        # Algorithm 1 line 13; Eqs. (15)-(16)
        L_ecl, H_gate = self.ecl_loss_fn(w, teacher_final)

        # ── Step 9: Total loss (Eq. 17) ────────────────────────────────────
        L_total = (config.LAMBDA_1 * L_cmrd
                   + config.LAMBDA_2 * L_im
                   + config.LAMBDA_3 * L_ecl)

        return {
            "loss_total":   L_total,
            "loss_cmrd":    L_cmrd,
            "loss_im":      L_im,
            "loss_ecl":     L_ecl,
            "H_gate":       H_gate,
            "ensemble_probs": ensemble_probs,    # (N, C)
            "gating_weights": w,                 # (N, K)
            "teacher_final":  teacher_final,     # (N, 2048)
        }

    def predict(self, x: torch.Tensor) -> torch.Tensor:
        """Inference-only forward. Returns predicted class indices (N,)."""
        with torch.no_grad():
            out = self.forward(x)
        return out["ensemble_probs"].argmax(dim=-1)
