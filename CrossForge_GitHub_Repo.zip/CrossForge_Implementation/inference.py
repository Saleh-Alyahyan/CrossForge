"""
inference.py - CrossForge Single-Sample Inference
Run:
  python inference.py --image path/to/image.jpg --checkpoint checkpoints/crossforge_best.pth
"""

import os
import argparse
import numpy as np
from PIL import Image
import torch
import torch.nn.functional as F
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import config
from model import CrossForge
from dataset import get_test_transform
from utils import load_checkpoint


OFFICE_HOME_CLASSES = None   # Will be loaded from dataset folder if available


def load_class_names(dataset: str, domain: str) -> list:
    """Load class names from dataset directory."""
    if dataset == "office_home":
        from dataset import OfficeHomeDataset
        root = os.path.join(config.DATASETS["office_home"]["local_path"], domain)
        if os.path.exists(root):
            from torchvision import datasets
            ds = datasets.ImageFolder(root)
            return ds.classes
    return [f"class_{i}" for i in range(config.NUM_CLASSES)]


def preprocess_image(image_path: str) -> torch.Tensor:
    """Load and preprocess a single image for inference."""
    img = Image.open(image_path).convert("RGB")
    transform = get_test_transform()
    tensor = transform(img).unsqueeze(0)   # (1, C, H, W)
    return tensor, img


def run_inference(
    model: CrossForge,
    image_path: str,
    class_names: list,
    device: torch.device,
    save_path: str = None,
    top_k: int = 5,
) -> dict:
    """
    Run CrossForge inference on a single image.
    Returns dict with predictions, gating weights, and confidence scores.
    """
    tensor, orig_img = preprocess_image(image_path)
    tensor = tensor.to(device)

    model.eval()
    with torch.no_grad():
        out = model(tensor)

    probs         = out["ensemble_probs"][0]       # (C,)
    gating_weights = out["gating_weights"][0]      # (K,)
    pred_idx      = probs.argmax().item()
    pred_class    = class_names[pred_idx] if pred_idx < len(class_names) else f"class_{pred_idx}"
    confidence    = probs[pred_idx].item()

    # Top-K predictions
    topk_vals, topk_idxs = probs.topk(min(top_k, len(class_names)))
    topk_preds = [
        (class_names[i.item()] if i.item() < len(class_names) else f"class_{i.item()}",
         v.item())
        for i, v in zip(topk_idxs, topk_vals)
    ]

    print(f"\n{'='*55}")
    print(f"Image: {os.path.basename(image_path)}")
    print(f"Predicted Class: {pred_class}")
    print(f"Confidence:      {100*confidence:.2f}%")
    print(f"\nTop-{top_k} Predictions:")
    for rank, (cls, prob) in enumerate(topk_preds, 1):
        print(f"  {rank}. {cls:<30} {100*prob:.2f}%")
    print(f"\nGating Weights (K={model.K} base learners):")
    for k, w in enumerate(gating_weights.cpu().numpy()):
        bar = "█" * int(w * 30)
        print(f"  Learner {k+1}: {bar:<30} {100*w:.1f}%")
    print(f"{'='*55}\n")

    # Visualization
    if save_path:
        _visualize_prediction(
            orig_img, topk_preds, gating_weights.cpu().numpy(),
            pred_class, confidence, save_path
        )

    return {
        "predicted_class": pred_class,
        "confidence":       confidence,
        "top_k":            topk_preds,
        "gating_weights":   gating_weights.cpu().numpy(),
        "all_probs":        probs.cpu().numpy(),
    }


def _visualize_prediction(
    orig_img: Image.Image,
    topk_preds: list,
    gating_weights: np.ndarray,
    pred_class: str,
    confidence: float,
    save_path: str,
) -> None:
    """Create visualization with prediction and gating weights."""
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.suptitle(f"CrossForge Prediction: {pred_class} ({100*confidence:.1f}%)",
                 fontsize=14, fontweight="bold")

    # Original image
    axes[0].imshow(orig_img)
    axes[0].set_title("Input Image")
    axes[0].axis("off")

    # Top-K bar chart
    classes_k = [c for c, _ in topk_preds]
    probs_k   = [p * 100 for _, p in topk_preds]
    colors    = ["#2196F3" if i > 0 else "#4CAF50" for i in range(len(classes_k))]
    axes[1].barh(classes_k[::-1], probs_k[::-1], color=colors[::-1])
    axes[1].set_xlabel("Confidence (%)")
    axes[1].set_title(f"Top-{len(topk_preds)} Predictions")
    axes[1].set_xlim(0, 100)

    # Gating weights (Section IV-B: dynamic ensemble gating)
    K = len(gating_weights)
    axes[2].bar(range(1, K+1), gating_weights * 100, color="#FF9800",
                edgecolor="black", linewidth=0.5)
    axes[2].set_xlabel("Base Learner")
    axes[2].set_ylabel("Gate Weight (%)")
    axes[2].set_title("Dynamic Ensemble Gating Weights\n(Section IV-B, Eq. 12)")
    axes[2].set_xticks(range(1, K+1))
    axes[2].axhline(100.0/K, color="red", linestyle="--",
                    label=f"Uniform ({100.0/K:.0f}%)")
    axes[2].legend(fontsize=8)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Visualization saved: {save_path}")


def main():
    parser = argparse.ArgumentParser(description="CrossForge Inference")
    parser.add_argument("--image",      required=True, help="Path to input image")
    parser.add_argument("--checkpoint", default=None,  help="Model checkpoint path")
    parser.add_argument("--dataset",    default=config.ACTIVE_DATASET)
    parser.add_argument("--target",     default=config.TARGET_DOMAIN)
    parser.add_argument("--top_k",      type=int, default=5)
    parser.add_argument("--save",       default=None,
                        help="Path to save visualization (default: results/)")
    args = parser.parse_args()

    device  = torch.device(config.DEVICE if torch.cuda.is_available() else "cpu")
    n_cls   = config.DATASETS[args.dataset]["num_classes"]
    classes = load_class_names(args.dataset, args.target)

    # Load model
    model = CrossForge(num_classes=n_cls, K=config.K, L=config.L).to(device)
    ckpt  = args.checkpoint or os.path.join(
        config.CHECKPOINT_DIR,
        f"crossforge_best_run{config.DEFAULT_SEED}.pth"
    )
    if os.path.exists(ckpt):
        state = load_checkpoint(ckpt, device)
        model.load_state_dict(state["model"])
        print(f"Model loaded from {ckpt}")
    else:
        print(f"WARNING: Checkpoint not found at {ckpt}. Using random weights.")

    # Save path
    os.makedirs(config.RESULTS_DIR, exist_ok=True)
    save_path = args.save or os.path.join(
        config.RESULTS_DIR,
        f"inference_{os.path.basename(args.image).split('.')[0]}.png"
    )

    run_inference(model, args.image, classes, device,
                  save_path=save_path, top_k=args.top_k)


if __name__ == "__main__":
    main()
