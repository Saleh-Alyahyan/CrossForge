"""
dataset.py - CrossForge Dataset Loading and Preprocessing
Paper Section V-A: Dataset descriptions and split protocols
Paper Section V-C: Data augmentation and preprocessing details
"""

import os
import glob
import zipfile
import tarfile
import urllib.request
from pathlib import Path
from typing import Tuple, Optional, List

import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader, Subset
from torchvision import transforms, datasets

import config


# ─────────────────────────────────────────────────────────────────────────────
# TRANSFORMS
# Section V-C: random resized crop 224x224, horizontal flip, color jitter,
# ImageNet normalization
# ─────────────────────────────────────────────────────────────────────────────

def get_train_transform() -> transforms.Compose:
    """
    Training augmentation pipeline (Section V-C):
    Random resized crop -> horizontal flip -> color jitter -> normalize
    """
    return transforms.Compose([
        transforms.Resize(config.RESIZE_SIZE),
        transforms.RandomResizedCrop(config.IMG_SIZE),
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(
            brightness=config.COLOR_JITTER["brightness"],
            contrast=config.COLOR_JITTER["contrast"],
            saturation=config.COLOR_JITTER["saturation"],
            hue=config.COLOR_JITTER["hue"],
        ),
        transforms.ToTensor(),
        transforms.Normalize(mean=config.IMAGENET_MEAN, std=config.IMAGENET_STD),
    ])


def get_test_transform() -> transforms.Compose:
    """
    Test transform (Section V: DomainNet-126 preprocessing details):
    Resize 256 -> center crop 224 -> normalize
    """
    return transforms.Compose([
        transforms.Resize(config.RESIZE_SIZE),
        transforms.CenterCrop(config.IMG_SIZE),
        transforms.ToTensor(),
        transforms.Normalize(mean=config.IMAGENET_MEAN, std=config.IMAGENET_STD),
    ])


# ─────────────────────────────────────────────────────────────────────────────
# DOWNLOAD HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def download_and_extract(url: str, dest_dir: str, filename: Optional[str] = None) -> None:
    """Download a file and extract if it is a zip/tar archive."""
    os.makedirs(dest_dir, exist_ok=True)
    if filename is None:
        filename = url.split("/")[-1]
    filepath = os.path.join(dest_dir, filename)

    if not os.path.exists(filepath):
        print(f"Downloading {url} ...")
        urllib.request.urlretrieve(url, filepath)
        print(f"Saved to {filepath}")
    else:
        print(f"File already exists: {filepath}")

    if filepath.endswith(".zip"):
        print("Extracting zip ...")
        with zipfile.ZipFile(filepath, "r") as zf:
            zf.extractall(dest_dir)
    elif filepath.endswith((".tar.gz", ".tgz", ".tar")):
        print("Extracting tar ...")
        with tarfile.open(filepath, "r:*") as tf:
            tf.extractall(dest_dir)
    print("Done.")


def download_office_home(dest: str = config.DATASETS["office_home"]["local_path"]) -> None:
    """
    Office-Home dataset.
    Download page: https://hemanthdv.github.io/officehome-dataset/
    Direct download (Google Drive public link):
    """
    url = "https://drive.google.com/uc?export=download&id=0B81rNlvomiwed0V1YUxQdC1uOTg"
    print("Office-Home: Please download manually from:")
    print("  https://hemanthdv.github.io/officehome-dataset/")
    print(f"  Extract to: {dest}")
    print("  Expected structure: data/office_home/Art/, Clipart/, Product/, Real_World/")
    os.makedirs(dest, exist_ok=True)
    # Automatic download requires gdrive authentication; manual preferred.


def download_domainnet(dest: str = config.DATASETS["domainnet_126"]["local_path"]) -> None:
    """
    DomainNet-126 (subset of full DomainNet).
    Data page: http://ai.bu.edu/M3SDA/
    """
    base_url = "http://csr.bu.edu/ftp/visda/2019/multi-source/"
    domains  = ["clipart", "painting", "real", "sketch", "infograph", "quickdraw"]
    os.makedirs(dest, exist_ok=True)
    for domain in domains:
        url = f"{base_url}{domain}.zip"
        domain_dir = os.path.join(dest, domain)
        if not os.path.exists(domain_dir):
            print(f"Downloading DomainNet domain: {domain}")
            download_and_extract(url, dest)
        else:
            print(f"DomainNet {domain} already exists.")


def download_visda(dest: str = config.DATASETS["visda_c"]["local_path"]) -> None:
    """
    VisDA-C: http://ai.bu.edu/visda-2017/
    Training (synthetic) and validation (real) splits.
    """
    print("VisDA-C: Please download from http://ai.bu.edu/visda-2017/")
    print(f"  Extract to: {dest}")
    print("  Expected structure: data/visda_c/train/, validation/")
    os.makedirs(dest, exist_ok=True)


# ─────────────────────────────────────────────────────────────────────────────
# BASE DOMAIN DATASET
# ─────────────────────────────────────────────────────────────────────────────

class DomainDataset(Dataset):
    """
    Generic domain dataset that loads images from a folder using ImageFolder.
    Supports Office-Home, DomainNet-126, VisDA-C, and clinical datasets.
    """

    def __init__(
        self,
        root: str,
        transform: Optional[transforms.Compose] = None,
        domain_name: str = "",
    ) -> None:
        self.root        = root
        self.transform   = transform
        self.domain_name = domain_name

        if not os.path.exists(root):
            raise FileNotFoundError(
                f"Dataset directory not found: {root}\n"
                "Please run dataset.py with --download to fetch the data."
            )

        self.dataset  = datasets.ImageFolder(root, transform=transform)
        self.classes  = self.dataset.classes
        self.class_to_idx = self.dataset.class_to_idx

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        return self.dataset[idx]


# ─────────────────────────────────────────────────────────────────────────────
# OFFICE-HOME DATASET
# Section V-A: 4 domains, 65 classes, 15500 images, 70/30 split
# ─────────────────────────────────────────────────────────────────────────────

class OfficeHomeDataset(DomainDataset):
    """
    Office-Home dataset (Section V-A, Table 3).
    Download: https://hemanthdv.github.io/officehome-dataset/
    Folder structure: data/office_home/{Art,Clipart,Product,Real_World}/{class}/
    """
    DOMAINS = ["Art", "Clipart", "Product", "Real_World"]
    NUM_CLASSES = 65

    def __init__(self, domain: str, split: str = "all",
                 transform: Optional[transforms.Compose] = None) -> None:
        assert domain in self.DOMAINS, f"Domain must be one of {self.DOMAINS}"
        root = os.path.join(config.DATASETS["office_home"]["local_path"], domain)
        super().__init__(root, transform, domain_name=domain)

        # 70/30 train/test split (Table 3, Section V)
        n         = len(self.dataset)
        indices   = list(range(n))
        np.random.seed(config.DEFAULT_SEED)
        np.random.shuffle(indices)
        split_idx = int(0.7 * n)

        if split == "train":
            self._indices = indices[:split_idx]
        elif split == "test":
            self._indices = indices[split_idx:]
        else:
            self._indices = indices

    def __len__(self) -> int:
        return len(self._indices)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        return self.dataset[self._indices[idx]]


# ─────────────────────────────────────────────────────────────────────────────
# DOMAINNET-126 DATASET
# Section V-A: 6 domains, 126 classes, 600k images, 70/30 split
# 7-task evaluation subset (Table 3)
# ─────────────────────────────────────────────────────────────────────────────

class DomainNet126Dataset(DomainDataset):
    """
    DomainNet-126 dataset (Section V-A, Table 3).
    Download: http://ai.bu.edu/M3SDA/
    Folder structure: data/domainnet126/{clipart,painting,real,sketch,...}/{class}/
    """
    DOMAINS = ["clipart", "painting", "real", "sketch", "infograph", "quickdraw"]
    NUM_CLASSES = 126
    EVAL_TASKS = [
        ("real", "clipart"), ("real", "painting"), ("clipart", "painting"),
        ("painting", "clipart"), ("clipart", "sketch"),
        ("painting", "sketch"), ("sketch", "real"),
    ]

    def __init__(self, domain: str, split: str = "all",
                 transform: Optional[transforms.Compose] = None) -> None:
        assert domain in self.DOMAINS, f"Domain must be one of {self.DOMAINS}"
        root = os.path.join(config.DATASETS["domainnet_126"]["local_path"], domain)
        super().__init__(root, transform, domain_name=domain)

        n         = len(self.dataset)
        indices   = list(range(n))
        np.random.seed(config.DEFAULT_SEED)
        np.random.shuffle(indices)
        split_idx = int(0.7 * n)

        if split == "train":
            self._indices = indices[:split_idx]
        elif split == "test":
            self._indices = indices[split_idx:]
        else:
            self._indices = indices

    def __len__(self) -> int:
        return len(self._indices)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        return self.dataset[self._indices[idx]]


# ─────────────────────────────────────────────────────────────────────────────
# PARTITIONED SOURCE DATASET FOR BASE LEARNER PRE-TRAINING
# Section V-C: K non-overlapping class-balanced subsets via stratified sampling
# ─────────────────────────────────────────────────────────────────────────────

def stratified_partition(dataset: Dataset, K: int, seed: int = 42) -> List[Subset]:
    """
    Partition dataset into K non-overlapping, class-balanced subsets.
    Section V-C: 'Source domain data is partitioned into K non-overlapping
    class-balanced subsets using stratified random sampling.'
    Each partition preserves the full class distribution of the source domain.
    """
    np.random.seed(seed)
    labels = np.array([dataset[i][1] for i in range(len(dataset))])
    classes = np.unique(labels)

    # Collect per-class indices
    class_indices = {c: np.where(labels == c)[0] for c in classes}

    # Split each class indices into K parts
    partition_indices = [[] for _ in range(K)]
    for c in classes:
        idx = class_indices[c]
        np.random.shuffle(idx)
        splits = np.array_split(idx, K)
        for k in range(K):
            partition_indices[k].extend(splits[k].tolist())

    return [Subset(dataset, part) for part in partition_indices]


# ─────────────────────────────────────────────────────────────────────────────
# DATALOADERS
# ─────────────────────────────────────────────────────────────────────────────

def get_source_loaders(
    dataset_name: str,
    source_domain: str,
    K: int = config.K,
    batch_size: int = config.PRETRAIN_BATCH_SIZE,
) -> List[DataLoader]:
    """
    Returns K DataLoaders for base learner pre-training.
    Each loader covers one stratified partition of the source domain.
    """
    full_source = OfficeHomeDataset(
        domain=source_domain,
        split="train",
        transform=get_train_transform(),
    ) if dataset_name == "office_home" else DomainNet126Dataset(
        domain=source_domain,
        split="train",
        transform=get_train_transform(),
    )

    partitions = stratified_partition(full_source, K)

    loaders = [
        DataLoader(
            part,
            batch_size=batch_size,
            shuffle=True,
            num_workers=config.NUM_WORKERS,
            pin_memory=config.PIN_MEMORY,
            drop_last=True,
        )
        for part in partitions
    ]
    return loaders


def get_target_loader(
    dataset_name: str,
    target_domain: str,
    batch_size: int = config.BATCH_SIZE,
    split: str = "all",
) -> DataLoader:
    """
    Returns DataLoader for the unlabeled target domain.
    Used during adaptation (no labels used in loss computation).
    """
    transform = get_train_transform() if split == "train" else get_test_transform()

    if dataset_name == "office_home":
        dataset = OfficeHomeDataset(target_domain, split=split, transform=transform)
    else:
        dataset = DomainNet126Dataset(target_domain, split=split, transform=transform)

    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=(split != "test"),
        num_workers=config.NUM_WORKERS,
        pin_memory=config.PIN_MEMORY,
        drop_last=(split == "train"),
    )


def get_test_loader(
    dataset_name: str,
    target_domain: str,
    batch_size: int = config.BATCH_SIZE,
) -> DataLoader:
    """Returns test DataLoader with test-time augmentation."""
    return get_target_loader(dataset_name, target_domain, batch_size, split="test")


# ─────────────────────────────────────────────────────────────────────────────
# DOWNLOAD SCRIPT ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Download CrossForge datasets")
    parser.add_argument("--dataset", choices=["office_home", "domainnet", "visda", "all"],
                        default="office_home")
    args = parser.parse_args()

    if args.dataset in ("office_home", "all"):
        download_office_home()
    if args.dataset in ("domainnet", "all"):
        download_domainnet()
    if args.dataset in ("visda", "all"):
        download_visda()

    print("\nDataset download complete. Please verify directory structure.")
    print(f"Expected root: {config.DATA_DIR}")
