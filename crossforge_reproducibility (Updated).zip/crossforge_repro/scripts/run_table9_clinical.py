"""
CrossForge: Reproduce Table 9 (Clinical, C1-C4) and the Table-9-adjacent
Macro-F1 figures for C2 (CheXpert) and C4 (ISIC 2018).

*** NOTE: results/reproduced/ is SYNTHETIC PLACEHOLDER DATA (see file header
and README.md) -- this exercises the pipeline only. C3 (CHAOS) is reported
as a 4-class CT->MRI classification proxy, not a segmentation Dice/IoU score
-- see REPRODUCIBILITY_SPEC.md and the manuscript's C3 note before citing. ***

Usage:
  python scripts/run_table9_clinical.py --seeds 42 123 2025
"""
import argparse, os, sys
import pandas as pd

METHOD_ORDER = ["Source Only", "SHOT", "NRC", "AaD", "LAME", "DaC", "G-SFDA", "CrossForge"]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=[42, 123, 2025])
    ap.add_argument("--csv", default=os.path.join(os.path.dirname(__file__), "..", "results",
                                                    "reproduced", "per_seed_per_task_results.csv"))
    args = ap.parse_args()
    df = pd.read_csv(args.csv, comment="#")
    df = df[(df["benchmark"] == "clinical") & (df["seed"].isin(args.seeds))]
    if df.empty:
        print("No clinical rows found for requested seeds.", file=sys.stderr); sys.exit(1)

    acc = df.pivot_table(index="task", columns="method", values="top1_accuracy", aggfunc="mean")
    acc = acc.reindex(columns=[m for m in METHOD_ORDER if m in acc.columns])
    acc.loc["Avg"] = acc.mean()
    print("=" * 78)
    print("Table 9 -- Clinical Top-1 accuracy (C1-C4), mean over seeds", args.seeds)
    print("SOURCE: results/reproduced/ (SYNTHETIC PLACEHOLDER DATA -- see header)")
    print("=" * 78)
    print(acc.round(1).to_string())

    f1df = df[df["macro_f1"].astype(str) != "N/A"].copy()
    if not f1df.empty:
        f1df["macro_f1"] = pd.to_numeric(f1df["macro_f1"], errors="coerce")
        f1 = f1df.pivot_table(index="task", columns="method", values="macro_f1", aggfunc="mean")
        f1 = f1.reindex(columns=[m for m in METHOD_ORDER if m in f1.columns])
        print("\nMacro-F1 (C2 CheXpert, C4 ISIC 2018 only):")
        print(f1.round(3).to_string())
    else:
        print("\nNo macro_f1 values populated yet (still N/A in results/reproduced/).")

if __name__ == "__main__":
    main()
