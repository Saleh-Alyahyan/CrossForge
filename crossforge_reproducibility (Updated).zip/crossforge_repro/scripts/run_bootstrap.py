"""
CrossForge: Paired bootstrap significance test (default: CrossForge vs DaC,
Office-Home, resampling over the 12 tasks), matching
supplementary/significance_tests.md Section 7.

*** NOTE: results/reproduced/ is SYNTHETIC PLACEHOLDER DATA -- this is the
real bootstrap procedure, run against placeholder numbers. It will not
reproduce the paper's reported intervals (separate 95% CIs 73.4-83.1 vs
67.9-78.8, paired-difference CI 4.2-5.8) until real per-task means replace
these numbers. ***

Usage:
  python scripts/run_bootstrap.py --benchmark office_home --n_resamples 10000
"""
import argparse, os, sys
import numpy as np
import pandas as pd

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--benchmark", default="office_home")
    ap.add_argument("--method_a", default="CrossForge")
    ap.add_argument("--method_b", default="DaC")
    ap.add_argument("--n_resamples", type=int, default=10000)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--csv", default=os.path.join(os.path.dirname(__file__), "..", "results",
                                                    "reproduced", "per_seed_per_task_results.csv"))
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)

    df = pd.read_csv(args.csv, comment="#")
    df = df[df["benchmark"] == args.benchmark]
    a = df[df["method"] == args.method_a].groupby("task")["top1_accuracy"].mean().values
    b = df[df["method"] == args.method_b].groupby("task")["top1_accuracy"].mean().values
    if len(a) == 0 or len(b) == 0 or len(a) != len(b):
        print("Mismatched or missing per-task means for the requested methods/benchmark.",
              file=sys.stderr)
        sys.exit(1)
    n = len(a)

    boot_a, boot_b, boot_diff = [], [], []
    for _ in range(args.n_resamples):
        idx = rng.integers(0, n, n)
        boot_a.append(a[idx].mean())
        boot_b.append(b[idx].mean())
        boot_diff.append((a - b)[idx].mean())
    boot_a, boot_b, boot_diff = map(np.array, (boot_a, boot_b, boot_diff))

    def ci(x):
        return np.percentile(x, 2.5), np.percentile(x, 97.5)

    ca, cb, cd = ci(boot_a), ci(boot_b), ci(boot_diff)
    print("=" * 78)
    print(f"Paired bootstrap, {args.benchmark}, n_resamples={args.n_resamples}")
    print("SOURCE: results/reproduced/ (SYNTHETIC PLACEHOLDER DATA -- see header)")
    print("=" * 78)
    print(f"{args.method_a} separate 95% CI: {ca[0]:.1f}-{ca[1]:.1f}")
    print(f"{args.method_b} separate 95% CI: {cb[0]:.1f}-{cb[1]:.1f}")
    print(f"Paired-difference 95% CI ({args.method_a} - {args.method_b}): "
          f"{cd[0]:.1f}-{cd[1]:.1f}  (excludes zero: {cd[0] > 0 or cd[1] < 0})")

if __name__ == "__main__":
    main()
