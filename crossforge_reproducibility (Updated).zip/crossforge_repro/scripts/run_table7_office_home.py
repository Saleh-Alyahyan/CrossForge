"""
CrossForge: Reproduce Table 7 (Office-Home, 12 tasks).

Reads per-seed results from results/reproduced/per_seed_per_task_results.csv
and prints the per-task and averaged accuracy table for all 8 methods.

*** NOTE ***
results/reproduced/per_seed_per_task_results.csv currently contains
SYNTHETIC PLACEHOLDER DATA (see the file header and README.md). No base
learners have actually been trained/adapted yet, so the numbers this
script prints do NOT reproduce the paper's Table 7 -- they only exercise
this aggregation pipeline end to end. Run pretrain_source.py, train.py and
evaluate_all.py for all (method, task, seed) combinations first, then
re-run scripts/collect_logs.py to populate real values before citing the
output of this script as a reproduction of Table 7.

Usage:
  python scripts/run_table7_office_home.py --seeds 42 123 2025
"""
import argparse
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

METHOD_ORDER = ["Source Only", "SHOT", "NRC", "AaD", "LAME", "DaC", "G-SFDA", "CrossForge"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=[42, 123, 2025])
    ap.add_argument(
        "--csv",
        default=os.path.join(os.path.dirname(__file__), "..", "results", "reproduced",
                              "per_seed_per_task_results.csv"),
    )
    args = ap.parse_args()

    df = pd.read_csv(args.csv, comment="#")
    df = df[df["benchmark"] == "office_home"]
    df = df[df["seed"].isin(args.seeds)]
    if df.empty:
        print("No office_home rows found for the requested seeds.", file=sys.stderr)
        sys.exit(1)

    pivot = df.pivot_table(index="task", columns="method", values="top1_accuracy", aggfunc="mean")
    pivot = pivot.reindex(columns=[m for m in METHOD_ORDER if m in pivot.columns])
    pivot.loc["Avg"] = pivot.mean()

    print("=" * 78)
    print("Table 7 -- Office-Home (12 tasks), mean over seeds", args.seeds)
    print("SOURCE: results/reproduced/ (SYNTHETIC PLACEHOLDER DATA -- see header)")
    print("=" * 78)
    print(pivot.round(1).to_string())

    ref = os.path.join(os.path.dirname(args.csv), "..", "expected", "table_means_reference.csv")
    if os.path.exists(ref):
        print(f"\nPublished means for comparison are in: {os.path.normpath(ref)}")


if __name__ == "__main__":
    main()
