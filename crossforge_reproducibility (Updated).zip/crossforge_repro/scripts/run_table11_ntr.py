"""
CrossForge: Reproduce Table 11 (Negative Transfer Rate, NTR) across all 24 tasks.

NTR = fraction of tasks where a method's accuracy falls below the
Source-Only accuracy on that same task.

*** NOTE: results/reproduced/ is SYNTHETIC PLACEHOLDER DATA (see file header
and README.md) -- this exercises the pipeline only; it will not reproduce
the paper's NTR values (SHOT 9.72%, NRC 6.94%, AaD 5.56%, LAME 11.11%,
DaC 8.33%, G-SFDA 6.94%, CrossForge 4.17%) until real adaptation runs
replace these numbers. ***

Usage:
  python scripts/run_table11_ntr.py --seeds 42 123 2025
"""
import argparse, os, sys
import pandas as pd

METHOD_ORDER = ["SHOT", "NRC", "AaD", "LAME", "DaC", "G-SFDA", "CrossForge"]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=[42, 123, 2025])
    ap.add_argument("--csv", default=os.path.join(os.path.dirname(__file__), "..", "results",
                                                    "reproduced", "per_seed_per_task_results.csv"))
    args = ap.parse_args()
    df = pd.read_csv(args.csv, comment="#")
    df = df[df["seed"].isin(args.seeds) & (df["method"] != "Source Only")]
    if df.empty:
        print("No rows found for requested seeds.", file=sys.stderr); sys.exit(1)
    df["below_source_only"] = pd.to_numeric(df["below_source_only"], errors="coerce")

    rows = []
    for method in METHOD_ORDER:
        sub = df[df["method"] == method]
        if sub.empty:
            continue
        per_seed = sub.groupby("seed")["below_source_only"].sum()
        n_tasks = sub["task"].nunique()
        mean_ntr = 100.0 * sub["below_source_only"].sum() / len(sub)
        rows.append({"method": method, **{f"seed_{s}_count": int(c) for s, c in per_seed.items()},
                     "n_tasks": n_tasks, "mean_NTR_pct": round(mean_ntr, 2)})
    out = pd.DataFrame(rows).set_index("method")
    print("=" * 78)
    print("Table 11 -- Negative Transfer Rate (NTR), mean over seeds", args.seeds)
    print("SOURCE: results/reproduced/ (SYNTHETIC PLACEHOLDER DATA -- see header)")
    print("=" * 78)
    print(out.to_string())

if __name__ == "__main__":
    main()
