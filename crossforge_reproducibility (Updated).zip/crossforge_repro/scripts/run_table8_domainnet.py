"""
CrossForge: Reproduce Table 8 (DomainNet-126, 7-task subset).

*** NOTE: results/reproduced/ is SYNTHETIC PLACEHOLDER DATA (see file header
and README.md) -- this exercises the pipeline only, it does not reproduce
the paper's Table 8 until real adaptation runs replace these values. ***

Usage:
  python scripts/run_table8_domainnet.py --seeds 42 123 2025
"""
import argparse, os, sys
import pandas as pd

METHOD_ORDER = ["Source Only", "SHOT", "NRC", "AaD", "LAME", "DaC", "G-SFDA", "CrossForge"]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=[42, 123, 2025])
    ap.add_argument("--csv", default=os.path.join(os.path.dirname(__file__), "..", "results",
                                                    "reproduced", "per_seed_per_task_results.csv"))
    args = ap.parse_args()
    df = pd.read_csv(args.csv, comment="#")
    df = df[(df["benchmark"] == "domainnet126") & (df["seed"].isin(args.seeds))]
    if df.empty:
        print("No domainnet126 rows found for requested seeds.", file=sys.stderr); sys.exit(1)
    pivot = df.pivot_table(index="task", columns="method", values="top1_accuracy", aggfunc="mean")
    pivot = pivot.reindex(columns=[m for m in METHOD_ORDER if m in pivot.columns])
    pivot.loc["Avg (7 tasks)"] = pivot.mean()
    print("=" * 78)
    print("Table 8 -- DomainNet-126 (7-task subset), mean over seeds", args.seeds)
    print("SOURCE: results/reproduced/ (SYNTHETIC PLACEHOLDER DATA -- see header)")
    print("=" * 78)
    print(pivot.round(1).to_string())

if __name__ == "__main__":
    main()
